import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import Stripe from 'stripe';
import cron from 'node-cron';
import { initializeApp, getApps } from 'firebase-admin/app';
import { getAuth, DecodedIdToken } from 'firebase-admin/auth';
import firebaseConfig from './firebase-applet-config.json' with { type: 'json' };
import {
  readGatewayCredentials,
  writeGatewayCredentials,
  getPublicGatewayStatus,
  readSmtpCredentials,
  writeSmtpCredentials,
  getPublicSmtpStatus,
  SmtpPreset,
  signToken,
  verifySignature,
} from './src/server/vault.ts';
import { generateInvoicePdfBuffer, InvoicePdfPayload } from './src/server/pdf.ts';
import {
  sendEmailViaGmailApi,
  sendEmailViaSmtp,
  verifySmtpConnection,
} from './src/server/gmail.ts';
import {
  savePublicInvoiceSnapshot,
  readPublicInvoiceSnapshot,
  saveBankInstructionSnapshot,
  readBankInstructionSnapshot,
  appendServerErrorLog,
  readServerErrorLogs,
  recordBufferedWebhookEvent,
  getPendingWebhookEvents,
  markWebhookEventSynced,
} from './src/server/publicStore.ts';
import {
  readAccountStore,
  upsertAccountDocument,
  deleteAccountDocument,
  mergeCloudStoreSnapshot,
  migrateLegacyGlobalStoreToAccount,
  registerAccountIndex,
  resolveAccountUidByEmail,
  StoreCollectionName,
} from './src/server/dbStore.ts';
import {
  ALL_API_SCOPES,
  ApiKeyScope,
  PublicApiKeyRecord,
  createApiKey,
  deleteApiKey,
  listApiKeysForAccount,
  readApiActivityForAccount,
  recordApiActivity,
  toggleApiKeyActive,
  verifyApiKeyToken,
} from './src/server/apiKeys.ts';
import {
  clearOtpChallenge,
  getSecuritySessionStatus,
  maskEmailAddress,
  prepareOtpChallenge,
  revokeSecuritySession,
  setRequire24hOtpSetting,
  verifyOtpChallenge,
} from './src/server/securityOtp.ts';

const PORT = Number(process.env.PORT) || 3000;

const VALID_COLLECTIONS = new Set<string>([
  'clients',
  'services',
  'subscriptions',
  'payments',
  'payment_requests',
  'invoices',
  'invoice_items',
  'reminder_settings',
  'reminder_logs',
  'email_logs',
  'email_templates',
  'payment_gateway_settings',
  'webhook_events',
  'system_settings',
]);

if (!getApps().length) {
  initializeApp({
    projectId: firebaseConfig.projectId,
  });
}

const adminAuth = getAuth();

interface AuthedRequest extends Request {
  adminUser?: DecodedIdToken;
  authTokenError?: string;
  apiKeyRecord?: PublicApiKeyRecord;
}

// Verifies optional Firebase ID token if attached, while keeping the disconnected store empty
// and surfacing invalid/expired token status so clients can force-refresh and retry.
async function attachOptionalFirebaseUser(
  req: AuthedRequest,
  res: Response,
  next: NextFunction
) {
  const token = req.header('X-Firebase-Id-Token');
  if (token) {
    try {
      const decoded = await adminAuth.verifyIdToken(token);
      req.adminUser = decoded;
      registerAccountIndex(decoded.uid, decoded.email);
    } catch (err) {
      const code =
        typeof err === 'object' && err !== null && 'code' in err
          ? String((err as { code?: unknown }).code)
          : 'invalid-token';
      const msg = err instanceof Error ? err.message : String(err);
      console.warn('[auth] verifyIdToken failed:', code, msg);
      appendServerErrorLog('firebase-auth', 'ID token verification failed', `${code}: ${msg}`);
      req.authTokenError = code;
      res.setHeader('X-Auth-Token-Error', code);
    }
  }
  next();
}

function getBaseUrl(req: Request): string {
  const smtp = readSmtpCredentials();
  if (smtp.publicPortalUrl && /^https?:\/\//i.test(smtp.publicPortalUrl.trim())) {
    return smtp.publicPortalUrl.trim().replace(/\/$/, '');
  }
  if (process.env.APP_URL && process.env.APP_URL !== 'MY_APP_URL') {
    return process.env.APP_URL.replace(/\/$/, '');
  }
  const proto = req.header('x-forwarded-proto') || req.protocol || 'http';
  const host = req.header('x-forwarded-host') || req.get('host') || `localhost:${PORT}`;
  return `${proto}://${host}`;
}

let cronTimezone = 'UTC';
let lastCronRunAt: string | null = null;
let cronJob: ReturnType<typeof cron.schedule> | null = null;

function startDailyReminderCron(tz: string) {
  if (cronJob) {
    cronJob.stop();
  }
  cronTimezone = tz || 'UTC';
  try {
    cronJob = cron.schedule(
      '0 9 * * *',
      () => {
        lastCronRunAt = new Date().toISOString();
      },
      { timezone: cronTimezone }
    );
  } catch (err) {
    appendServerErrorLog(
      'cron',
      'Invalid timezone for reminder schedule, falling back to UTC',
      err instanceof Error ? err.message : String(err)
    );
    cronTimezone = 'UTC';
    cronJob = cron.schedule('0 9 * * *', () => {
      lastCronRunAt = new Date().toISOString();
    });
  }
}

async function createServer() {
  const app = express();
  startDailyReminderCron('UTC');

  // Webhook endpoint MUST receive raw body for cryptographic signature verification
  app.post('/api/webhooks/payment', express.raw({ type: 'application/json' }), (req, res) => {
    try {
      const creds = readGatewayCredentials();
      if (!creds.secretKey || !creds.webhookSecret) {
        appendServerErrorLog('webhook', 'Received webhook while gateway webhook secret is not configured');
        res.status(400).json({ error: 'Webhook secret not configured on server.' });
        return;
      }

      const signature = req.header('stripe-signature');
      if (!signature) {
        res.status(400).json({ error: 'Missing stripe-signature header.' });
        return;
      }

      const stripe = new Stripe(creds.secretKey);
      const event = stripe.webhooks.constructEvent(req.body, signature, creds.webhookSecret);

      if (event.type === 'checkout.session.completed') {
        const session = event.data.object as Stripe.Checkout.Session;
        const paymentRequestId = session.metadata?.paymentRequestId;
        const amountPaid = session.amount_total ? session.amount_total / 100 : undefined;
        const currency = session.currency ? session.currency.toUpperCase() : undefined;

        recordBufferedWebhookEvent({
          externalEventId: event.id,
          provider: 'stripe',
          eventType: event.type,
          paymentRequestId,
          sessionId: session.id,
          amountPaid,
          currency,
          transactionReference:
            typeof session.payment_intent === 'string'
              ? session.payment_intent
              : session.id,
          summary: `Checkout session ${session.id} completed (${amountPaid ?? 0} ${currency ?? ''})`,
          receivedAt: new Date().toISOString(),
          syncedToFirestore: false,
        });
      } else {
        recordBufferedWebhookEvent({
          externalEventId: event.id,
          provider: 'stripe',
          eventType: event.type,
          summary: `Verified webhook event ${event.type}`,
          receivedAt: new Date().toISOString(),
          syncedToFirestore: false,
        });
      }

      res.json({ received: true });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Webhook signature verification failed';
      appendServerErrorLog('webhook', 'Webhook verification error', msg);
      res.status(400).json({ error: msg });
    }
  });

  app.use(express.json({ limit: '5mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'freska-assist', timestamp: new Date().toISOString() });
  });

  // --- Persistent Account-Scoped Store Endpoints ---
  app.get('/api/store', attachOptionalFirebaseUser, (req: AuthedRequest, res) => {
    const uid = req.adminUser?.uid;
    if (!uid) {
      if (req.authTokenError) {
        res.status(401).json({
          error: 'Firebase session token expired or invalid. Refreshing authentication...',
        });
        return;
      }
      res.json({
        clients: [],
        services: [],
        subscriptions: [],
        payments: [],
        payment_requests: [],
        invoices: [],
        invoice_items: [],
        reminder_settings: [],
        reminder_logs: [],
        email_logs: [],
        email_templates: [],
        payment_gateway_settings: [],
        webhook_events: [],
        system_settings: [],
      });
      return;
    }

    migrateLegacyGlobalStoreToAccount(uid, req.adminUser?.email);
    const store = readAccountStore(uid);
    res.json({
      clients: Object.values(store.clients),
      services: Object.values(store.services),
      subscriptions: Object.values(store.subscriptions),
      payments: Object.values(store.payments),
      payment_requests: Object.values(store.payment_requests),
      invoices: Object.values(store.invoices),
      invoice_items: Object.values(store.invoice_items),
      reminder_settings: Object.values(store.reminder_settings),
      reminder_logs: Object.values(store.reminder_logs),
      email_logs: Object.values(store.email_logs),
      email_templates: Object.values(store.email_templates),
      payment_gateway_settings: Object.values(store.payment_gateway_settings),
      webhook_events: Object.values(store.webhook_events),
      system_settings: Object.values(store.system_settings),
    });
  });

  app.put('/api/store/:collection/:id', attachOptionalFirebaseUser, (req: AuthedRequest, res) => {
    const uid = req.adminUser?.uid;
    if (!uid) {
      res.status(401).json({ error: 'Connect your Google Account to save client data.' });
      return;
    }
    const { collection: col, id } = req.params;
    if (!VALID_COLLECTIONS.has(col)) {
      res.status(400).json({ error: `Unknown collection: ${col}` });
      return;
    }
    migrateLegacyGlobalStoreToAccount(uid, req.adminUser?.email);
    const saved = upsertAccountDocument(
      uid,
      col as StoreCollectionName,
      id,
      (req.body || {}) as Record<string, unknown>
    );
    res.json(saved);
  });

  app.delete('/api/store/:collection/:id', attachOptionalFirebaseUser, (req: AuthedRequest, res) => {
    const uid = req.adminUser?.uid;
    if (!uid) {
      res.status(401).json({ error: 'Connect your Google Account to delete client data.' });
      return;
    }
    const { collection: col, id } = req.params;
    if (!VALID_COLLECTIONS.has(col)) {
      res.status(400).json({ error: `Unknown collection: ${col}` });
      return;
    }
    deleteAccountDocument(uid, col as StoreCollectionName, id);
    res.json({ ok: true });
  });

  app.post('/api/store/sync-cloud', attachOptionalFirebaseUser, (req: AuthedRequest, res) => {
    try {
      const uid = req.adminUser?.uid;
      if (!uid) {
        res.status(401).json({ error: 'Connect your Google Account to sync cloud data.' });
        return;
      }
      const { collections, allowEmptyCollections } = (req.body || {}) as {
        collections?: Partial<Record<StoreCollectionName, Array<Record<string, unknown>>>>;
        allowEmptyCollections?: string[];
      };
      if (!collections || typeof collections !== 'object') {
        res.status(400).json({ error: 'Invalid collections payload.' });
        return;
      }
      migrateLegacyGlobalStoreToAccount(uid, req.adminUser?.email);
      const nextStore = mergeCloudStoreSnapshot(
        uid,
        collections,
        Array.isArray(allowEmptyCollections) ? allowEmptyCollections : []
      );
      res.json({ ok: true, clientsCount: Object.keys(nextStore.clients || {}).length });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to mirror cloud store';
      res.status(500).json({ error: msg });
    }
  });

  // --- Public Signed Invoice Download ---
  app.get('/api/public/invoice/:invoiceId', async (req, res) => {
    try {
      const { invoiceId } = req.params;
      const sig = String(req.query.sig || '');
      if (!verifySignature(`invoice:${invoiceId}`, sig)) {
        res.status(403).json({ error: 'Invalid or expired invoice access signature.' });
        return;
      }

      const snapshot = readPublicInvoiceSnapshot(invoiceId);
      if (!snapshot) {
        res.status(404).json({ error: 'Invoice record not found.' });
        return;
      }

      const pdfBuffer = await generateInvoicePdfBuffer(snapshot);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader(
        'Content-Disposition',
        `inline; filename="FreskaAssist-${snapshot.invoiceNumber}.pdf"`
      );
      res.send(pdfBuffer);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to render PDF invoice';
      appendServerErrorLog('invoice-public', 'Failed to stream public invoice PDF', msg);
      res.status(500).json({ error: msg });
    }
  });

  // --- Public Signed Bank Transfer & Hosted Checkout Lookup ---
  app.get('/api/public/bank-request/:requestId', (req, res) => {
    const { requestId } = req.params;
    const sig = String(req.query.sig || '');
    if (!verifySignature(`bank:${requestId}`, sig)) {
      res.status(403).json({ error: 'Invalid or expired payment request signature.' });
      return;
    }

    const snapshot = readBankInstructionSnapshot(requestId);
    if (!snapshot) {
      res.status(404).json({ error: 'Payment instruction record not found.' });
      return;
    }

    const creds = readGatewayCredentials();
    res.json({
      ...snapshot,
      cardGateway: {
        liveEnabled: Boolean(creds.enabled && creds.connectionVerified && creds.secretKey),
        testModeAvailable: true,
      },
    });
  });

  app.post('/api/public/bank-request/:requestId/test-checkout', (req, res) => {
    try {
      const { requestId } = req.params;
      const sig = String(req.query.sig || '');
      if (!verifySignature(`bank:${requestId}`, sig)) {
        res.status(403).json({ error: 'Invalid or expired payment request signature.' });
        return;
      }

      const snapshot = readBankInstructionSnapshot(requestId);
      if (!snapshot) {
        res.status(404).json({ error: 'Payment request record not found.' });
        return;
      }

      if (snapshot.status === 'paid') {
        res.json({ ok: true, alreadyPaid: true, snapshot });
        return;
      }

      const { cardLast4 } = (req.body || {}) as { cardLast4?: string };
      const cleanLast4 =
        typeof cardLast4 === 'string' ? cardLast4.replace(/\D/g, '').slice(-4) : '4242';
      const now = new Date().toISOString();
      const txRef = `TEST-CHK-${Date.now().toString(36).toUpperCase()}`;

      const updatedSnapshot = {
        ...snapshot,
        status: 'paid',
        paidAt: now,
        paidMethod: 'card' as const,
        transactionReference: txRef,
        testMode: true,
        updatedAt: now,
      };
      saveBankInstructionSnapshot(updatedSnapshot);

      recordBufferedWebhookEvent({
        externalEventId: `test_evt_${requestId}_${Date.now()}`,
        provider: 'test_checkout',
        eventType: 'checkout.session.completed',
        paymentRequestId: requestId,
        sessionId: txRef,
        amountPaid: snapshot.amount,
        currency: snapshot.currency,
        transactionReference: txRef,
        summary: `Test Checkout completed (${snapshot.amount} ${snapshot.currency} · Card •••• ${
          cleanLast4 || '4242'
        })`,
        receivedAt: now,
        syncedToFirestore: false,
      });

      res.json({
        ok: true,
        transactionReference: txRef,
        paidAt: now,
        snapshot: updatedSnapshot,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Test checkout processing failed';
      appendServerErrorLog('test-checkout', 'Test checkout failure', msg);
      res.status(500).json({ error: msg });
    }
  });

  app.post('/api/public/bank-request/:requestId/live-checkout', async (req, res) => {
    try {
      const { requestId } = req.params;
      const sig = String(req.query.sig || '');
      if (!verifySignature(`bank:${requestId}`, sig)) {
        res.status(403).json({ error: 'Invalid or expired payment request signature.' });
        return;
      }

      const snapshot = readBankInstructionSnapshot(requestId);
      if (!snapshot) {
        res.status(404).json({ error: 'Payment request record not found.' });
        return;
      }

      const creds = readGatewayCredentials();
      if (!creds.enabled || !creds.connectionVerified || !creds.secretKey) {
        res.status(400).json({ error: 'Live card gateway is not active.' });
        return;
      }

      const stripe = new Stripe(creds.secretKey);
      const baseUrl = getBaseUrl(req);
      const session = await stripe.checkout.sessions.create({
        mode: 'payment',
        line_items: [
          {
            price_data: {
              currency: (snapshot.currency || 'EUR').toLowerCase(),
              unit_amount: Math.round(snapshot.amount * 100),
              product_data: {
                name: snapshot.serviceName,
                description: snapshot.description || undefined,
              },
            },
            quantity: 1,
          },
        ],
        metadata: {
          paymentRequestId: requestId,
          clientId: snapshot.clientId || '',
          billingType: snapshot.billingType || 'one_time',
          subscriptionId: snapshot.subscriptionId || '',
        },
        success_url: `${baseUrl}/?checkout=success&session_id={CHECKOUT_SESSION_ID}&request_id=${encodeURIComponent(
          requestId
        )}`,
        cancel_url: `${baseUrl}/?bank_request=${encodeURIComponent(
          requestId
        )}&sig=${encodeURIComponent(sig)}`,
      });

      if (!session.url) {
        throw new Error('Stripe did not return a hosted checkout URL.');
      }

      res.json({ checkoutUrl: session.url, sessionId: session.id });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to initialize card checkout';
      appendServerErrorLog('live-checkout', 'Live checkout session error', msg);
      res.status(400).json({ error: msg });
    }
  });

  app.post('/api/public/bank-request/:requestId/report-transfer', (req, res) => {
    try {
      const { requestId } = req.params;
      const sig = String(req.query.sig || '');
      if (!verifySignature(`bank:${requestId}`, sig)) {
        res.status(403).json({ error: 'Invalid or expired payment request signature.' });
        return;
      }

      const snapshot = readBankInstructionSnapshot(requestId);
      if (!snapshot) {
        res.status(404).json({ error: 'Payment instruction record not found.' });
        return;
      }

      const { note } = (req.body || {}) as { note?: string };
      const now = new Date().toISOString();
      const updated = {
        ...snapshot,
        clientReportedTransfer: true,
        clientReportedAt: now,
        clientTransferNote: typeof note === 'string' ? note.trim().slice(0, 300) : '',
        updatedAt: now,
      };
      saveBankInstructionSnapshot(updated);
      res.json({ ok: true, snapshot: updated });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to record transfer notice';
      res.status(500).json({ error: msg });
    }
  });

  // --- Admin Payment Gateway Configuration & Checkout ---
  app.get('/api/admin/gateway/status', attachOptionalFirebaseUser, (_req, res) => {
    res.json(getPublicGatewayStatus());
  });

  app.post('/api/admin/gateway/config', attachOptionalFirebaseUser, (req, res) => {
    try {
      const existing = readGatewayCredentials();
      const {
        provider = 'stripe',
        environment = 'test',
        publicKey,
        secretKey,
        webhookSecret,
      } = req.body as {
        provider?: 'stripe';
        environment?: 'test' | 'live';
        publicKey?: string;
        secretKey?: string;
        webhookSecret?: string;
      };

      const nextPublicKey = typeof publicKey === 'string' ? publicKey.trim() : existing.publicKey;
      const nextSecretKey =
        typeof secretKey === 'string' && secretKey.trim().length > 0
          ? secretKey.trim()
          : existing.secretKey;
      const nextWebhookSecret =
        typeof webhookSecret === 'string' && webhookSecret.trim().length > 0
          ? webhookSecret.trim()
          : existing.webhookSecret;

      const secretChanged =
        typeof secretKey === 'string' &&
        secretKey.trim().length > 0 &&
        secretKey.trim() !== existing.secretKey;

      const updated = {
        ...existing,
        provider,
        environment: environment === 'live' ? ('live' as const) : ('test' as const),
        publicKey: nextPublicKey,
        secretKey: nextSecretKey,
        webhookSecret: nextWebhookSecret,
        connectionVerified: secretChanged ? false : existing.connectionVerified,
        enabled: secretChanged ? false : existing.enabled,
        updatedAt: new Date().toISOString(),
      };

      writeGatewayCredentials(updated);
      res.json(getPublicGatewayStatus());
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to save gateway configuration';
      appendServerErrorLog('gateway', 'Failed to save gateway config', msg);
      res.status(500).json({ error: msg });
    }
  });

  app.post('/api/admin/gateway/clear', attachOptionalFirebaseUser, (_req, res) => {
    writeGatewayCredentials({
      provider: 'stripe',
      environment: 'test',
      publicKey: '',
      secretKey: '',
      webhookSecret: '',
      enabled: false,
      connectionVerified: false,
      lastVerifiedAt: null,
      accountId: null,
      updatedAt: new Date().toISOString(),
    });
    res.json(getPublicGatewayStatus());
  });

  app.post('/api/admin/gateway/test', attachOptionalFirebaseUser, async (_req, res) => {
    try {
      const creds = readGatewayCredentials();
      if (!creds.secretKey) {
        res.status(400).json({
          error: 'No Secret API Key is saved. Enter valid gateway credentials first.',
        });
        return;
      }

      const stripe = new Stripe(creds.secretKey);
      const balance = await stripe.balance.retrieve();
      const verifiedLabel = balance.livemode ? 'Stripe Live' : 'Stripe Test';

      const updated = {
        ...creds,
        connectionVerified: true,
        lastVerifiedAt: new Date().toISOString(),
        accountId: verifiedLabel,
        updatedAt: new Date().toISOString(),
      };
      writeGatewayCredentials(updated);
      res.json({ verified: true, accountId: verifiedLabel, status: getPublicGatewayStatus() });
    } catch (err) {
      const creds = readGatewayCredentials();
      writeGatewayCredentials({
        ...creds,
        connectionVerified: false,
        enabled: false,
        updatedAt: new Date().toISOString(),
      });
      const msg = err instanceof Error ? err.message : 'Gateway authentication failed';
      appendServerErrorLog('gateway', 'Payment gateway connection test failed', msg);
      res.status(400).json({ error: msg, status: getPublicGatewayStatus() });
    }
  });

  app.post('/api/admin/gateway/toggle', attachOptionalFirebaseUser, (req, res) => {
    const { enabled } = req.body as { enabled?: boolean };
    const creds = readGatewayCredentials();

    if (enabled) {
      if (!creds.secretKey || !creds.publicKey) {
        res.status(400).json({
          error: 'Cannot enable card payments: Public and Secret API keys must be configured.',
        });
        return;
      }
      if (!creds.connectionVerified) {
        res.status(400).json({
          error: 'Cannot enable card payments: Test and verify the gateway connection first.',
        });
        return;
      }
    }

    writeGatewayCredentials({
      ...creds,
      enabled: Boolean(enabled),
      updatedAt: new Date().toISOString(),
    });
    res.json(getPublicGatewayStatus());
  });

  app.post('/api/admin/gateway/checkout', attachOptionalFirebaseUser, async (req, res) => {
    try {
      const creds = readGatewayCredentials();
      if (!creds.enabled || !creds.connectionVerified || !creds.secretKey) {
        res.status(400).json({
          error:
            'Card payments are disabled until valid gateway credentials are entered, tested, and enabled.',
        });
        return;
      }

      const {
        paymentRequestId,
        clientId,
        clientEmail,
        serviceName,
        description,
        amount,
        currency,
        billingType,
        subscriptionId,
      } = req.body as {
        paymentRequestId: string;
        clientId: string;
        clientEmail: string;
        serviceName: string;
        description?: string;
        amount: number;
        currency: string;
        billingType: 'subscription' | 'one_time';
        subscriptionId?: string;
      };

      if (!amount || amount <= 0) {
        res.status(400).json({ error: 'Amount must be greater than zero.' });
        return;
      }

      const stripe = new Stripe(creds.secretKey);
      const baseUrl = getBaseUrl(req);
      const unitAmount = Math.round(amount * 100);

      const session = await stripe.checkout.sessions.create({
        mode: 'payment',
        customer_email: clientEmail,
        line_items: [
          {
            price_data: {
              currency: (currency || 'USD').toLowerCase(),
              unit_amount: unitAmount,
              product_data: {
                name: serviceName,
                description: description || undefined,
              },
            },
            quantity: 1,
          },
        ],
        metadata: {
          paymentRequestId,
          clientId,
          billingType,
          subscriptionId: subscriptionId || '',
        },
        success_url: `${baseUrl}/?checkout=success&session_id={CHECKOUT_SESSION_ID}&request_id=${encodeURIComponent(
          paymentRequestId
        )}`,
        cancel_url: `${baseUrl}/?checkout=cancelled&request_id=${encodeURIComponent(
          paymentRequestId
        )}`,
      });

      if (!session.url) {
        throw new Error('Payment provider did not return a hosted checkout URL.');
      }

      res.json({ checkoutUrl: session.url, sessionId: session.id });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to create checkout session';
      appendServerErrorLog('gateway-checkout', 'Checkout session creation failed', msg);
      res.status(400).json({ error: msg });
    }
  });

  app.get('/api/admin/gateway/session/:sessionId', attachOptionalFirebaseUser, async (req, res) => {
    try {
      const creds = readGatewayCredentials();
      if (!creds.secretKey) {
        res.status(400).json({ error: 'Gateway credentials are not configured.' });
        return;
      }
      const stripe = new Stripe(creds.secretKey);
      const session = await stripe.checkout.sessions.retrieve(req.params.sessionId);
      res.json({
        id: session.id,
        paymentStatus: session.payment_status,
        status: session.status,
        amountTotal: session.amount_total ? session.amount_total / 100 : 0,
        currency: session.currency?.toUpperCase() || 'USD',
        paymentIntent:
          typeof session.payment_intent === 'string' ? session.payment_intent : session.id,
        metadata: session.metadata || {},
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to retrieve checkout session';
      res.status(400).json({ error: msg });
    }
  });

  // --- Server-Side PDF Invoice Endpoints ---
  app.post('/api/admin/invoices/register-public', attachOptionalFirebaseUser, (req, res) => {
    try {
      const { invoiceId, payload } = req.body as {
        invoiceId: string;
        payload: InvoicePdfPayload;
      };
      if (!invoiceId || !payload?.invoiceNumber) {
        res.status(400).json({ error: 'Missing invoiceId or invoice payload.' });
        return;
      }
      savePublicInvoiceSnapshot(invoiceId, payload);
      const sig = signToken(`invoice:${invoiceId}`);
      const baseUrl = getBaseUrl(req);
      const downloadUrl = `${baseUrl}/api/public/invoice/${encodeURIComponent(
        invoiceId
      )}?sig=${sig}`;
      res.json({ downloadToken: sig, downloadUrl });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to register invoice snapshot';
      res.status(500).json({ error: msg });
    }
  });

  app.post('/api/admin/invoices/pdf', attachOptionalFirebaseUser, async (req, res) => {
    try {
      const payload = req.body as InvoicePdfPayload;
      const pdfBuffer = await generateInvoicePdfBuffer(payload);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader(
        'Content-Disposition',
        `inline; filename="FreskaAssist-${payload.invoiceNumber || 'Invoice'}.pdf"`
      );
      res.send(pdfBuffer);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'PDF generation failed';
      appendServerErrorLog('pdf', 'Failed to generate invoice PDF', msg);
      res.status(500).json({ error: msg });
    }
  });

  // --- Bank Transfer & Hosted Checkout Public Snapshot ---
  app.post('/api/admin/payment-requests/register-bank', attachOptionalFirebaseUser, (req, res) => {
    try {
      const snapshot = req.body;
      if (!snapshot?.requestId) {
        res.status(400).json({ error: 'Missing requestId.' });
        return;
      }
      saveBankInstructionSnapshot(snapshot);
      const sig = signToken(`bank:${snapshot.requestId}`);
      const baseUrl = getBaseUrl(req);
      const paymentUrl = `${baseUrl}/?bank_request=${encodeURIComponent(
        snapshot.requestId
      )}&sig=${sig}`;
      res.json({ paymentUrl, signature: sig });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to save bank request instructions';
      res.status(500).json({ error: msg });
    }
  });

  app.post(
    '/api/admin/payment-requests/:requestId/mark-paid',
    attachOptionalFirebaseUser,
    (req, res) => {
      try {
        const { requestId } = req.params;
        const snapshot = readBankInstructionSnapshot(requestId);
        if (!snapshot) {
          res.json({ ok: true, updated: false });
          return;
        }
        const { paymentMethod, transactionReference } = (req.body || {}) as {
          paymentMethod?: 'bank_transfer' | 'card' | 'manual';
          transactionReference?: string;
        };
        const now = new Date().toISOString();
        saveBankInstructionSnapshot({
          ...snapshot,
          status: 'paid',
          paidAt: snapshot.paidAt || now,
          paidMethod: paymentMethod || snapshot.paidMethod || 'bank_transfer',
          transactionReference:
            transactionReference || snapshot.transactionReference || snapshot.reference,
          updatedAt: now,
        });
        res.json({ ok: true, updated: true });
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Failed to mark snapshot paid';
        res.status(500).json({ error: msg });
      }
    }
  );

  // --- Verified Domain / Custom SMTP Email Relay Configuration ---
  app.get('/api/admin/email/status', attachOptionalFirebaseUser, (_req, res) => {
    res.json(getPublicSmtpStatus());
  });

  app.post('/api/admin/email/config', attachOptionalFirebaseUser, (req, res) => {
    try {
      const existing = readSmtpCredentials();
      const {
        preset,
        host,
        port,
        secure,
        username,
        password,
        fromName,
        fromEmail,
        replyTo,
        publicPortalUrl,
      } = (req.body || {}) as {
        preset?: SmtpPreset;
        host?: string;
        port?: number;
        secure?: boolean;
        username?: string;
        password?: string;
        fromName?: string;
        fromEmail?: string;
        replyTo?: string;
        publicPortalUrl?: string;
      };

      const nextHost = typeof host === 'string' ? host.trim() : existing.host;
      const nextPort = typeof port === 'number' && Number.isFinite(port) ? port : existing.port;
      const nextSecure = typeof secure === 'boolean' ? secure : existing.secure;
      const nextUser = typeof username === 'string' ? username.trim() : existing.username;
      const nextPass =
        typeof password === 'string' && password.trim().length > 0
          ? password.trim()
          : existing.password;
      const nextFromName = typeof fromName === 'string' ? fromName.trim() : existing.fromName;
      const nextFromEmail = typeof fromEmail === 'string' ? fromEmail.trim() : existing.fromEmail;
      const nextReplyTo = typeof replyTo === 'string' ? replyTo.trim() : existing.replyTo;
      const nextPortalUrl =
        typeof publicPortalUrl === 'string' ? publicPortalUrl.trim() : existing.publicPortalUrl;

      const connectionChanged =
        nextHost !== existing.host ||
        nextPort !== existing.port ||
        nextSecure !== existing.secure ||
        nextUser !== existing.username ||
        (typeof password === 'string' && password.trim().length > 0 && password.trim() !== existing.password);

      writeSmtpCredentials({
        preset: preset || existing.preset || 'custom',
        host: nextHost,
        port: nextPort || 587,
        secure: nextSecure,
        username: nextUser,
        password: nextPass,
        fromName: nextFromName || 'FreskaAssist',
        fromEmail: nextFromEmail,
        replyTo: nextReplyTo,
        publicPortalUrl: nextPortalUrl,
        connectionVerified: connectionChanged ? false : existing.connectionVerified,
        enabled: connectionChanged ? false : existing.enabled,
        lastVerifiedAt: connectionChanged ? null : existing.lastVerifiedAt,
        updatedAt: new Date().toISOString(),
      });

      res.json(getPublicSmtpStatus());
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to save SMTP configuration';
      appendServerErrorLog('email', 'Failed to save SMTP config', msg);
      res.status(500).json({ error: msg });
    }
  });

  app.post('/api/admin/email/test', attachOptionalFirebaseUser, async (_req, res) => {
    const creds = readSmtpCredentials();
    if (!creds.host || !creds.fromEmail) {
      res.status(400).json({ error: 'SMTP host and From Email are required before testing.' });
      return;
    }
    try {
      await verifySmtpConnection({
        host: creds.host,
        port: creds.port,
        secure: creds.secure,
        username: creds.username,
        password: creds.password,
      });
      writeSmtpCredentials({
        ...creds,
        connectionVerified: true,
        lastVerifiedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      res.json({ verified: true, status: getPublicSmtpStatus() });
    } catch (err) {
      writeSmtpCredentials({
        ...creds,
        connectionVerified: false,
        enabled: false,
        updatedAt: new Date().toISOString(),
      });
      const msg = err instanceof Error ? err.message : 'SMTP verification failed';
      appendServerErrorLog('email', 'SMTP connection verification failed', msg);
      res.status(400).json({ error: msg, status: getPublicSmtpStatus() });
    }
  });

  app.post('/api/admin/email/toggle', attachOptionalFirebaseUser, (req, res) => {
    const { enabled } = (req.body || {}) as { enabled?: boolean };
    const creds = readSmtpCredentials();
    if (enabled) {
      if (!creds.host || !creds.fromEmail) {
        res.status(400).json({ error: 'Configure SMTP Host and From Email first.' });
        return;
      }
      if (!creds.connectionVerified) {
        res.status(400).json({ error: 'Test & verify the SMTP connection before enabling.' });
        return;
      }
    }
    writeSmtpCredentials({
      ...creds,
      enabled: Boolean(enabled),
      updatedAt: new Date().toISOString(),
    });
    res.json(getPublicSmtpStatus());
  });

  app.post('/api/admin/email/clear', attachOptionalFirebaseUser, (_req, res) => {
    writeSmtpCredentials({
      preset: 'custom',
      host: '',
      port: 587,
      secure: false,
      username: '',
      password: '',
      fromName: 'FreskaAssist',
      fromEmail: '',
      replyTo: '',
      publicPortalUrl: '',
      enabled: false,
      connectionVerified: false,
      lastVerifiedAt: null,
      updatedAt: new Date().toISOString(),
    });
    res.json(getPublicSmtpStatus());
  });

  // --- Email Sending Route (Verified SMTP Relay OR Gmail API OAuth) ---
  app.post('/api/admin/gmail/send', attachOptionalFirebaseUser, async (req: AuthedRequest, res) => {
    const {
      to,
      subject,
      bodyText,
      senderDisplayName,
      senderEmail,
      senderGoogleName,
      invoicePayload,
    } = req.body as {
      to: string;
      subject: string;
      bodyText: string;
      senderDisplayName?: string;
      senderEmail?: string;
      senderGoogleName?: string;
      invoicePayload?: InvoicePdfPayload;
    };

    if (!to || !subject || !bodyText) {
      res.status(400).json({ error: 'Recipient, subject, and message body are required.' });
      return;
    }

    const smtpCreds = readSmtpCredentials();
    const useSmtp = Boolean(
      smtpCreds.enabled && smtpCreds.connectionVerified && smtpCreds.host && smtpCreds.fromEmail
    );

    const authHeader = req.header('Authorization');
    const gmailToken =
      authHeader && authHeader.startsWith('Bearer ')
        ? authHeader.slice('Bearer '.length).trim()
        : '';

    if (!useSmtp && !gmailToken) {
      res.status(401).json({
        error:
          'No active email sender. Either enable Verified SMTP Relay or connect your Google Account in Email Integration.',
      });
      return;
    }

    try {
      let attachment:
        | { filename: string; mimeType: string; contentBuffer: Buffer }
        | undefined;

      if (invoicePayload) {
        const pdfBuffer = await generateInvoicePdfBuffer(invoicePayload);
        attachment = {
          filename: `FreskaAssist-${invoicePayload.invoiceNumber}.pdf`,
          mimeType: 'application/pdf',
          contentBuffer: pdfBuffer,
        };
      }

      if (useSmtp) {
        const result = await sendEmailViaSmtp({
          smtp: {
            host: smtpCreds.host,
            port: smtpCreds.port,
            secure: smtpCreds.secure,
            username: smtpCreds.username,
            password: smtpCreds.password,
          },
          fromName: smtpCreds.fromName || senderDisplayName || 'FreskaAssist',
          fromEmail: smtpCreds.fromEmail,
          replyTo: smtpCreds.replyTo || undefined,
          to,
          subject,
          bodyText,
          attachment,
        });
        res.json({
          sent: true,
          messageId: result.messageId,
          fromEmail: smtpCreds.fromEmail,
          transport: 'smtp',
        });
        return;
      }

      // Verify the actual connected Google account email and name from the OAuth token
      let resolvedFromEmail = senderEmail || req.adminUser?.email || '';
      let resolvedGoogleName = '';
      try {
        const userinfoRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
          headers: { Authorization: `Bearer ${gmailToken}` },
        });
        if (userinfoRes.ok) {
          const info = (await userinfoRes.json()) as { email?: string; name?: string };
          if (info.email) resolvedFromEmail = info.email;
          if (info.name) resolvedGoogleName = info.name;
        }
      } catch {
        // Fallback to provided senderEmail
      }

      if (!resolvedFromEmail) {
        resolvedFromEmail = 'me';
      }

      const isConsumerGmail =
        resolvedFromEmail.toLowerCase().endsWith('@gmail.com') ||
        resolvedFromEmail.toLowerCase().endsWith('@googlemail.com');
      const verifiedAccountName = resolvedGoogleName || senderGoogleName || '';
      const effectiveFromName = isConsumerGmail
        ? verifiedAccountName
        : senderDisplayName || verifiedAccountName || 'FreskaAssist';

      const result = await sendEmailViaGmailApi({
        accessToken: gmailToken,
        fromName: effectiveFromName,
        fromEmail: resolvedFromEmail,
        to,
        subject,
        bodyText,
        attachment,
      });

      res.json({
        sent: true,
        messageId: result.messageId,
        fromEmail: resolvedFromEmail,
        transport: 'gmail_api',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Email dispatch failed';
      appendServerErrorLog('gmail', `Failed to send email to ${to}`, msg);
      res.status(502).json({ error: msg });
    }
  });

  // --- 24-Hour Gmail Security Verification Code (OTP) ---
  app.get('/api/admin/security/status', attachOptionalFirebaseUser, (req: AuthedRequest, res) => {
    const email = req.adminUser?.email || String(req.query.email || '');
    const token = req.header('X-Freska-Security-Token') || '';
    const status = getSecuritySessionStatus(email, token);
    res.json({
      ...status,
      maskedEmail: email ? maskEmailAddress(email) : '',
    });
  });

  app.post(
    '/api/admin/security/send-code',
    attachOptionalFirebaseUser,
    async (req: AuthedRequest, res) => {
      const body = (req.body || {}) as {
        email?: string;
        senderGoogleName?: string;
      };
      const email = (req.adminUser?.email || body.email || '').trim();
      if (!email || !email.includes('@')) {
        res.status(400).json({ error: 'A valid Google account email is required.' });
        return;
      }

      const smtpCreds = readSmtpCredentials();
      const useSmtp = Boolean(
        smtpCreds.enabled && smtpCreds.connectionVerified && smtpCreds.host && smtpCreds.fromEmail
      );
      const authHeader = req.header('Authorization');
      const gmailToken =
        authHeader && authHeader.startsWith('Bearer ')
          ? authHeader.slice('Bearer '.length).trim()
          : '';

      if (!useSmtp && !gmailToken) {
        res.json({
          sent: false,
          requiresGmailAuth: true,
          maskedEmail: maskEmailAddress(email),
          message:
            'Authorize Gmail access once so FreskaAssist can deliver your 6-digit security code.',
        });
        return;
      }

      const prep = prepareOtpChallenge(email);
      if (!prep.ok) {
        res.json({
          sent: true,
          reusedActiveChallenge: true,
          cooldownSeconds: prep.cooldownSeconds,
          expiresInSeconds: prep.expiresInSeconds,
          maskedEmail: maskEmailAddress(email),
          deliveryMethod: useSmtp ? 'smtp' : 'gmail_api',
        });
        return;
      }

      const subject = `FreskaAssist security code: ${prep.code}`;
      const bodyText = [
        `Your FreskaAssist security code is: ${prep.code}`,
        '',
        'Enter this 6-digit code to unlock your FreskaAssist workspace for 24 hours.',
        'This code expires in 10 minutes.',
        '',
        'If you did not request this sign-in, you can safely ignore this message.',
      ].join('\n');

      try {
        if (useSmtp) {
          await sendEmailViaSmtp({
            smtp: {
              host: smtpCreds.host,
              port: smtpCreds.port,
              secure: smtpCreds.secure,
              username: smtpCreds.username,
              password: smtpCreds.password,
            },
            fromName: smtpCreds.fromName || 'FreskaAssist Security',
            fromEmail: smtpCreds.fromEmail,
            replyTo: smtpCreds.replyTo || undefined,
            to: email,
            subject,
            bodyText,
          });
          res.json({
            sent: true,
            reusedActiveChallenge: false,
            cooldownSeconds: prep.cooldownSeconds,
            expiresInSeconds: prep.expiresInSeconds,
            maskedEmail: maskEmailAddress(email),
            deliveryMethod: 'smtp',
          });
          return;
        }

        let resolvedFromEmail = email;
        let resolvedGoogleName = body.senderGoogleName || '';
        try {
          const userinfoRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
            headers: { Authorization: `Bearer ${gmailToken}` },
          });
          if (userinfoRes.ok) {
            const info = (await userinfoRes.json()) as { email?: string; name?: string };
            if (info.email) resolvedFromEmail = info.email;
            if (info.name) resolvedGoogleName = info.name;
          }
        } catch {
          // Use known Google account email
        }

        await sendEmailViaGmailApi({
          accessToken: gmailToken,
          fromName: resolvedGoogleName || 'FreskaAssist',
          fromEmail: resolvedFromEmail || 'me',
          to: email,
          subject,
          bodyText,
        });

        res.json({
          sent: true,
          reusedActiveChallenge: false,
          cooldownSeconds: prep.cooldownSeconds,
          expiresInSeconds: prep.expiresInSeconds,
          maskedEmail: maskEmailAddress(email),
          deliveryMethod: 'gmail_api',
        });
      } catch (err) {
        clearOtpChallenge(email);
        const msg = err instanceof Error ? err.message : 'Failed to deliver security code';
        appendServerErrorLog('security-otp', `Failed to send 24h security code to ${email}`, msg);
        const isAuthErr = /401|403|invalid authentication|unauthorized|token|credential/i.test(msg);
        if (isAuthErr && !useSmtp) {
          res.json({
            sent: false,
            requiresGmailAuth: true,
            maskedEmail: maskEmailAddress(email),
            message: 'Gmail authorization expired. Re-authorize Gmail to receive your security code.',
          });
          return;
        }
        res.status(502).json({ error: msg });
      }
    }
  );

  app.post('/api/admin/security/verify-code', attachOptionalFirebaseUser, (req: AuthedRequest, res) => {
    const body = (req.body || {}) as { email?: string; code?: string };
    const email = (req.adminUser?.email || body.email || '').trim();
    const code = String(body.code || '');
    if (!email) {
      res.status(400).json({ error: 'Google account email is required.' });
      return;
    }

    const result = verifyOtpChallenge(email, code);
    if (!result.ok) {
      res.status(400).json({
        error: result.error,
        attemptsRemaining: result.attemptsRemaining,
      });
      return;
    }

    res.json({
      verified: true,
      securityToken: result.securityToken,
      status: result.status,
    });
  });

  app.post('/api/admin/security/lock', attachOptionalFirebaseUser, (req: AuthedRequest, res) => {
    const body = (req.body || {}) as { email?: string };
    const email = (req.adminUser?.email || body.email || '').trim();
    const token = req.header('X-Freska-Security-Token') || '';
    revokeSecuritySession(email, token);
    res.json({ locked: true });
  });

  app.post('/api/admin/security/settings', attachOptionalFirebaseUser, (req, res) => {
    const { require24hOtp } = (req.body || {}) as { require24hOtp?: boolean };
    if (typeof require24hOtp !== 'boolean') {
      res.status(400).json({ error: 'Boolean "require24hOtp" is required.' });
      return;
    }
    const saved = setRequire24hOtpSetting(require24hOtp);
    res.json({ require24hOtp: saved });
  });

  // --- Webhook Sync & Server Logs ---
  app.get('/api/admin/webhooks/pending', attachOptionalFirebaseUser, (_req, res) => {
    res.json({ events: getPendingWebhookEvents() });
  });

  app.post('/api/admin/webhooks/ack', attachOptionalFirebaseUser, (req, res) => {
    const { externalEventId } = req.body as { externalEventId?: string };
    if (externalEventId) markWebhookEventSynced(externalEventId);
    res.json({ ok: true });
  });

  app.get('/api/admin/logs', attachOptionalFirebaseUser, (_req, res) => {
    res.json({
      logs: readServerErrorLogs(),
      cron: {
        timezone: cronTimezone,
        schedule: '0 9 * * *',
        lastRunAt: lastCronRunAt,
      },
    });
  });

  app.post('/api/admin/cron/config', attachOptionalFirebaseUser, (req, res) => {
    const { timezone } = req.body as { timezone?: string };
    if (timezone) {
      startDailyReminderCron(timezone);
    }
    res.json({ timezone: cronTimezone, schedule: '0 9 * * *', lastRunAt: lastCronRunAt });
  });

  // --- Admin Integration API Key Management ---
  app.get('/api/admin/api-keys', attachOptionalFirebaseUser, (req: AuthedRequest, res) => {
    const uid = req.adminUser?.uid;
    if (!uid && req.authTokenError) {
      res.status(401).json({
        error: 'Firebase session token expired or invalid. Refreshing authentication...',
      });
      return;
    }
    const email = req.adminUser?.email;
    res.json({
      keys: listApiKeysForAccount(uid, email),
      activity: readApiActivityForAccount(uid, email),
      availableScopes: ALL_API_SCOPES,
    });
  });

  app.post('/api/admin/api-keys', attachOptionalFirebaseUser, (req: AuthedRequest, res) => {
    try {
      const uid = req.adminUser?.uid;
      if (!uid) {
        res.status(401).json({ error: 'Connect your Google Account to create API keys.' });
        return;
      }
      const { name, scopes } = (req.body || {}) as {
        name?: string;
        scopes?: unknown;
      };
      if (!name || typeof name !== 'string' || !name.trim()) {
        res.status(400).json({ error: 'API key name is required.' });
        return;
      }
      const created = createApiKey(name, scopes, {
        uid,
        email: req.adminUser?.email,
      });
      res.status(201).json({
        key: created.record,
        plaintextKey: created.plaintextKey,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to create API key';
      appendServerErrorLog('api-keys', 'API key creation failed', msg);
      res.status(500).json({ error: msg });
    }
  });

  app.patch('/api/admin/api-keys/:id', attachOptionalFirebaseUser, (req: AuthedRequest, res) => {
    const uid = req.adminUser?.uid;
    if (!uid) {
      res.status(401).json({ error: 'Connect your Google Account to manage API keys.' });
      return;
    }
    const { id } = req.params;
    const { active } = (req.body || {}) as { active?: boolean };
    if (typeof active !== 'boolean') {
      res.status(400).json({ error: 'Boolean "active" field is required.' });
      return;
    }
    const updated = toggleApiKeyActive(id, active, uid, req.adminUser?.email);
    if (!updated) {
      res.status(404).json({ error: 'API key not found.' });
      return;
    }
    res.json({ key: updated });
  });

  app.delete('/api/admin/api-keys/:id', attachOptionalFirebaseUser, (req: AuthedRequest, res) => {
    const uid = req.adminUser?.uid;
    if (!uid) {
      res.status(401).json({ error: 'Connect your Google Account to delete API keys.' });
      return;
    }
    const { id } = req.params;
    const deleted = deleteApiKey(id, uid, req.adminUser?.email);
    if (!deleted) {
      res.status(404).json({ error: 'API key not found.' });
      return;
    }
    res.json({ ok: true });
  });

  // --- External Website Integration REST API (/api/v1/*) ---
  app.use('/api/v1', (req: Request, res: Response, next: NextFunction) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key');
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });

  function resolveApiOwnerUid(keyRecord?: PublicApiKeyRecord): string | null {
    if (!keyRecord) return null;
    if (keyRecord.ownerUid) return keyRecord.ownerUid;
    if (keyRecord.ownerEmail) {
      return resolveAccountUidByEmail(keyRecord.ownerEmail);
    }
    return resolveAccountUidByEmail('zwizoo175@gmail.com');
  }

  function requireApiKey(requiredScope?: ApiKeyScope) {
    return (req: AuthedRequest, res: Response, next: NextFunction) => {
      const xApiKey = req.header('X-API-Key');
      const authHeader = req.header('Authorization');
      const bearerKey =
        authHeader && authHeader.toLowerCase().startsWith('bearer ')
          ? authHeader.slice(7).trim()
          : '';
      const rawKey = (xApiKey || bearerKey || '').trim();

      if (!rawKey) {
        res.status(401).json({
          error: 'Missing API key. Pass X-API-Key or Authorization: Bearer <api_key>.',
        });
        return;
      }

      const keyRecord = verifyApiKeyToken(rawKey);
      if (!keyRecord) {
        res.status(401).json({ error: 'Invalid or disabled API key.' });
        return;
      }

      const resolvedOwnerUid = resolveApiOwnerUid(keyRecord);

      if (requiredScope && !keyRecord.scopes.includes(requiredScope)) {
        recordApiActivity({
          keyId: keyRecord.id,
          keyName: keyRecord.name,
          ownerUid: resolvedOwnerUid || undefined,
          method: req.method,
          path: req.originalUrl,
          statusCode: 403,
        });
        res.status(403).json({
          error: `API key lacks required permission scope: ${requiredScope}`,
        });
        return;
      }

      req.apiKeyRecord = keyRecord;
      res.on('finish', () => {
        recordApiActivity({
          keyId: keyRecord.id,
          keyName: keyRecord.name,
          ownerUid: resolvedOwnerUid || undefined,
          method: req.method,
          path: req.originalUrl,
          statusCode: res.statusCode,
        });
      });
      next();
    };
  }

  app.get('/api/v1/me', requireApiKey(), (req: AuthedRequest, res) => {
    const ownerUid = resolveApiOwnerUid(req.apiKeyRecord);
    const store = readAccountStore(ownerUid);
    const sysSettings =
      store.system_settings?.default || Object.values(store.system_settings || {})[0] || {};
    res.json({
      ok: true,
      workspace: {
        businessName: String(sysSettings.businessName || 'FreskaAssist'),
        defaultCurrency: String(sysSettings.defaultCurrency || 'EUR'),
        invoicePrefix: String(sysSettings.invoicePrefix || 'FA'),
      },
      apiKey: req.apiKeyRecord,
    });
  });

  app.get('/api/v1/services', requireApiKey('services:read'), (req: AuthedRequest, res) => {
    const ownerUid = resolveApiOwnerUid(req.apiKeyRecord);
    const store = readAccountStore(ownerUid);
    const services = Object.values(store.services || {}).filter((s) => s.active !== false);
    res.json({ services });
  });

  app.get('/api/v1/clients', requireApiKey('clients:read'), (req: AuthedRequest, res) => {
    const ownerUid = resolveApiOwnerUid(req.apiKeyRecord);
    const store = readAccountStore(ownerUid);
    const emailQuery = typeof req.query.email === 'string' ? req.query.email.trim().toLowerCase() : '';
    const searchQuery =
      typeof req.query.search === 'string' ? req.query.search.trim().toLowerCase() : '';

    let clients = Object.values(store.clients || {});
    if (emailQuery) {
      clients = clients.filter((c) => String(c.email || '').toLowerCase() === emailQuery);
    } else if (searchQuery) {
      clients = clients.filter(
        (c) =>
          String(c.fullName || '').toLowerCase().includes(searchQuery) ||
          String(c.businessName || '').toLowerCase().includes(searchQuery) ||
          String(c.email || '').toLowerCase().includes(searchQuery) ||
          String(c.clientCode || '').toLowerCase().includes(searchQuery)
      );
    }
    res.json({ clients });
  });

  app.post('/api/v1/clients', requireApiKey('clients:write'), (req: AuthedRequest, res) => {
    try {
      const ownerUid = resolveApiOwnerUid(req.apiKeyRecord);
      if (!ownerUid) {
        res.status(409).json({
          error: 'API key owner Google Account has not signed in yet. Connect Google Account once first.',
        });
        return;
      }

      const body = (req.body || {}) as {
        fullName?: string;
        businessName?: string;
        email?: string;
        phone?: string;
        businessType?: string;
        notes?: string;
        preferredCurrency?: string;
        preferredPaymentMethod?: 'bank_transfer' | 'manual' | 'card';
      };

      const email = typeof body.email === 'string' ? body.email.trim() : '';
      const fullName = typeof body.fullName === 'string' ? body.fullName.trim() : '';
      if (!email || !email.includes('@')) {
        res.status(400).json({ error: 'Valid client email address is required.' });
        return;
      }
      if (!fullName) {
        res.status(400).json({ error: 'Client fullName is required.' });
        return;
      }

      const store = readAccountStore(ownerUid);
      const existing = Object.values(store.clients || {}).find(
        (c) => String(c.email || '').toLowerCase() === email.toLowerCase()
      );

      if (existing) {
        const updated = upsertAccountDocument(ownerUid, 'clients', String(existing.id), {
          fullName: fullName || existing.fullName,
          businessName: body.businessName?.trim() || existing.businessName || fullName,
          phone: body.phone !== undefined ? body.phone.trim() : existing.phone,
          businessType:
            body.businessType !== undefined ? body.businessType.trim() : existing.businessType,
          notes: body.notes !== undefined ? body.notes.trim() : existing.notes,
          _cloudSynced: false,
        });
        res.json({ client: updated, created: false });
        return;
      }

      const sysSettings =
        store.system_settings?.default || Object.values(store.system_settings || {})[0] || {};
      const clientId = `cli_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const clientCode = `FA-CL-${Math.floor(1000 + Math.random() * 9000)}`;
      const saved = upsertAccountDocument(ownerUid, 'clients', clientId, {
        id: clientId,
        clientCode,
        fullName,
        businessName: body.businessName?.trim() || fullName,
        email,
        phone: body.phone?.trim() || '',
        businessType: body.businessType?.trim() || '',
        servicesPurchased: [],
        notes: body.notes?.trim() || '',
        status: 'active',
        preferredCurrency:
          body.preferredCurrency?.trim().toUpperCase() ||
          String(sysSettings.defaultCurrency || 'EUR'),
        preferredPaymentMethod: body.preferredPaymentMethod || 'bank_transfer',
        _cloudSynced: false,
      });

      res.status(201).json({ client: saved, created: true });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to create client via API';
      res.status(500).json({ error: msg });
    }
  });

  app.get('/api/v1/subscriptions', requireApiKey('subscriptions:read'), (req: AuthedRequest, res) => {
    const ownerUid = resolveApiOwnerUid(req.apiKeyRecord);
    const store = readAccountStore(ownerUid);
    const clientId = typeof req.query.clientId === 'string' ? req.query.clientId.trim() : '';
    let subscriptions = Object.values(store.subscriptions || {});
    if (clientId) {
      subscriptions = subscriptions.filter((s) => s.clientId === clientId);
    }
    res.json({ subscriptions });
  });

  app.post('/api/v1/subscriptions', requireApiKey('subscriptions:write'), (req: AuthedRequest, res) => {
    try {
      const ownerUid = resolveApiOwnerUid(req.apiKeyRecord);
      if (!ownerUid) {
        res.status(409).json({
          error: 'API key owner Google Account has not signed in yet. Connect Google Account once first.',
        });
        return;
      }

      const body = (req.body || {}) as {
        clientId?: string;
        name?: string;
        description?: string;
        monthlyPrice?: number;
        currency?: string;
        billingFrequency?: 'monthly' | 'quarterly' | 'yearly';
        paymentMethod?: 'bank_transfer' | 'manual' | 'card';
      };

      const store = readAccountStore(ownerUid);
      const client = body.clientId ? store.clients?.[body.clientId] : null;
      if (!client) {
        res.status(404).json({ error: 'Valid clientId is required to create a subscription.' });
        return;
      }

      const sysSettings =
        store.system_settings?.default || Object.values(store.system_settings || {})[0] || {};
      const today = new Date().toISOString().slice(0, 10);
      const nextDateObj = new Date(`${today}T00:00:00Z`);
      const freq = body.billingFrequency || 'monthly';
      if (freq === 'quarterly') nextDateObj.setUTCMonth(nextDateObj.getUTCMonth() + 3);
      else if (freq === 'yearly') nextDateObj.setUTCFullYear(nextDateObj.getUTCFullYear() + 1);
      else nextDateObj.setUTCMonth(nextDateObj.getUTCMonth() + 1);

      const price =
        typeof body.monthlyPrice === 'number' && body.monthlyPrice > 0 ? body.monthlyPrice : 599;
      const subId = `sub_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const saved = upsertAccountDocument(ownerUid, 'subscriptions', subId, {
        id: subId,
        clientId: client.id,
        serviceId: 'svc_sub_599',
        name: body.name?.trim() || 'Subscription Plan',
        description: body.description?.trim() || 'Recurring monthly subscription package (599€ / month)',
        monthlyPrice: price,
        currency:
          body.currency?.trim().toUpperCase() ||
          String(client.preferredCurrency || sysSettings.defaultCurrency || 'EUR'),
        startDate: today,
        nextPaymentDate: nextDateObj.toISOString().slice(0, 10),
        billingFrequency: freq,
        paymentMethod: body.paymentMethod || 'bank_transfer',
        status: 'active',
        reminderEnabled: true,
        autoRenew: false,
        _cloudSynced: false,
      });

      res.status(201).json({ subscription: saved, client });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to create subscription';
      res.status(500).json({ error: msg });
    }
  });

  app.get('/api/v1/payment-links', requireApiKey('payments:read'), (req: AuthedRequest, res) => {
    const ownerUid = resolveApiOwnerUid(req.apiKeyRecord);
    const store = readAccountStore(ownerUid);
    const clientId = typeof req.query.clientId === 'string' ? req.query.clientId.trim() : '';
    const status = typeof req.query.status === 'string' ? req.query.status.trim() : '';

    let requests = Object.values(store.payment_requests || {}).map((r) => {
      const snap = readBankInstructionSnapshot(String(r.id));
      if (snap && snap.status === 'paid' && r.status !== 'paid') {
        return {
          ...r,
          status: 'paid',
          paidAt: snap.paidAt,
          paidMethod: snap.paidMethod,
          transactionReference: snap.transactionReference,
          testMode: snap.testMode,
        };
      }
      return r;
    });

    if (clientId) requests = requests.filter((r) => r.clientId === clientId);
    if (status) requests = requests.filter((r) => r.status === status);
    res.json({ paymentLinks: requests });
  });

  app.get('/api/v1/payment-links/:requestId', requireApiKey('payments:read'), (req: AuthedRequest, res) => {
    const { requestId } = req.params;
    const ownerUid = resolveApiOwnerUid(req.apiKeyRecord);
    const store = readAccountStore(ownerUid);
    const reqDoc = store.payment_requests?.[requestId];
    const snap = readBankInstructionSnapshot(requestId);
    if (!reqDoc && !snap) {
      res.status(404).json({ error: 'Payment link not found.' });
      return;
    }

    const effectiveStatus = snap?.status === 'paid' ? 'paid' : String(reqDoc?.status || snap?.status || 'pending');
    res.json({
      paymentLink: {
        ...(reqDoc || {}),
        id: requestId,
        status: effectiveStatus,
        paidAt: snap?.paidAt || reqDoc?.paidAt || null,
        paidMethod: snap?.paidMethod || null,
        transactionReference: snap?.transactionReference || null,
        testMode: Boolean(snap?.testMode),
      },
    });
  });

  app.post('/api/v1/payment-links', requireApiKey('payments:write'), (req: AuthedRequest, res) => {
    try {
      const ownerUid = resolveApiOwnerUid(req.apiKeyRecord);
      if (!ownerUid) {
        res.status(409).json({
          error: 'API key owner Google Account has not signed in yet. Connect Google Account once first.',
        });
        return;
      }

      const body = (req.body || {}) as {
        clientId?: string;
        client?: {
          fullName?: string;
          businessName?: string;
          email?: string;
          phone?: string;
        };
        subscriptionId?: string;
        billingType?: 'subscription' | 'one_time';
        serviceName?: string;
        description?: string;
        amount?: number;
        currency?: string;
        dueDate?: string;
      };

      const store = readAccountStore(ownerUid);
      const sysSettings =
        store.system_settings?.default || Object.values(store.system_settings || {})[0] || {};
      const gwSettings =
        store.payment_gateway_settings?.default ||
        Object.values(store.payment_gateway_settings || {})[0] ||
        {};

      let client: Record<string, unknown> | undefined = body.clientId
        ? store.clients?.[body.clientId]
        : undefined;

      if (!client && body.client?.email) {
        const targetEmail = body.client.email.trim().toLowerCase();
        client = Object.values(store.clients || {}).find(
          (c) => String(c.email || '').toLowerCase() === targetEmail
        );
        if (!client) {
          const fullName = body.client.fullName?.trim() || targetEmail.split('@')[0];
          const newClientId = `cli_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
          client = upsertAccountDocument(ownerUid, 'clients', newClientId, {
            id: newClientId,
            clientCode: `FA-CL-${Math.floor(1000 + Math.random() * 9000)}`,
            fullName,
            businessName: body.client.businessName?.trim() || fullName,
            email: body.client.email.trim(),
            phone: body.client.phone?.trim() || '',
            businessType: '',
            servicesPurchased: [],
            notes: 'Created automatically via API integration',
            status: 'active',
            preferredCurrency:
              body.currency?.trim().toUpperCase() ||
              String(sysSettings.defaultCurrency || 'EUR'),
            preferredPaymentMethod: 'bank_transfer',
            _cloudSynced: false,
          });
        }
      }

      if (!client) {
        res.status(400).json({
          error: 'Provide either a valid clientId or a client object with { email, fullName }.',
        });
        return;
      }

      const billingType: 'subscription' | 'one_time' =
        body.billingType === 'subscription' ? 'subscription' : 'one_time';
      const defaultAmount = billingType === 'subscription' ? 599 : 1199;
      const amount =
        typeof body.amount === 'number' && !Number.isNaN(body.amount) && body.amount > 0
          ? Number(body.amount)
          : defaultAmount;
      const currency =
        body.currency?.trim().toUpperCase() ||
        String(client.preferredCurrency || sysSettings.defaultCurrency || 'EUR');
      const serviceName =
        body.serviceName?.trim() ||
        (billingType === 'subscription' ? 'Subscription Plan' : 'One-Time Payment Plan');
      const description =
        body.description?.trim() ||
        (billingType === 'subscription'
          ? `Recurring monthly subscription package (${amount} ${currency}/mo)`
          : `Single one-time payment package (${amount} ${currency})`);

      const today = new Date();
      const defaultDue = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000)
        .toISOString()
        .slice(0, 10);
      const dueDate = body.dueDate?.trim() || defaultDue;

      const requestId = `req_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const reference = `FA-REF-${Math.floor(100000 + Math.random() * 900000)}`;

      saveBankInstructionSnapshot({
        requestId,
        reference,
        clientId: String(client.id),
        subscriptionId: body.subscriptionId || '',
        billingType,
        clientName: String(client.fullName || ''),
        businessName: String(client.businessName || client.fullName || ''),
        serviceName,
        description,
        amount,
        currency,
        dueDate,
        status: 'pending',
        bankAccountName: String(gwSettings.bankAccountName || ''),
        bankName: String(gwSettings.bankName || ''),
        bankIban: String(gwSettings.bankIban || ''),
        bankBic: String(gwSettings.bankBic || ''),
        bankInstructions: String(gwSettings.bankInstructions || ''),
        companyName: String(sysSettings.businessName || 'FreskaAssist'),
        updatedAt: new Date().toISOString(),
      });

      const sig = signToken(`bank:${requestId}`);
      const baseUrl = getBaseUrl(req);
      const paymentUrl = `${baseUrl}/?bank_request=${encodeURIComponent(requestId)}&sig=${sig}`;

      const savedRequest = upsertAccountDocument(ownerUid, 'payment_requests', requestId, {
        id: requestId,
        clientId: String(client.id),
        subscriptionId: body.subscriptionId || '',
        serviceId: billingType === 'subscription' ? 'svc_sub_599' : 'svc_onetime_1199',
        serviceName,
        description,
        billingType,
        paymentMethod: 'bank_transfer',
        reference,
        amount,
        currency,
        dueDate,
        paymentUrl,
        gatewaySessionId: '',
        status: 'pending',
        _cloudSynced: false,
      });

      res.status(201).json({
        paymentLink: savedRequest,
        client,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to create payment link';
      appendServerErrorLog('api-v1', 'Failed to create payment link via API', msg);
      res.status(500).json({ error: msg });
    }
  });

  app.get('/api/v1/invoices', requireApiKey('invoices:read'), (req: AuthedRequest, res) => {
    const ownerUid = resolveApiOwnerUid(req.apiKeyRecord);
    const store = readAccountStore(ownerUid);
    const clientId = typeof req.query.clientId === 'string' ? req.query.clientId.trim() : '';
    const baseUrl = getBaseUrl(req);
    let invoices = Object.values(store.invoices || {});
    if (clientId) invoices = invoices.filter((inv) => inv.clientId === clientId);
    const enriched = invoices.map((inv) => {
      const invId = String(inv.id);
      const sig = signToken(`invoice:${invId}`);
      return {
        ...inv,
        downloadUrl: `${baseUrl}/api/public/invoice/${encodeURIComponent(invId)}?sig=${sig}`,
      };
    });
    res.json({ invoices: enriched });
  });

  app.get('/api/v1/payments', requireApiKey('payments:read'), (req: AuthedRequest, res) => {
    const ownerUid = resolveApiOwnerUid(req.apiKeyRecord);
    const store = readAccountStore(ownerUid);
    const clientId = typeof req.query.clientId === 'string' ? req.query.clientId.trim() : '';
    let payments = Object.values(store.payments || {});
    if (clientId) payments = payments.filter((p) => p.clientId === clientId);
    res.json({ payments });
  });

  // --- Vite / Static SPA Middleware ---
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output not found.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`FreskaAssist server running on http://0.0.0.0:${PORT}`);
  });
}

createServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
