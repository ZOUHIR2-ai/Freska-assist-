import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  KeyRound,
  Plus,
  Copy,
  Check,
  Trash2,
  Power,
  RefreshCw,
  ShieldCheck,
  Terminal,
  Play,
  AlertCircle,
} from 'lucide-react';
import {
  ApiActivityEntry,
  IntegrationApiKeyRecord,
  IntegrationApiScope,
  createIntegrationApiKey,
  deleteIntegrationApiKey,
  fetchApiKeys,
  toggleIntegrationApiKey,
} from '../lib/api.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import { ConfirmDialog } from './ConfirmDialog.tsx';

const ALL_SCOPES: Array<{ scope: IntegrationApiScope; label: string }> = [
  { scope: 'clients:read', label: 'Clients (Read)' },
  { scope: 'clients:write', label: 'Clients (Create/Update)' },
  { scope: 'payments:read', label: 'Payment Links & Payments (Read)' },
  { scope: 'payments:write', label: 'Payment Links (Create)' },
  { scope: 'subscriptions:read', label: 'Subscriptions (Read)' },
  { scope: 'subscriptions:write', label: 'Subscriptions (Create)' },
  { scope: 'invoices:read', label: 'Invoices & PDF Links (Read)' },
  { scope: 'services:read', label: 'Service Packages (Read)' },
];

const SCOPE_PRESETS: Record<'full' | 'checkout' | 'readonly', IntegrationApiScope[]> = {
  full: ALL_SCOPES.map((s) => s.scope),
  checkout: ['clients:read', 'clients:write', 'payments:read', 'payments:write', 'services:read'],
  readonly: ['clients:read', 'payments:read', 'subscriptions:read', 'invoices:read', 'services:read'],
};

export const ApiKeysPanel: React.FC = () => {
  const { notify } = useFreska();

  const [keys, setKeys] = useState<IntegrationApiKeyRecord[]>([]);
  const [activity, setActivity] = useState<ApiActivityEntry[]>([]);
  const [loading, setLoading] = useState(true);

  const [newKeyName, setNewKeyName] = useState('');
  const [selectedScopes, setSelectedScopes] = useState<IntegrationApiScope[]>(SCOPE_PRESETS.full);
  const [creating, setCreating] = useState(false);

  const [revealedSecret, setRevealedSecret] = useState<{
    name: string;
    key: string;
  } | null>(null);
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedBaseUrl, setCopiedBaseUrl] = useState(false);
  const [copiedSnippet, setCopiedSnippet] = useState(false);

  const [snippetTab, setSnippetTab] = useState<'js' | 'curl' | 'endpoints'>('js');
  const [testKeyInput, setTestKeyInput] = useState('');
  const [testingKey, setTestingKey] = useState(false);
  const [testResult, setTestResult] = useState<{
    ok: boolean;
    status: number;
    body: string;
  } | null>(null);

  const [revokeTarget, setRevokeTarget] = useState<IntegrationApiKeyRecord | null>(null);
  const [revoking, setRevoking] = useState(false);

  const baseUrl = useMemo(() => {
    if (typeof window === 'undefined') return 'http://localhost:3000';
    return window.location.origin;
  }, []);

  const loadKeys = useCallback(async () => {
    try {
      const data = await fetchApiKeys();
      setKeys(data.keys || []);
      setActivity(data.activity || []);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to load API keys');
    } finally {
      setLoading(false);
    }
  }, [notify]);

  useEffect(() => {
    loadKeys();
  }, [loadKeys]);

  const applyPreset = (preset: 'full' | 'checkout' | 'readonly') => {
    setSelectedScopes([...SCOPE_PRESETS[preset]]);
  };

  const toggleScope = (scope: IntegrationApiScope) => {
    setSelectedScopes((prev) =>
      prev.includes(scope) ? prev.filter((s) => s !== scope) : [...prev, scope]
    );
  };

  const handleCreateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyName.trim()) {
      notify('error', 'Enter a descriptive name for this API key.');
      return;
    }
    if (selectedScopes.length === 0) {
      notify('error', 'Select at least one permission scope.');
      return;
    }
    setCreating(true);
    try {
      const res = await createIntegrationApiKey({
        name: newKeyName.trim(),
        scopes: selectedScopes,
      });
      setRevealedSecret({ name: res.key.name, key: res.plaintextKey });
      setTestKeyInput(res.plaintextKey);
      setNewKeyName('');
      await loadKeys();
      notify('success', `API key "${res.key.name}" created. Copy your secret key now.`);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to create API key');
    } finally {
      setCreating(false);
    }
  };

  const handleToggleActive = async (item: IntegrationApiKeyRecord) => {
    try {
      await toggleIntegrationApiKey(item.id, !item.active);
      await loadKeys();
      notify(
        'info',
        `API key "${item.name}" is now ${!item.active ? 'active' : 'disabled'}.`
      );
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to update API key');
    }
  };

  const handleConfirmRevoke = async () => {
    if (!revokeTarget) return;
    setRevoking(true);
    try {
      await deleteIntegrationApiKey(revokeTarget.id);
      if (revealedSecret && testKeyInput && revealedSecret.name === revokeTarget.name) {
        setRevealedSecret(null);
      }
      setRevokeTarget(null);
      await loadKeys();
      notify('success', 'API key permanently revoked.');
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to revoke API key');
    } finally {
      setRevoking(false);
    }
  };

  const copyText = async (
    value: string,
    setter: React.Dispatch<React.SetStateAction<boolean>>
  ) => {
    try {
      await navigator.clipboard.writeText(value);
      setter(true);
      setTimeout(() => setter(false), 2000);
    } catch {
      notify('error', 'Clipboard access blocked. Copy the value manually.');
    }
  };

  const handleTestKey = async () => {
    const keyToUse = testKeyInput.trim();
    if (!keyToUse) {
      notify('error', 'Paste an active API key first to run a live connection test.');
      return;
    }
    setTestingKey(true);
    setTestResult(null);
    try {
      const res = await fetch(`${baseUrl}/api/v1/me`, {
        headers: { 'X-API-Key': keyToUse },
      });
      const json = await res.json().catch(() => ({}));
      setTestResult({
        ok: res.ok,
        status: res.status,
        body: JSON.stringify(json, null, 2),
      });
      await loadKeys();
    } catch (err) {
      setTestResult({
        ok: false,
        status: 0,
        body: err instanceof Error ? err.message : 'Connection failed',
      });
    } finally {
      setTestingKey(false);
    }
  };

  const sampleKeyPlaceholder = revealedSecret?.key || 'fa_live_YOUR_API_KEY';

  const jsSnippet = `// Create a client & generate a unified Payment Link (Bank Transfer + Card Checkout)
const response = await fetch("${baseUrl}/api/v1/payment-links", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "X-API-Key": "${sampleKeyPlaceholder}"
  },
  body: JSON.stringify({
    client: {
      fullName: "Client Full Name",
      businessName: "Client Business SARL",
      email: "client@example.com"
    },
    billingType: "subscription", // "subscription" (599 EUR) or "one_time" (1199 EUR)
    amount: 599,
    currency: "EUR"
  })
});

const data = await response.json();
// Redirect your customer to data.paymentLink.paymentUrl
console.log(data.paymentLink.paymentUrl);`;

  const curlSnippet = `curl -X POST "${baseUrl}/api/v1/payment-links" \\
  -H "Content-Type: application/json" \\
  -H "X-API-Key: ${sampleKeyPlaceholder}" \\
  -d '{
    "client": {
      "fullName": "Client Full Name",
      "businessName": "Client Business SARL",
      "email": "client@example.com"
    },
    "billingType": "one_time",
    "amount": 1199,
    "currency": "EUR"
  }'`;

  return (
    <div className="space-y-6">
      {/* Revealed One-Time Secret Key Notice */}
      {revealedSecret && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-5 space-y-3">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-sm font-semibold text-emerald-950">
                  Secret API Key Ready — {revealedSecret.name}
                </h3>
                <p className="text-xs text-emerald-800 mt-0.5">
                  Copy and store this key in your external website&apos;s server environment. For
                  security, the full secret cannot be viewed again after you leave this screen.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setRevealedSecret(null)}
              className="text-xs font-medium text-emerald-800 hover:text-emerald-950 whitespace-nowrap"
            >
              Dismiss
            </button>
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <code className="flex-1 px-3 py-2 text-xs font-mono bg-white border border-emerald-300 rounded-lg text-slate-900 select-all break-all">
              {revealedSecret.key}
            </code>
            <button
              type="button"
              onClick={() => copyText(revealedSecret.key, setCopiedKey)}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg whitespace-nowrap shrink-0"
            >
              {copiedKey ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedKey ? 'Copied' : 'Copy Secret Key'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Generate New API Key Card */}
      <form
        onSubmit={handleCreateKey}
        className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-5"
      >
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5">
          <div>
            <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-slate-700" />
              <span>Generate External Integration API Key</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Connect external websites, landing pages, or checkout portals to FreskaAssist using
              authenticated REST endpoints.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => applyPreset('full')}
              className="px-2.5 py-1.5 min-h-[36px] sm:min-h-0 text-[11px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded"
            >
              Full Access
            </button>
            <button
              type="button"
              onClick={() => applyPreset('checkout')}
              className="px-2.5 py-1.5 min-h-[36px] sm:min-h-0 text-[11px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded"
            >
              Payment Links Only
            </button>
            <button
              type="button"
              onClick={() => applyPreset('readonly')}
              className="px-2.5 py-1.5 min-h-[36px] sm:min-h-0 text-[11px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded"
            >
              Read-Only
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 items-end">
          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Website / Integration Name
            </label>
            <input
              type="text"
              required
              value={newKeyName}
              onChange={(e) => setNewKeyName(e.target.value)}
              placeholder="e.g. Agency Landing Page, Client Portal, E-Commerce Store"
              className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg"
            />
          </div>
          <button
            type="submit"
            disabled={creating}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50 whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{creating ? 'Generating...' : 'Generate API Key'}</span>
          </button>
        </div>

        <div>
          <p className="text-xs font-medium text-slate-700 mb-2">Permission Scopes</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2">
            {ALL_SCOPES.map((item) => {
              const checked = selectedScopes.includes(item.scope);
              return (
                <label
                  key={item.scope}
                  className={`flex items-center gap-2 px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 rounded-lg border text-xs cursor-pointer transition-colors ${
                    checked
                      ? 'bg-slate-50 border-slate-400 text-slate-900 font-medium'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => toggleScope(item.scope)}
                    className="rounded border-slate-300 text-slate-900"
                  />
                  <span className="truncate">{item.label}</span>
                </label>
              );
            })}
          </div>
        </div>
      </form>

      {/* Active API Keys List */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-4 sm:px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <h2 className="text-sm font-semibold text-slate-900">Issued API Keys</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Keys authenticate requests via{' '}
              <code className="font-mono text-slate-700">X-API-Key</code> or{' '}
              <code className="font-mono text-slate-700">Authorization: Bearer</code>.
            </p>
          </div>
          <button
            type="button"
            onClick={loadKeys}
            className="inline-flex items-center gap-1.5 px-3 py-2 sm:py-1.5 min-h-[38px] sm:min-h-0 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 shrink-0"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>

        {loading ? (
          <div className="p-8 text-center text-xs text-slate-500">Loading API keys...</div>
        ) : keys.length === 0 ? (
          <div className="p-8 text-center space-y-2">
            <p className="text-sm font-medium text-slate-800">No API keys created yet</p>
            <p className="text-xs text-slate-500">
              Generate your first key above to connect an external website or web application.
            </p>
          </div>
        ) : (
          <>
            <div className="md:hidden divide-y divide-slate-100">
              {keys.map((k) => (
                <div key={k.id} className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900 truncate">{k.name}</p>
                      <p className="text-xs font-mono text-slate-600 mt-0.5">{k.keyPrefix}</p>
                    </div>
                    <span
                      className={`inline-block px-2 py-0.5 text-[11px] font-medium rounded border shrink-0 ${
                        k.active
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-slate-100 text-slate-600 border-slate-200'
                      }`}
                    >
                      {k.active ? 'Active' : 'Disabled'}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 p-2.5 bg-slate-50 rounded-lg text-xs">
                    <div>
                      <p className="text-[10px] uppercase text-slate-500 font-semibold">Scopes</p>
                      <p className="font-mono tabular-nums text-slate-800 mt-0.5">
                        {k.scopes.length === ALL_SCOPES.length ? 'All (8)' : `${k.scopes.length}`}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase text-slate-500 font-semibold">Requests</p>
                      <p className="font-mono tabular-nums text-slate-800 mt-0.5">
                        {k.requestCount || 0}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase text-slate-500 font-semibold">Last Used</p>
                      <p className="font-mono tabular-nums text-slate-800 mt-0.5 truncate">
                        {k.lastUsedAt ? k.lastUsedAt.slice(0, 10) : 'Never'}
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => handleToggleActive(k)}
                      className="min-h-[40px] inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                    >
                      <Power className="w-3.5 h-3.5" />
                      <span>{k.active ? 'Disable' : 'Enable'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setRevokeTarget(k)}
                      className="min-h-[40px] inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-red-700 bg-white border border-red-200 rounded-lg hover:bg-red-50"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Revoke</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    <th className="px-5 py-3">Integration Name</th>
                    <th className="px-5 py-3">Key Prefix</th>
                    <th className="px-5 py-3">Status</th>
                    <th className="px-5 py-3">Scopes</th>
                    <th className="px-5 py-3 text-right">Requests</th>
                    <th className="px-5 py-3">Last Used</th>
                    <th className="px-5 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {keys.map((k) => (
                    <tr key={k.id} className="hover:bg-slate-50/70">
                      <td className="px-5 py-3.5 font-medium text-slate-900">{k.name}</td>
                      <td className="px-5 py-3.5 font-mono text-slate-700 whitespace-nowrap">
                        {k.keyPrefix}
                      </td>
                      <td className="px-5 py-3.5 whitespace-nowrap">
                        <span
                          className={`inline-block px-2 py-0.5 text-[11px] font-medium rounded border ${
                            k.active
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : 'bg-slate-100 text-slate-600 border-slate-200'
                          }`}
                        >
                          {k.active ? 'Active' : 'Disabled'}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-slate-600">
                        <span className="font-mono tabular-nums">
                          {k.scopes.length === ALL_SCOPES.length
                            ? 'All scopes (8)'
                            : `${k.scopes.length} scopes`}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right font-mono tabular-nums text-slate-700">
                        {k.requestCount || 0}
                      </td>
                      <td className="px-5 py-3.5 font-mono text-slate-500 whitespace-nowrap">
                        {k.lastUsedAt ? k.lastUsedAt.slice(0, 19).replace('T', ' ') : 'Never'}
                      </td>
                      <td className="px-5 py-3.5 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleToggleActive(k)}
                            title={k.active ? 'Disable key' : 'Enable key'}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-slate-700 bg-white border border-slate-300 rounded hover:bg-slate-50"
                          >
                            <Power className="w-3 h-3" />
                            <span>{k.active ? 'Disable' : 'Enable'}</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setRevokeTarget(k)}
                            title="Revoke key"
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-red-700 bg-white border border-red-200 rounded hover:bg-red-50"
                          >
                            <Trash2 className="w-3 h-3" />
                            <span>Revoke</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      {/* API Connection Tester & Code Snippets */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-4 sm:px-5 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
              <Terminal className="w-4 h-4 text-slate-700" />
              <span>Connect External Websites — REST API Reference</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Use your API key from any external website or backend to sync clients, create
              subscriptions, and generate unified payment links.
            </p>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto min-w-0">
            <code className="flex-1 sm:flex-none px-2.5 py-2 sm:py-1.5 text-[11px] font-mono bg-slate-100 border border-slate-200 rounded text-slate-800 sm:max-w-[260px] min-w-0 truncate">
              {baseUrl}/api/v1
            </code>
            <button
              type="button"
              onClick={() => copyText(`${baseUrl}/api/v1`, setCopiedBaseUrl)}
              className="inline-flex items-center gap-1 px-2.5 py-2 sm:py-1.5 min-h-[38px] sm:min-h-0 text-[11px] font-medium text-slate-700 bg-white border border-slate-300 rounded hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              {copiedBaseUrl ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              <span>{copiedBaseUrl ? 'Copied' : 'Copy Base URL'}</span>
            </button>
          </div>
        </div>

        <div className="p-4 sm:p-5 space-y-5">
          {/* Live Key Verification Tester */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3.5 sm:p-4 space-y-3">
            <div className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-center">
              <input
                type="password"
                value={testKeyInput}
                onChange={(e) => setTestKeyInput(e.target.value)}
                placeholder="Paste your fa_live_... key to test GET /api/v1/me"
                className="flex-1 min-w-0 px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-mono bg-white border border-slate-300 rounded-lg"
              />
              <button
                type="button"
                disabled={testingKey}
                onClick={handleTestKey}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50 whitespace-nowrap"
              >
                <Play className="w-3.5 h-3.5" />
                <span>{testingKey ? 'Testing...' : 'Test API Connection'}</span>
              </button>
            </div>
            {testResult && (
              <div
                className={`rounded-lg border p-3 text-xs space-y-1.5 ${
                  testResult.ok
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                    : 'bg-red-50 border-red-200 text-red-950'
                }`}
              >
                <div className="flex items-center gap-2 font-medium">
                  {testResult.ok ? (
                    <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-red-700" />
                  )}
                  <span>HTTP {testResult.status} Response</span>
                </div>
                <pre className="text-[11px] font-mono overflow-x-auto bg-white/80 p-2 rounded border border-slate-200 text-slate-800">
                  {testResult.body}
                </pre>
              </div>
            )}
          </div>

          {/* Code Tabs */}
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200">
              <div className="flex items-center gap-4 overflow-x-auto min-w-0">
                <button
                  type="button"
                  onClick={() => setSnippetTab('js')}
                  className={`pb-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
                    snippetTab === 'js'
                      ? 'border-slate-900 text-slate-900'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  JavaScript (fetch)
                </button>
                <button
                  type="button"
                  onClick={() => setSnippetTab('curl')}
                  className={`pb-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
                    snippetTab === 'curl'
                      ? 'border-slate-900 text-slate-900'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  cURL
                </button>
                <button
                  type="button"
                  onClick={() => setSnippetTab('endpoints')}
                  className={`pb-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
                    snippetTab === 'endpoints'
                      ? 'border-slate-900 text-slate-900'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  All Endpoints
                </button>
              </div>

              {snippetTab !== 'endpoints' && (
                <button
                  type="button"
                  onClick={() =>
                    copyText(snippetTab === 'js' ? jsSnippet : curlSnippet, setCopiedSnippet)
                  }
                  className="mb-1.5 inline-flex items-center gap-1 px-2.5 py-1.5 sm:py-1 text-[11px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded shrink-0"
                >
                  {copiedSnippet ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedSnippet ? 'Copied' : 'Copy Code'}</span>
                </button>
              )}
            </div>

            {snippetTab === 'endpoints' ? (
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg text-xs">
                {[
                  ['GET', '/api/v1/me', 'Verify API key & workspace profile'],
                  ['GET', '/api/v1/services', 'List active packages (599 EUR / 1,199 EUR)'],
                  ['GET / POST', '/api/v1/clients', 'Search or create/update client records'],
                  ['GET / POST', '/api/v1/subscriptions', 'List or assign client subscriptions'],
                  [
                    'GET / POST',
                    '/api/v1/payment-links',
                    'Create unified Bank Transfer + Card Checkout links & poll status',
                  ],
                  ['GET', '/api/v1/payment-links/:id', 'Check real-time payment link status'],
                  ['GET', '/api/v1/payments', 'List confirmed & recorded payments'],
                  ['GET', '/api/v1/invoices', 'List paid invoices with signed PDF URLs'],
                ].map(([method, endpoint, desc]) => (
                  <div
                    key={endpoint}
                    className="px-3.5 sm:px-4 py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1"
                  >
                    <div className="flex items-center gap-2.5 font-mono min-w-0">
                      <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-slate-100 text-slate-800 rounded shrink-0">
                        {method}
                      </span>
                      <span className="text-slate-900 font-medium break-all">{endpoint}</span>
                    </div>
                    <span className="text-slate-500">{desc}</span>
                  </div>
                ))}
              </div>
            ) : (
              <pre className="p-3.5 sm:p-4 bg-slate-950 text-slate-100 rounded-lg text-xs font-mono overflow-x-auto leading-relaxed">
                {snippetTab === 'js' ? jsSnippet : curlSnippet}
              </pre>
            )}
          </div>
        </div>
      </div>

      {/* Recent External API Activity */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-4 sm:px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <h2 className="text-sm font-semibold text-slate-900">Recent External API Requests</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Live log of authenticated calls from connected websites and apps.
            </p>
          </div>
          <button
            type="button"
            onClick={loadKeys}
            className="inline-flex items-center gap-1.5 px-3 py-2 sm:py-1.5 min-h-[38px] sm:min-h-0 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 shrink-0"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>
        {activity.length === 0 ? (
          <p className="p-6 text-center text-xs text-slate-500">
            No external API calls recorded yet.
          </p>
        ) : (
          <div className="divide-y divide-slate-100 max-h-64 overflow-y-auto text-xs">
            {activity.map((entry) => (
              <div
                key={entry.id}
                className="px-4 sm:px-5 py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 sm:gap-4"
              >
                <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                  <span
                    className={`px-1.5 py-0.5 font-mono text-[11px] font-semibold rounded border shrink-0 ${
                      entry.statusCode < 400
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-red-50 text-red-700 border-red-200'
                    }`}
                  >
                    {entry.statusCode}
                  </span>
                  <span className="font-mono font-semibold text-slate-800 shrink-0">
                    {entry.method}
                  </span>
                  <span className="font-mono text-slate-700 truncate">{entry.path}</span>
                </div>
                <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 text-slate-500">
                  <span className="text-slate-700 font-medium truncate">{entry.keyName}</span>
                  <span className="font-mono tabular-nums">
                    {entry.timestamp.slice(0, 19).replace('T', ' ')}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <ConfirmDialog
        open={Boolean(revokeTarget)}
        title="Revoke API Key"
        description="Any external website using this API key will immediately lose access to FreskaAssist endpoints."
        details={
          revokeTarget
            ? [
                `Integration: ${revokeTarget.name}`,
                `Key Prefix: ${revokeTarget.keyPrefix}`,
                `Total Requests: ${revokeTarget.requestCount}`,
              ]
            : undefined
        }
        confirmLabel="Revoke Key"
        variant="danger"
        busy={revoking}
        onConfirm={handleConfirmRevoke}
        onCancel={() => setRevokeTarget(null)}
      />
    </div>
  );
};
