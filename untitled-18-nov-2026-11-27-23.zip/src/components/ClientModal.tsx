import React, { useEffect, useState } from 'react';
import { X, Repeat, CreditCard, Mail, AlertCircle } from 'lucide-react';
import { saveEntity } from '../lib/storeClient.ts';
import {
  assignClientBillingPlan,
  computeClientFinancials,
  generateId,
  sendClientWelcomeEmail,
  STANDARD_PACKAGES,
} from '../lib/billingEngine.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import type { ClientRecord, ClientStatus, PaymentMethod } from '../types/freska.ts';

interface ClientModalProps {
  open: boolean;
  editingClient?: ClientRecord | null;
  onClose: () => void;
}

type ClientBillingChoice = 'subscription' | 'one_time' | 'none';

export const ClientModal: React.FC<ClientModalProps> = ({
  open,
  editingClient,
  onClose,
}) => {
  const {
    user,
    clients,
    subscriptions,
    payments,
    paymentRequests,
    gatewayDbSettings,
    gatewayServerStatus,
    systemSettings,
    emailTemplates,
    emailDeliveryActive,
    smtpStatus,
    gmailEmail,
    reconnectGmail,
    notify,
  } = useFreska();

  const [fullName, setFullName] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [businessType, setBusinessType] = useState('');
  const [servicesText, setServicesText] = useState('');
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<ClientStatus>('active');
  const [preferredCurrency, setPreferredCurrency] = useState(
    systemSettings.defaultCurrency || 'EUR'
  );
  const [preferredPaymentMethod, setPreferredPaymentMethod] =
    useState<PaymentMethod>('bank_transfer');

  const [billingPlan, setBillingPlan] = useState<ClientBillingChoice>('subscription');
  const [initialBillingPlan, setInitialBillingPlan] = useState<ClientBillingChoice>('none');
  const [planAmount, setPlanAmount] = useState('599');
  const [initialPlanAmount, setInitialPlanAmount] = useState(599);

  const [saving, setSaving] = useState(false);

  const cardPaymentsActive = Boolean(
    gatewayServerStatus?.enabled && gatewayServerStatus?.connectionVerified
  );

  useEffect(() => {
    if (!open) return;
    if (editingClient) {
      const fin = computeClientFinancials(
        editingClient.id,
        subscriptions,
        payments,
        paymentRequests
      );
      const detectedPlan: ClientBillingChoice = fin.billingMode || 'none';
      const detectedAmount =
        detectedPlan === 'subscription'
          ? fin.monthlyRate || STANDARD_PACKAGES.subscription.defaultPrice
          : detectedPlan === 'one_time'
          ? fin.oneTimeAmount || STANDARD_PACKAGES.one_time.defaultPrice
          : STANDARD_PACKAGES.subscription.defaultPrice;

      setFullName(editingClient.fullName);
      setBusinessName(editingClient.businessName);
      setEmail(editingClient.email);
      setPhone(editingClient.phone || '');
      setBusinessType(editingClient.businessType || '');
      setServicesText((editingClient.servicesPurchased || []).join(', '));
      setNotes(editingClient.notes || '');
      setStatus(editingClient.status);
      setPreferredCurrency(
        editingClient.preferredCurrency || systemSettings.defaultCurrency || 'EUR'
      );
      setPreferredPaymentMethod(editingClient.preferredPaymentMethod || 'bank_transfer');
      setBillingPlan(detectedPlan);
      setInitialBillingPlan(detectedPlan);
      setPlanAmount(String(detectedAmount));
      setInitialPlanAmount(detectedAmount);
    } else {
      setFullName('');
      setBusinessName('');
      setEmail('');
      setPhone('');
      setBusinessType('');
      setServicesText('');
      setNotes('');
      setStatus('active');
      setPreferredCurrency('EUR');
      setPreferredPaymentMethod('bank_transfer');
      setBillingPlan('subscription');
      setInitialBillingPlan('none');
      setPlanAmount(String(STANDARD_PACKAGES.subscription.defaultPrice));
      setInitialPlanAmount(STANDARD_PACKAGES.subscription.defaultPrice);
    }
  }, [
    open,
    editingClient,
    subscriptions,
    payments,
    paymentRequests,
    systemSettings.defaultCurrency,
  ]);

  if (!open) return null;

  const handleSelectPlan = (choice: ClientBillingChoice) => {
    setBillingPlan(choice);
    if (choice === 'subscription') {
      setPlanAmount(String(STANDARD_PACKAGES.subscription.defaultPrice));
      setPreferredCurrency('EUR');
    } else if (choice === 'one_time') {
      setPlanAmount(String(STANDARD_PACKAGES.one_time.defaultPrice));
      setPreferredCurrency('EUR');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      notify('error', 'Connect your Google Account first so clients stay saved to your account.');
      return;
    }
    if (!fullName.trim() || !email.trim()) {
      notify('error', 'Full name and email address are required.');
      return;
    }

    const numericPlanAmount = Number(planAmount);
    if (billingPlan !== 'none' && (Number.isNaN(numericPlanAmount) || numericPlanAmount <= 0)) {
      notify('error', 'Enter a valid positive amount for the selected billing package.');
      return;
    }

    setSaving(true);
    try {
      const servicesPurchased = servicesText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
        .slice(0, 50);

      let savedClient: ClientRecord;

      if (editingClient) {
        const updatedFields = {
          fullName: fullName.trim(),
          businessName: businessName.trim() || fullName.trim(),
          email: email.trim(),
          phone: phone.trim(),
          businessType: businessType.trim(),
          servicesPurchased,
          notes: notes.trim(),
          status,
          preferredCurrency,
          preferredPaymentMethod,
        };
        await saveEntity('clients', editingClient.id, updatedFields);
        savedClient = { ...editingClient, ...updatedFields };
      } else {
        const id = generateId('cli');
        const clientCode = `CL-${String(clients.length + 1).padStart(4, '0')}`;
        const newClientData = {
          id,
          clientCode,
          fullName: fullName.trim(),
          businessName: businessName.trim() || fullName.trim(),
          email: email.trim(),
          phone: phone.trim(),
          businessType: businessType.trim(),
          servicesPurchased,
          notes: notes.trim(),
          status,
          preferredCurrency,
          preferredPaymentMethod,
        };
        await saveEntity('clients', id, newClientData, { isNew: true });
        savedClient = newClientData;

        // Create independent per-client reminder settings with default schedule
        const remSettingId = `remset_${id}`;
        await saveEntity(
          'reminder_settings',
          remSettingId,
          {
            id: remSettingId,
            clientId: id,
            enabled: true,
            daysBeforeDue: 3,
            sendOnDueDate: true,
            daysAfterDueFirst: 3,
            daysAfterDueSecond: 7,
            customOffsets: [],
          },
          { isNew: true }
        );
      }

      const planChanged =
        !editingClient ||
        billingPlan !== initialBillingPlan ||
        numericPlanAmount !== initialPlanAmount;

      let assignedPlanResult: Awaited<ReturnType<typeof assignClientBillingPlan>> | null = null;
      if (billingPlan !== 'none' && planChanged) {
        assignedPlanResult = await assignClientBillingPlan({
          client: savedClient,
          planType: billingPlan,
          customAmount: numericPlanAmount,
          currency: preferredCurrency,
          paymentMethod: preferredPaymentMethod,
          existingSubscriptions: subscriptions,
          existingPaymentRequests: paymentRequests,
          gatewaySettings: gatewayDbSettings,
          systemSettings,
          cardPaymentsActive,
        });
      }

      if (!editingClient) {
        const welcomeRes = await sendClientWelcomeEmail({
          client: savedClient,
          planType: billingPlan,
          amount: assignedPlanResult?.amount ?? (billingPlan !== 'none' ? numericPlanAmount : 0),
          currency: assignedPlanResult?.currency ?? preferredCurrency,
          paymentUrl: assignedPlanResult?.paymentUrl,
          templates: emailTemplates,
        });

        const planSummary = assignedPlanResult
          ? assignedPlanResult.mode === 'subscription'
            ? `Subscription (${assignedPlanResult.amount} ${assignedPlanResult.currency}/mo)`
            : `One-Time Payment (${assignedPlanResult.amount} ${assignedPlanResult.currency})`
          : 'Profile saved';

        if (welcomeRes.sent) {
          notify(
            'success',
            billingPlan === 'one_time'
              ? `Created ${savedClient.businessName} · ${planSummary}. Welcome email + payment link sent.`
              : `Created ${savedClient.businessName} · ${planSummary}. Welcome email sent (payment link scheduled in 2 days).`
          );
        } else {
          notify(
            'info',
            `Created ${savedClient.businessName} · ${planSummary}. ${
              emailDeliveryActive
                ? `Welcome email failed: ${welcomeRes.error || 'Unknown error'}`
                : 'Enable SMTP Relay or authorize Gmail to send the automatic welcome email.'
            }`
          );
        }
      } else if (assignedPlanResult) {
        notify(
          'success',
          `Updated ${savedClient.businessName} · ${
            assignedPlanResult.mode === 'subscription'
              ? `Subscription (${assignedPlanResult.amount} ${assignedPlanResult.currency}/mo)`
              : `One-Time Payment (${assignedPlanResult.amount} ${assignedPlanResult.currency})`
          }.`
        );
      } else {
        notify('success', `Updated client profile for ${savedClient.businessName}.`);
      }

      onClose();
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to save client');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/40 backdrop-blur-[1px] p-2 sm:p-4">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl sm:rounded-xl shadow-lg overflow-hidden max-h-[92dvh] flex flex-col">
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200 shrink-0">
          <h2 className="text-base font-semibold text-slate-900 truncate pr-2">
            {editingClient ? `Edit Client · ${editingClient.clientCode}` : 'Add New Client'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-2 -mr-1 rounded min-h-[40px] min-w-[40px] flex items-center justify-center"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto p-4 sm:p-6 space-y-4">
          {/* Per-Client Billing Mode Selection: Subscription (599€) OR One-Time Payment (1199€) */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-slate-900">
                  Client Billing Package (Choose One)
                </p>
                <p className="text-[11px] text-slate-500">
                  Assign either a monthly Subscription (599€) or a One-Time Payment (1,199€).
                </p>
              </div>
              {billingPlan !== 'none' && (
                <button
                  type="button"
                  onClick={() => handleSelectPlan('none')}
                  className="text-[11px] text-slate-500 hover:text-slate-800 underline"
                >
                  Assign later
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => handleSelectPlan('subscription')}
                className={`p-3.5 rounded-lg border text-left transition-all flex items-start gap-3 ${
                  billingPlan === 'subscription'
                    ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                    : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'
                }`}
              >
                <Repeat
                  className={`w-4 h-4 mt-0.5 shrink-0 ${
                    billingPlan === 'subscription' ? 'text-emerald-400' : 'text-slate-500'
                  }`}
                />
                <div className="min-w-0">
                  <div className="text-xs font-semibold">Subscription</div>
                  <div
                    className={`text-sm font-mono font-semibold tabular-nums mt-0.5 ${
                      billingPlan === 'subscription' ? 'text-white' : 'text-slate-900'
                    }`}
                  >
                    599.00 € <span className="text-[11px] font-sans font-normal">/ month</span>
                  </div>
                  <div
                    className={`text-[11px] mt-0.5 ${
                      billingPlan === 'subscription' ? 'text-slate-300' : 'text-slate-500'
                    }`}
                  >
                    Monthly recurring billing & reminders
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleSelectPlan('one_time')}
                className={`p-3.5 rounded-lg border text-left transition-all flex items-start gap-3 ${
                  billingPlan === 'one_time'
                    ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                    : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'
                }`}
              >
                <CreditCard
                  className={`w-4 h-4 mt-0.5 shrink-0 ${
                    billingPlan === 'one_time' ? 'text-sky-400' : 'text-slate-500'
                  }`}
                />
                <div className="min-w-0">
                  <div className="text-xs font-semibold">One-Time Payment</div>
                  <div
                    className={`text-sm font-mono font-semibold tabular-nums mt-0.5 ${
                      billingPlan === 'one_time' ? 'text-white' : 'text-slate-900'
                    }`}
                  >
                    1,199.00 € <span className="text-[11px] font-sans font-normal">single</span>
                  </div>
                  <div
                    className={`text-[11px] mt-0.5 ${
                      billingPlan === 'one_time' ? 'text-slate-300' : 'text-slate-500'
                    }`}
                  >
                    Single payment request (no recurring)
                  </div>
                </div>
              </button>
            </div>

            {billingPlan !== 'none' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-1">
                    Package Price
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    value={planAmount}
                    onChange={(e) => setPlanAmount(e.target.value)}
                    className="w-full min-h-[44px] sm:min-h-0 px-3 py-2 sm:py-1.5 text-sm font-mono border border-slate-300 rounded-lg bg-white tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-1">
                    Package Currency
                  </label>
                  <select
                    value={preferredCurrency}
                    onChange={(e) => setPreferredCurrency(e.target.value)}
                    className="w-full min-h-[44px] sm:min-h-0 px-3 py-2 sm:py-1.5 text-sm border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="EUR">EUR (€)</option>
                    <option value="USD">USD ($)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="CAD">CAD</option>
                    <option value="MAD">MAD</option>
                  </select>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Jane Doe"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Business Name *
              </label>
              <input
                type="text"
                required
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="Northstar Studio LLC"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Email Address *
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="billing@northstar.example"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Phone Number
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+33 6 12 34 56 78"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Business Type
              </label>
              <input
                type="text"
                value={businessType}
                onChange={(e) => setBusinessType(e.target.value)}
                placeholder="E-Commerce, SaaS, Agency..."
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Preferred Currency
              </label>
              <select
                value={preferredCurrency}
                onChange={(e) => setPreferredCurrency(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
              >
                <option value="EUR">EUR (€)</option>
                <option value="USD">USD ($)</option>
                <option value="GBP">GBP (£)</option>
                <option value="CAD">CAD</option>
                <option value="MAD">MAD</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Client Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as ClientStatus)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
              >
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="archived">Archived</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Preferred Payment Method
              </label>
              <select
                value={preferredPaymentMethod}
                onChange={(e) => setPreferredPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
              >
                <option value="bank_transfer">Bank Transfer (Virement)</option>
                <option value="manual">Manual Payment</option>
                <option value="card">Credit / Debit Card</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Additional Services (comma separated)
              </label>
              <input
                type="text"
                value={servicesText}
                onChange={(e) => setServicesText(e.target.value)}
                placeholder="Web Retainer, SEO Audit"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Internal Notes
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Private administration notes, billing preferences, or SLA terms..."
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>

          {!editingClient && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-start gap-2">
                {emailDeliveryActive ? (
                  <Mail className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                )}
                <span>
                  {emailDeliveryActive ? (
                    <>
                      Auto-welcome via{' '}
                      <span className="font-mono">
                        {smtpStatus?.enabled && smtpStatus?.connectionVerified
                          ? smtpStatus.fromEmail
                          : gmailEmail || 'Email'}
                      </span>
                      :{' '}
                      {billingPlan === 'one_time'
                        ? 'Sends welcome email with immediate payment link.'
                        : billingPlan === 'subscription'
                        ? 'Sends welcome email immediately; subscription payment link dispatches in 2 days.'
                        : 'Sends welcome email immediately.'}
                    </>
                  ) : (
                    'No active email sender — enable SMTP Relay or authorize Gmail so the welcome email sends automatically.'
                  )}
                </span>
              </div>
              {!emailDeliveryActive && (
                <button
                  type="button"
                  onClick={() => reconnectGmail()}
                  className="px-2.5 py-1 text-[11px] font-medium text-white bg-slate-900 rounded hover:bg-slate-800 whitespace-nowrap"
                >
                  Authorize Gmail
                </button>
              )}
            </div>
          )}

          <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2.5 sm:gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto min-h-[44px] sm:min-h-0 px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="w-full sm:w-auto min-h-[44px] sm:min-h-0 px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
            >
              {saving ? 'Saving...' : editingClient ? 'Save Changes' : 'Create Client'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
