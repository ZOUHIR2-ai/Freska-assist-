import React from 'react';

const STATUS_STYLES: Record<string, { bg: string; text: string; border: string; label: string }> = {
  active: { bg: 'bg-emerald-50', text: 'text-emerald-800', border: 'border-emerald-200', label: 'Active' },
  paid: { bg: 'bg-emerald-50', text: 'text-emerald-800', border: 'border-emerald-200', label: 'Paid' },
  sent: { bg: 'bg-emerald-50', text: 'text-emerald-800', border: 'border-emerald-200', label: 'Sent' },
  processed: { bg: 'bg-emerald-50', text: 'text-emerald-800', border: 'border-emerald-200', label: 'Processed' },
  pending: { bg: 'bg-amber-50', text: 'text-amber-800', border: 'border-amber-200', label: 'Pending' },
  paused: { bg: 'bg-slate-100', text: 'text-slate-700', border: 'border-slate-200', label: 'Paused' },
  inactive: { bg: 'bg-slate-100', text: 'text-slate-700', border: 'border-slate-200', label: 'Inactive' },
  archived: { bg: 'bg-slate-100', text: 'text-slate-600', border: 'border-slate-200', label: 'Archived' },
  skipped: { bg: 'bg-slate-100', text: 'text-slate-600', border: 'border-slate-200', label: 'Skipped' },
  ignored: { bg: 'bg-slate-100', text: 'text-slate-600', border: 'border-slate-200', label: 'Ignored' },
  unpaid: { bg: 'bg-orange-50', text: 'text-orange-800', border: 'border-orange-200', label: 'Unpaid' },
  overdue: { bg: 'bg-red-50', text: 'text-red-800', border: 'border-red-200', label: 'Overdue' },
  failed: { bg: 'bg-red-50', text: 'text-red-800', border: 'border-red-200', label: 'Failed' },
  cancelled: { bg: 'bg-slate-100', text: 'text-slate-600', border: 'border-slate-200', label: 'Cancelled' },
  refunded: { bg: 'bg-slate-100', text: 'text-slate-700', border: 'border-slate-300', label: 'Refunded' },
};

export const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const key = (status || '').toLowerCase();
  const style = STATUS_STYLES[key] || {
    bg: 'bg-slate-100',
    text: 'text-slate-700',
    border: 'border-slate-200',
    label: status,
  };

  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 text-xs font-medium rounded border whitespace-nowrap shrink-0 ${style.bg} ${style.text} ${style.border}`}
    >
      {style.label}
    </span>
  );
};
