import React, { useEffect, useState } from 'react';
import {
  ShieldCheck,
  Mail,
  Lock,
  RefreshCw,
  ArrowLeftRight,
  LogOut,
  CheckCircle2,
  AlertCircle,
  Clock,
  ExternalLink,
} from 'lucide-react';
import { useFreska } from '../context/FreskaContext.tsx';
import { isEmbeddedIframe } from '../lib/firebase.ts';

function GoogleGIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5 shrink-0" aria-hidden="true">
      <path
        fill="#4285F4"
        d="M23.745 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-8.97Z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.3 0 6.08-1.09 8.1-2.96l-3.88-3.05c-1.09.73-2.49 1.16-4.22 1.16-3.25 0-6-2.19-6.98-5.14H1.01v3.14C3.02 21.14 7.21 24 12 24Z"
      />
      <path
        fill="#FBBC05"
        d="M5.02 14.01c-.25-.73-.39-1.51-.39-2.31s.14-1.58.39-2.31V6.25H1.01C.37 7.53 0 8.97 0 11.7s.37 4.17 1.01 5.45l4.01-3.14Z"
      />
      <path
        fill="#EA4335"
        d="M12 4.75c1.8 0 3.41.62 4.68 1.84l3.51-3.51C18.07 1.19 15.3 0 12 0 7.21 0 3.02 2.86 1.01 6.85l4.01 3.14c.98-2.95 3.73-5.24 6.98-5.24Z"
      />
    </svg>
  );
}

export const SecurityGateScreen: React.FC = () => {
  const {
    user,
    googleConnecting,
    gmailConnected,
    smtpStatus,
    authError,
    securityState,
    securityCodeSending,
    securityVerifying,
    securityCodeSent,
    securityRequiresGmailAuth,
    securityDeliveryMethod,
    securityMaskedEmail,
    securityError,
    securityCooldownSeconds,
    connectGoogle,
    connectGoogleWithRedirect,
    switchGoogleAccount,
    disconnectGoogle,
    requestSecurityCode,
    submitSecurityCode,
  } = useFreska();

  const [codeInput, setCodeInput] = useState('');
  const isEmbedded = isEmbeddedIframe();
  const standaloneUrl = typeof window !== 'undefined' ? window.location.href : '/';

  useEffect(() => {
    setCodeInput('');
  }, [user?.email, securityState]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = codeInput.replace(/\D/g, '').slice(0, 6);
    if (clean.length !== 6) return;
    await submitSecurityCode(clean);
  };

  const handleCodeChange = (value: string) => {
    const clean = value.replace(/\D/g, '').slice(0, 6);
    setCodeInput(clean);
  };

  const smtpConfigured = Boolean(smtpStatus?.enabled && smtpStatus?.connectionVerified);

  return (
    <div className="min-h-[100dvh] bg-slate-50 flex flex-col justify-center px-4 py-6 sm:px-6 lg:px-8">
      <div className="w-full max-w-md mx-auto">
        {/* Brand Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="bg-black rounded-xl px-4 py-2.5 shadow-sm border border-slate-900 mb-4">
            <img
              src="/assets/aistudio/IMG-20261117-WA0014_9dd05831.jpg"
              alt="FreskaAssist"
              className="h-7 w-auto object-contain"
            />
          </div>
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
            <ShieldCheck className="w-4 h-4 text-slate-900" />
            <span>24-Hour Gmail Security Verification</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-semibold text-slate-900 tracking-tight">
            {securityState === 'locked_no_google'
              ? 'Sign in with Google to Unlock'
              : 'Verify Your Gmail Security Code'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1.5 max-w-sm leading-relaxed">
            {securityState === 'locked_no_google'
              ? 'FreskaAssist protects your workspace by sending a 6-digit verification code to your Google Account Gmail every 24 hours.'
              : 'Your 24-hour session requires verification. Enter the 6-digit code sent automatically to your linked Gmail.'}
          </p>
        </div>

        {/* Main Card */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5 sm:p-7 space-y-5">
          {securityState === 'locked_no_google' ? (
            <>
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
                <div className="flex items-start gap-3">
                  <Lock className="w-4 h-4 text-slate-700 shrink-0 mt-0.5" />
                  <div className="text-xs text-slate-600 leading-relaxed space-y-1">
                    <p className="font-semibold text-slate-900">How 24-hour protection works</p>
                    <p>
                      Connect your Google Account. A one-time 6-digit security code will be sent
                      directly to your Gmail inbox and unlocks the dashboard for 24 hours.
                    </p>
                  </div>
                </div>
              </div>

              {authError && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-3.5 space-y-2.5 text-xs text-red-900">
                  <div className="flex items-start gap-2.5">
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    <span className="leading-relaxed">{authError}</span>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2">
                    {isEmbedded ? (
                      <a
                        href={standaloneUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="min-h-[42px] px-3.5 py-2 bg-red-900 hover:bg-red-800 text-white font-medium rounded-lg inline-flex items-center justify-center gap-2 transition-colors"
                      >
                        <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                        <span>Open App in New Tab</span>
                      </a>
                    ) : (
                      <button
                        type="button"
                        disabled={googleConnecting}
                        onClick={() => connectGoogleWithRedirect(true)}
                        className="min-h-[42px] px-3.5 py-2 bg-red-900 hover:bg-red-800 text-white font-medium rounded-lg inline-flex items-center justify-center gap-2 transition-colors disabled:opacity-60"
                      >
                        <span>Use Full-Page Google Redirect</span>
                      </button>
                    )}
                    <button
                      type="button"
                      disabled={googleConnecting}
                      onClick={() =>
                        connectGoogle({ includeGmail: false, forceAccountSelect: true })
                      }
                      className="min-h-[42px] px-3.5 py-2 bg-white hover:bg-red-100 text-red-900 border border-red-300 font-medium rounded-lg inline-flex items-center justify-center gap-1.5 transition-colors disabled:opacity-60"
                    >
                      <span>Sign in with Google Profile Only</span>
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-2.5">
                <button
                  type="button"
                  disabled={googleConnecting}
                  onClick={() => connectGoogle({ includeGmail: true, forceAccountSelect: true })}
                  className="w-full min-h-[48px] px-4 py-3 bg-slate-900 hover:bg-slate-800 text-white text-sm font-medium rounded-xl flex items-center justify-center gap-3 transition-colors disabled:opacity-60"
                >
                  <GoogleGIcon />
                  <span>
                    {googleConnecting ? 'Connecting Google Account...' : 'Sign in with Google & Gmail'}
                  </span>
                </button>

                {smtpConfigured && (
                  <button
                    type="button"
                    disabled={googleConnecting}
                    onClick={() => connectGoogle({ includeGmail: false, forceAccountSelect: true })}
                    className="w-full min-h-[44px] px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-xs font-medium rounded-xl flex items-center justify-center gap-2 transition-colors disabled:opacity-60"
                  >
                    <span>Sign in with Google Profile (SMTP Code Delivery)</span>
                  </button>
                )}

                {isEmbedded && !authError && (
                  <a
                    href={standaloneUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full min-h-[42px] px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                    <span>Mobile browser? Open in standalone tab to sign in</span>
                  </a>
                )}
              </div>
            </>
          ) : (
            <>
              {/* Linked Account Banner */}
              <div className="flex items-center justify-between gap-3 bg-slate-50 border border-slate-200 rounded-xl p-3.5">
                <div className="flex items-center gap-3 min-w-0">
                  {user?.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt={user.displayName || 'Google Account'}
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-full object-cover border border-slate-300 shrink-0"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-slate-900 text-white flex items-center justify-center text-sm font-semibold shrink-0">
                      {(user?.displayName || user?.email || 'G').charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-900 truncate">
                      {user?.displayName || 'Google Account'}
                    </p>
                    <p className="text-xs font-mono text-slate-600 truncate">
                      {securityMaskedEmail || user?.email}
                    </p>
                  </div>
                </div>
                <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-600 shrink-0">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>24h Lock</span>
                </span>
              </div>

              {/* Delivery Status */}
              {securityCodeSending ? (
                <div className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 flex items-center gap-3 text-xs text-slate-700">
                  <RefreshCw className="w-4 h-4 text-slate-600 animate-spin shrink-0" />
                  <span>
                    Sending 6-digit security code to{' '}
                    <span className="font-mono font-medium">
                      {securityMaskedEmail || user?.email}
                    </span>
                    ...
                  </span>
                </div>
              ) : securityRequiresGmailAuth && !smtpConfigured ? (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-2.5 text-xs text-amber-950">
                    <Mail className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <p className="font-semibold">Gmail delivery authorization required</p>
                      <p className="text-amber-800 leading-relaxed">
                        Your 24-hour session expired. Tap below to authorize Gmail so FreskaAssist
                        can automatically send your 6-digit verification code to{' '}
                        <span className="font-mono">{user?.email}</span>.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={googleConnecting}
                    onClick={() => connectGoogle({ includeGmail: true, forceAccountSelect: false })}
                    className="w-full min-h-[48px] px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-medium rounded-xl flex items-center justify-center gap-2.5 transition-colors disabled:opacity-60"
                  >
                    <GoogleGIcon />
                    <span>
                      {googleConnecting
                        ? 'Authorizing Gmail...'
                        : 'Authorize Gmail & Send Verification Code'}
                    </span>
                  </button>
                </div>
              ) : securityCodeSent ? (
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 flex items-start gap-2.5 text-xs text-emerald-950">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <div className="space-y-0.5">
                    <p className="font-semibold">
                      Security code sent to {securityMaskedEmail || user?.email}
                    </p>
                    <p className="text-emerald-800">
                      Delivered via{' '}
                      {securityDeliveryMethod === 'smtp' ? 'Verified SMTP Relay' : 'Gmail API'}.
                      Valid for 10 minutes.
                    </p>
                  </div>
                </div>
              ) : null}

              {(securityError || authError) && (
                <div className="bg-red-50 border border-red-200 rounded-xl px-3.5 py-2.5 flex items-start gap-2.5 text-xs text-red-800">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <span>{securityError || authError}</span>
                </div>
              )}

              {/* OTP Entry Form */}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label
                    htmlFor="freska-otp-input"
                    className="block text-xs font-medium text-slate-700 mb-1.5"
                  >
                    Enter 6-Digit Gmail Security Code
                  </label>
                  <input
                    id="freska-otp-input"
                    type="text"
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    pattern="[0-9]{6}"
                    maxLength={6}
                    value={codeInput}
                    onChange={(e) => handleCodeChange(e.target.value)}
                    placeholder="000000"
                    className="w-full min-h-[54px] px-4 py-3 text-center font-mono text-2xl font-semibold tracking-[0.42em] text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-slate-900 placeholder:text-slate-300"
                  />
                </div>

                <button
                  type="submit"
                  disabled={securityVerifying || codeInput.length !== 6}
                  className="w-full min-h-[48px] px-4 py-3 bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>
                    {securityVerifying ? 'Verifying Code...' : 'Verify & Unlock (24 Hours)'}
                  </span>
                </button>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 pt-1">
                  <button
                    type="button"
                    disabled={
                      securityCodeSending ||
                      securityCooldownSeconds > 0 ||
                      (!gmailConnected && !smtpConfigured)
                    }
                    onClick={() => requestSecurityCode()}
                    className="min-h-[44px] px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${securityCodeSending ? 'animate-spin' : ''}`}
                    />
                    <span>
                      {securityCooldownSeconds > 0
                        ? `Resend Code (${securityCooldownSeconds}s)`
                        : 'Resend Code to Gmail'}
                    </span>
                  </button>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      disabled={googleConnecting}
                      onClick={() => switchGoogleAccount(true)}
                      className="min-h-[44px] px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl flex items-center justify-center gap-1.5"
                    >
                      <ArrowLeftRight className="w-3.5 h-3.5 shrink-0" />
                      <span>Switch</span>
                    </button>
                    <button
                      type="button"
                      onClick={disconnectGoogle}
                      className="min-h-[44px] px-3 py-2 text-xs font-medium text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl flex items-center justify-center gap-1.5"
                    >
                      <LogOut className="w-3.5 h-3.5 shrink-0" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
