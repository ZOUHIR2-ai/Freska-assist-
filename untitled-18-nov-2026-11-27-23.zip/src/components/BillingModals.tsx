import React, { useEffect, useRef, useState } from 'react';
import { X, Copy, Check, ExternalLink, AlertCircle, Mail, CheckCircle2 } from 'lucide-react';
import { saveEntity } from '../lib/storeClient.ts';
import {
  confirmPaymentAndGenerateInvoice,
  createBankTransferPaymentUrl,
  generateId,
  logEmailDispatch,
  STANDARD_PACKAGES,
  todayIsoDate,
  addDays,
} from '../lib/billingEngine.ts';
import { createHostedCheckoutSession, sendGmailMessage } from '../lib/api.ts';
import { interpolateTemplate } from '../lib/templates.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import type {
  BillingType,
  PaymentMethod,
  PaymentRequestRecord,
} from '../types/freska.ts';

interface PaymentLinkModalProps {
  open: boolean;
  presetClientId?: string | null;
  presetSubscriptionId?: string | null;
  onClose: () => void;
  onSendEmailRequest?: (req: PaymentRequestRecord) => void;
}

export const PaymentLinkModal: React.FC<PaymentLinkModalProps> = ({
  open,
  presetClientId,
  presetSubscriptionId,
  onClose,
  onSendEmailRequest,
}) => {
  const {
    clients,
    services,
    subscriptions,
    emailTemplates,
    gatewayDbSettings,
    gatewayServerStatus,
    systemSettings,
    emailDeliveryActive,
    smtpStatus,
    gmailEmail,
    reconnectGmail,
    googleConnecting,
    notify,
  } = useFreska();

  const [clientId, setClientId] = useState('');
  const [serviceId, setServiceId] = useState('');
  const [subscriptionId, setSubscriptionId] = useState('');
  const [serviceName, setServiceName] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState(systemSettings.defaultCurrency || 'EUR');
  const [billingType, setBillingType] = useState<BillingType>('subscription');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('bank_transfer');
  const [dueDate, setDueDate] = useState(addDays(todayIsoDate(), 7));
  const [reference, setReference] = useState('');
  const [sendViaGmail, setSendViaGmail] = useState(true);
  const [creating, setCreating] = useState(false);
  const [createdReq, setCreatedReq] = useState<PaymentRequestRecord | null>(null);
  const [emailOutcome, setEmailOutcome] = useState<
    | { status: 'sent'; recipient: string }
    | { status: 'failed'; error: string }
    | { status: 'skipped'; reason: string }
    | null
  >(null);
  const [copied, setCopied] = useState(false);

  const prevOpenRef = useRef(false);

  const cardPaymentsActive = Boolean(
    gatewayServerStatus?.enabled && gatewayServerStatus?.connectionVerified
  );

  const applyClientDefaults = (targetClientId: string, explicitSubId?: string | null) => {
    const clientObj = clients.find((c) => c.id === targetClientId);
    const matchingSub =
      (explicitSubId ? subscriptions.find((s) => s.id === explicitSubId) : undefined) ||
      subscriptions.find((s) => s.clientId === targetClientId && s.status !== 'cancelled');

    if (matchingSub) {
      setSubscriptionId(matchingSub.id);
      setServiceId(matchingSub.serviceId || STANDARD_PACKAGES.subscription.id);
      setServiceName(matchingSub.name);
      setDescription(matchingSub.description || '');
      setAmount(String(matchingSub.monthlyPrice));
      setCurrency(matchingSub.currency || 'EUR');
      setBillingType('subscription');
      setPaymentMethod(
        matchingSub.paymentMethod === 'card' && !cardPaymentsActive
          ? 'bank_transfer'
          : matchingSub.paymentMethod
      );
      setDueDate(matchingSub.nextPaymentDate || addDays(todayIsoDate(), 7));
    } else {
      const pkg = STANDARD_PACKAGES.one_time;
      setSubscriptionId('');
      setServiceId(pkg.id);
      setServiceName(pkg.name);
      setDescription(pkg.description);
      setAmount(String(pkg.defaultPrice));
      setCurrency(clientObj?.preferredCurrency || systemSettings.defaultCurrency || 'EUR');
      setBillingType('one_time');
      setPaymentMethod('bank_transfer');
      setDueDate(addDays(todayIsoDate(), 7));
    }
  };

  useEffect(() => {
    const wasOpen = prevOpenRef.current;
    prevOpenRef.current = open;
    if (!open || wasOpen) return;

    setCreatedReq(null);
    setEmailOutcome(null);
    setCopied(false);
    setSendViaGmail(emailDeliveryActive);

    const defClient = presetClientId || clients.find((c) => c.status !== 'archived')?.id || '';
    setClientId(defClient);
    applyClientDefaults(defClient, presetSubscriptionId);
    setReference(`FA-REF-${Math.floor(100000 + Math.random() * 900000)}`);
  }, [open]);

  useEffect(() => {
    if (open && emailDeliveryActive && !createdReq) {
      setSendViaGmail(true);
    }
  }, [open, emailDeliveryActive, createdReq]);

  if (!open) return null;

  const selectedClient = clients.find((c) => c.id === clientId);
  const clientSubs = subscriptions.filter(
    (s) => s.clientId === clientId && s.status !== 'cancelled'
  );

  const handleSelectClient = (nextClientId: string) => {
    setClientId(nextClientId);
    applyClientDefaults(nextClientId, null);
  };

  const handleSelectService = (svcId: string) => {
    setServiceId(svcId);
    const svc = services.find((s) => s.id === svcId);
    if (svc) {
      setServiceName(svc.name);
      setDescription(svc.description || '');
      setAmount(String(svc.defaultPrice));
      setCurrency(svc.currency);
      setBillingType(svc.billingType);
    }
  };

  const handleSelectSub = (subId: string) => {
    setSubscriptionId(subId);
    const sub = subscriptions.find((s) => s.id === subId);
    if (sub) {
      setServiceName(sub.name);
      setDescription(sub.description || '');
      setAmount(String(sub.monthlyPrice));
      setCurrency(sub.currency);
      setBillingType('subscription');
      setDueDate(sub.nextPaymentDate);
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find((c) => c.id === clientId);
    const numAmount = Number(amount);

    if (!client || !serviceName.trim() || Number.isNaN(numAmount) || numAmount <= 0) {
      notify('error', 'Select a client, service name, and amount greater than 0.');
      return;
    }

    setCreating(true);
    try {
      const requestId = generateId('req');
      let paymentUrl = '';
      let gatewaySessionId = '';

      if (paymentMethod === 'card' && cardPaymentsActive) {
        const checkout = await createHostedCheckoutSession({
          paymentRequestId: requestId,
          clientId: client.id,
          clientEmail: client.email,
          serviceName: serviceName.trim(),
          description: description.trim(),
          amount: numAmount,
          currency,
          billingType,
          subscriptionId: subscriptionId || undefined,
        });
        paymentUrl = checkout.checkoutUrl;
        gatewaySessionId = checkout.sessionId;
      } else if (paymentMethod === 'bank_transfer' || paymentMethod === 'card') {
        paymentUrl = await createBankTransferPaymentUrl({
          requestId,
          reference: reference.trim(),
          client,
          serviceName: serviceName.trim(),
          description: description.trim(),
          amount: numAmount,
          currency,
          dueDate,
          billingType,
          subscriptionId: subscriptionId || undefined,
          gatewaySettings: gatewayDbSettings,
          systemSettings,
        });
      }

      const record: PaymentRequestRecord = {
        id: requestId,
        clientId: client.id,
        subscriptionId: subscriptionId || '',
        serviceId: serviceId || '',
        serviceName: serviceName.trim(),
        description: description.trim(),
        billingType,
        paymentMethod,
        reference: reference.trim(),
        amount: numAmount,
        currency,
        dueDate,
        paymentUrl,
        gatewaySessionId,
        status: 'pending',
      };

      await saveEntity('payment_requests', requestId, { ...record }, { isNew: true });

      // Automatically send the payment link to the client when enabled & active
      if (sendViaGmail && emailDeliveryActive && client.email && record.paymentUrl) {
        const tpl = emailTemplates.find((t) => t.templateKey === 'payment_link');
        const ctx = {
          client_name: client.fullName,
          business_name: client.businessName,
          service_name: record.serviceName,
          amount: record.amount.toFixed(2),
          currency: record.currency,
          payment_link: record.paymentUrl,
          due_date: record.dueDate,
        };
        const subject = interpolateTemplate(
          tpl?.subject || 'Billing summary for {{business_name}} — {{service_name}}',
          ctx
        );
        const bodyText = interpolateTemplate(
          tpl?.body ||
            'Hello {{client_name}},\n\nAmount: {{amount}} {{currency}}\nDue date: {{due_date}}\n\nPayment link:\n{{payment_link}}',
          ctx
        );

        try {
          const sentRes = await sendGmailMessage({
            to: client.email,
            subject,
            bodyText,
            senderDisplayName: tpl?.senderDisplayName || 'FreskaAssist',
          });
          await logEmailDispatch({
            clientId: client.id,
            recipient: client.email,
            subject,
            emailType: 'payment_link',
            status: 'sent',
            gmailMessageId: sentRes.messageId,
          });
          setEmailOutcome({ status: 'sent', recipient: client.email });
          notify('success', `Payment link created & emailed to ${client.email}.`);
        } catch (emailErr) {
          const msg = emailErr instanceof Error ? emailErr.message : 'Gmail dispatch failed';
          await logEmailDispatch({
            clientId: client.id,
            recipient: client.email,
            subject,
            emailType: 'payment_link',
            status: 'failed',
            errorMessage: msg,
          });
          setEmailOutcome({ status: 'failed', error: msg });
          notify('error', `Payment link created, but email failed: ${msg}`);
        }
      } else {
        const reason = !record.paymentUrl
          ? 'Manual payment request has no external checkout URL.'
          : !client.email
          ? 'Client does not have an email address.'
          : !emailDeliveryActive
          ? 'No active email sender (enable SMTP Relay or connect Gmail).'
          : 'Auto-send option was unchecked.';
        setEmailOutcome({ status: 'skipped', reason });
        notify('success', `Payment request ${record.reference} created.`);
      }

      setCreatedReq(record);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to create payment request');
    } finally {
      setCreating(false);
    }
  };

  const handleCopy = () => {
    if (!createdReq?.paymentUrl) return;
    navigator.clipboard.writeText(createdReq.paymentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/40 backdrop-blur-[1px] p-2 sm:p-4">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl sm:rounded-xl shadow-lg overflow-hidden max-h-[92dvh] flex flex-col">
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200 shrink-0">
          <h2 className="text-base font-semibold text-slate-900">Generate Payment Request</h2>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-2 -mr-1 rounded min-h-[40px] min-w-[40px] flex items-center justify-center"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {createdReq ? (
          <div className="p-4 sm:p-6 space-y-5 overflow-y-auto">
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg">
              <p className="text-sm font-semibold text-emerald-900">
                Payment Request Ready · {createdReq.reference}
              </p>
              <p className="text-xs text-emerald-800 mt-1">
                Status is PENDING until payment is verified or completed via checkout.
              </p>
            </div>

            {emailOutcome?.status === 'sent' && (
              <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-950 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">Sent to Client via Gmail</p>
                  <p className="text-blue-800 mt-0.5">
                    The payment link email was dispatched to{' '}
                    <span className="font-mono font-medium">{emailOutcome.recipient}</span>.
                  </p>
                </div>
              </div>
            )}

            {emailOutcome?.status === 'failed' && (
              <div className="p-3.5 bg-red-50 border border-red-200 rounded-lg text-xs text-red-900 flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">Automatic Email Failed</p>
                  <p className="mt-0.5">{emailOutcome.error}</p>
                </div>
              </div>
            )}

            {emailOutcome?.status === 'skipped' && (
              <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">Link Created (Not Emailed Automatically)</p>
                  <p className="mt-0.5">{emailOutcome.reason}</p>
                </div>
              </div>
            )}

            {createdReq.paymentUrl ? (
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  {createdReq.paymentMethod === 'card' && cardPaymentsActive
                    ? 'Hosted Card Checkout URL'
                    : 'Client Payment Link (Bank Transfer + Test Card Checkout)'}
                </label>
                <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={createdReq.paymentUrl}
                    className="w-full sm:flex-1 min-h-[44px] sm:min-h-0 px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-lg text-slate-800"
                  />
                  <div className="grid grid-cols-2 sm:flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={handleCopy}
                      className="min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50 whitespace-nowrap"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Copied' : 'Copy Link'}</span>
                    </button>
                    <a
                      href={createdReq.paymentUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50 whitespace-nowrap"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Open</span>
                    </a>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-sm text-slate-600">
                Manual payment request logged. Confirm payment once funds are received.
              </p>
            )}

            <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2.5 sm:gap-3 pt-4 border-t border-slate-200">
              {onSendEmailRequest && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onSendEmailRequest(createdReq);
                  }}
                  className="w-full sm:w-auto min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>
                    {emailOutcome?.status === 'sent'
                      ? 'Resend / Edit in Email Composer'
                      : 'Send Payment Link via Gmail'}
                  </span>
                </button>
              )}
              <button
                type="button"
                onClick={onClose}
                className="w-full sm:w-auto min-h-[44px] sm:min-h-0 px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleGenerate} className="overflow-y-auto p-4 sm:p-6 space-y-4">
            <div className="flex flex-wrap items-center gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
              <span className="text-[11px] font-medium text-slate-600 mr-1">Quick Package:</span>
              <button
                type="button"
                onClick={() => {
                  const pkg = STANDARD_PACKAGES.subscription;
                  setServiceId(pkg.id);
                  setServiceName(pkg.name);
                  setDescription(pkg.description);
                  setAmount(String(pkg.defaultPrice));
                  setCurrency(pkg.currency);
                  setBillingType('subscription');
                }}
                className={`px-2.5 py-1 text-xs font-medium rounded-md border ${
                  billingType === 'subscription' && Number(amount) === 599
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                }`}
              >
                Subscription · 599€
              </button>
              <button
                type="button"
                onClick={() => {
                  const pkg = STANDARD_PACKAGES.one_time;
                  setSubscriptionId('');
                  setServiceId(pkg.id);
                  setServiceName(pkg.name);
                  setDescription(pkg.description);
                  setAmount(String(pkg.defaultPrice));
                  setCurrency(pkg.currency);
                  setBillingType('one_time');
                }}
                className={`px-2.5 py-1 text-xs font-medium rounded-md border ${
                  billingType === 'one_time' && Number(amount) === 1199
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                }`}
              >
                One-Time · 1,199€
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Client *</label>
                <select
                  required
                  value={clientId}
                  onChange={(e) => handleSelectClient(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="">Select client...</option>
                  {clients
                    .filter((c) => c.status !== 'archived')
                    .map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.businessName} ({c.fullName})
                      </option>
                    ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Link to Subscription (Optional)
                </label>
                <select
                  value={subscriptionId}
                  onChange={(e) => handleSelectSub(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="">None / One-Time or Custom</option>
                  {clientSubs.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.monthlyPrice} {s.currency})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Service Catalog (Optional)
                </label>
                <select
                  value={serviceId}
                  onChange={(e) => handleSelectService(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="">Custom service...</option>
                  {services
                    .filter((s) => s.active)
                    .map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.defaultPrice} {s.currency})
                      </option>
                    ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Service / Item Name *
                </label>
                <input
                  type="text"
                  required
                  value={serviceName}
                  onChange={(e) => setServiceName(e.target.value)}
                  placeholder="Website Maintenance"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Amount *</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Currency</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="EUR">EUR</option>
                  <option value="USD">USD</option>
                  <option value="GBP">GBP</option>
                  <option value="CAD">CAD</option>
                  <option value="MAD">MAD</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Billing Type
                </label>
                <select
                  value={billingType}
                  onChange={(e) => setBillingType(e.target.value as BillingType)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="subscription">Subscription</option>
                  <option value="one_time">One-Time Purchase</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Due Date</label>
                <input
                  type="date"
                  required
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Payment Method
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="bank_transfer">
                    Bank Transfer + {cardPaymentsActive ? 'Card Checkout' : 'Card Checkout (Test Mode)'}
                  </option>
                  <option value="card">
                    Credit / Debit Card {cardPaymentsActive ? '(Stripe Live)' : '(Test Checkout Mode)'}
                  </option>
                  <option value="manual">Manual Payment Record</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Payment Reference *
                </label>
                <input
                  type="text"
                  required
                  value={reference}
                  onChange={(e) => setReference(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            {!cardPaymentsActive && paymentMethod !== 'manual' && (
              <div className="flex items-start gap-2.5 p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-slate-500" />
                <span>
                  {!gatewayDbSettings.bankIban
                    ? 'Card Checkout runs in Test Mode until Stripe is connected. Bank IBAN can also be configured in Payment Settings so clients see both transfer and test card options.'
                    : 'This hosted link includes both your Bank Transfer (Virement) instructions and a Test Card Checkout until live gateway credentials are connected.'}
                </span>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Optional Description
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Billing cycle period or deliverable details..."
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>

            {paymentMethod !== 'manual' && (
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                {emailDeliveryActive ? (
                  <label className="flex items-start gap-2.5 text-xs text-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={sendViaGmail}
                      onChange={(e) => setSendViaGmail(e.target.checked)}
                      className="mt-0.5 rounded border-slate-300 text-slate-900"
                    />
                    <span>
                      Send payment link automatically via{' '}
                      <span className="font-mono">
                        {smtpStatus?.enabled && smtpStatus?.connectionVerified
                          ? smtpStatus.fromEmail
                          : gmailEmail || 'connected'}
                      </span>{' '}
                      to{' '}
                      <span className="font-mono font-medium">
                        {selectedClient?.email || 'selected client'}
                      </span>
                    </span>
                  </label>
                ) : (
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-amber-900">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                      <span>
                        No email sender is active yet, so generating will only create the link
                        unless you enable SMTP Relay or authorize Gmail first.
                      </span>
                    </div>
                    <button
                      type="button"
                      disabled={googleConnecting}
                      onClick={() => reconnectGmail()}
                      className="px-3 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md whitespace-nowrap disabled:opacity-50"
                    >
                      {googleConnecting ? 'Authorizing...' : 'Authorize Gmail'}
                    </button>
                  </div>
                )}
              </div>
            )}

            <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2.5 sm:gap-3 pt-4 border-t border-slate-200">
              <button
                type="button"
                onClick={onClose}
                className="w-full sm:w-auto min-h-[44px] sm:min-h-0 px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={creating}
                className="w-full sm:w-auto min-h-[44px] sm:min-h-0 px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
              >
                {creating
                  ? sendViaGmail && emailDeliveryActive && paymentMethod !== 'manual'
                    ? 'Generating & Sending...'
                    : 'Generating...'
                  : sendViaGmail && emailDeliveryActive && paymentMethod !== 'manual' && selectedClient?.email
                  ? 'Generate & Send Payment Link'
                  : 'Generate Payment Link'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

interface ManualPaymentModalProps {
  open: boolean;
  presetClientId?: string | null;
  presetSubscriptionId?: string | null;
  onClose: () => void;
}

export const ManualPaymentModal: React.FC<ManualPaymentModalProps> = ({
  open,
  presetClientId,
  presetSubscriptionId,
  onClose,
}) => {
  const {
    clients,
    subscriptions,
    invoices,
    systemSettings,
    emailTemplates,
    emailDeliveryActive,
    notify,
  } = useFreska();

  const [clientId, setClientId] = useState('');
  const [subscriptionId, setSubscriptionId] = useState('');
  const [billingType, setBillingType] = useState<BillingType>('one_time');
  const [serviceName, setServiceName] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState(systemSettings.defaultCurrency || 'EUR');
  const [paymentDate, setPaymentDate] = useState(todayIsoDate());
  const [transactionReference, setTransactionReference] = useState('');
  const [notes, setNotes] = useState('');
  const [sendEmail, setSendEmail] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!open) return;
    const defClient = presetClientId || clients.find((c) => c.status !== 'archived')?.id || '';
    const clientObj = clients.find((c) => c.id === defClient);
    setClientId(defClient);
    setSubscriptionId(presetSubscriptionId || '');
    if (presetSubscriptionId) {
      const sub = subscriptions.find((s) => s.id === presetSubscriptionId);
      if (sub) {
        setBillingType('subscription');
        setServiceName(sub.name);
        setDescription(sub.description || '');
        setAmount(String(sub.monthlyPrice));
        setCurrency(sub.currency);
      }
    } else {
      const pkg = STANDARD_PACKAGES.one_time;
      setBillingType('one_time');
      setServiceName(pkg.name);
      setDescription(pkg.description);
      setAmount(String(pkg.defaultPrice));
      setCurrency(clientObj?.preferredCurrency || systemSettings.defaultCurrency || 'EUR');
    }
    setPaymentDate(todayIsoDate());
    setTransactionReference(`MAN-${Math.floor(100000 + Math.random() * 900000)}`);
    setNotes('');
    setSendEmail(emailDeliveryActive);
    setConfirmed(false);
  }, [
    open,
    presetClientId,
    presetSubscriptionId,
    clients,
    subscriptions,
    systemSettings.defaultCurrency,
    emailDeliveryActive,
  ]);

  if (!open) return null;

  const clientSubs = subscriptions.filter(
    (s) => s.clientId === clientId && s.status !== 'cancelled'
  );

  const handleSelectSub = (subId: string) => {
    setSubscriptionId(subId);
    const sub = subscriptions.find((s) => s.id === subId);
    if (sub) {
      setBillingType('subscription');
      setServiceName(sub.name);
      setDescription(sub.description || '');
      setAmount(String(sub.monthlyPrice));
      setCurrency(sub.currency);
    } else {
      setBillingType('one_time');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find((c) => c.id === clientId);
    const numAmount = Number(amount);

    if (!confirmed) {
      notify('error', 'Explicit administrator confirmation is required before recording payment.');
      return;
    }
    if (!client || !serviceName.trim() || Number.isNaN(numAmount) || numAmount <= 0) {
      notify('error', 'Select client, service description, and a valid payment amount.');
      return;
    }

    setSubmitting(true);
    try {
      const sub = subscriptionId
        ? subscriptions.find((s) => s.id === subscriptionId) || null
        : null;

      const res = await confirmPaymentAndGenerateInvoice({
        client,
        amount: numAmount,
        currency,
        serviceName: serviceName.trim(),
        serviceDescription: description.trim(),
        billingType,
        paymentMethod: 'manual',
        paymentDate,
        transactionReference: transactionReference.trim(),
        manuallyVerified: true,
        notes: notes.trim(),
        subscription: sub,
        existingInvoices: invoices,
        systemSettings,
        templates: emailTemplates,
        sendConfirmationEmail: sendEmail,
      });

      notify(
        'success',
        `Manual payment confirmed & Invoice ${res.invoiceNumber} generated.${
          res.emailSent ? ' Sent via Gmail.' : ''
        }`
      );
      if (res.emailError) {
        notify('error', `Invoice created, but Gmail dispatch failed: ${res.emailError}`);
      }
      onClose();
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to register payment');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/40 backdrop-blur-[1px] p-2 sm:p-4">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl sm:rounded-xl shadow-lg overflow-hidden max-h-[92dvh] flex flex-col">
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200 shrink-0">
          <h2 className="text-base font-semibold text-slate-900 truncate pr-2">
            Register Manual Payment / One-Time Purchase
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-2 -mr-1 rounded min-h-[40px] min-w-[40px] flex items-center justify-center"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto p-4 sm:p-6 space-y-4">
          <div className="flex flex-wrap items-center gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
            <span className="text-[11px] font-medium text-slate-600 mr-1">Quick Package:</span>
            <button
              type="button"
              onClick={() => {
                const pkg = STANDARD_PACKAGES.subscription;
                setBillingType('subscription');
                setServiceName(pkg.name);
                setDescription(pkg.description);
                setAmount(String(pkg.defaultPrice));
                setCurrency(pkg.currency);
              }}
              className={`px-2.5 py-1 text-xs font-medium rounded-md border ${
                billingType === 'subscription' && Number(amount) === 599
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
              }`}
            >
              Subscription · 599€
            </button>
            <button
              type="button"
              onClick={() => {
                const pkg = STANDARD_PACKAGES.one_time;
                setSubscriptionId('');
                setBillingType('one_time');
                setServiceName(pkg.name);
                setDescription(pkg.description);
                setAmount(String(pkg.defaultPrice));
                setCurrency(pkg.currency);
              }}
              className={`px-2.5 py-1 text-xs font-medium rounded-md border ${
                billingType === 'one_time' && Number(amount) === 1199
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
              }`}
            >
              One-Time · 1,199€
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Client *</label>
              <select
                required
                value={clientId}
                onChange={(e) => setClientId(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                <option value="">Select client...</option>
                {clients
                  .filter((c) => c.status !== 'archived')
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.businessName} ({c.fullName})
                    </option>
                  ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Apply to Subscription (Optional)
              </label>
              <select
                value={subscriptionId}
                onChange={(e) => handleSelectSub(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                <option value="">One-Time Purchase (No recurring reminders)</option>
                {clientSubs.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.monthlyPrice} {s.currency})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Service / Payment Description *
              </label>
              <input
                type="text"
                required
                value={serviceName}
                onChange={(e) => setServiceName(e.target.value)}
                placeholder="Cash / Wire / Offline Service Purchase"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Amount *</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Currency</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full px-2 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="EUR">EUR</option>
                  <option value="USD">USD</option>
                  <option value="GBP">GBP</option>
                  <option value="CAD">CAD</option>
                  <option value="MAD">MAD</option>
                </select>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Payment Date *
              </label>
              <input
                type="date"
                required
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Transaction Reference *
              </label>
              <input
                type="text"
                required
                value={transactionReference}
                onChange={(e) => setTransactionReference(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Detailed Description / Line Item Note
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Appears on generated PDF invoice"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Internal Notes</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Received via cash, check, or direct offline transfer..."
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>

          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2.5">
            <label className="flex items-start gap-2.5 text-sm text-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={confirmed}
                onChange={(e) => setConfirmed(e.target.checked)}
                className="mt-1 rounded border-slate-300 text-slate-900"
              />
              <span>
                I explicitly confirm that this offline/manual payment has been received. This
                transaction will be marked as manually verified and an official PAID invoice will be
                generated immediately.
              </span>
            </label>

            <label className="flex items-center gap-2.5 text-sm text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={sendEmail}
                disabled={!emailDeliveryActive}
                onChange={(e) => setSendEmail(e.target.checked)}
                className="rounded border-slate-300 text-slate-900 disabled:opacity-50"
              />
              <span>
                Send generated PDF invoice to client{' '}
                {!emailDeliveryActive && '(Enable SMTP or connect Gmail first)'}
              </span>
            </label>
          </div>

          <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2.5 sm:gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto min-h-[44px] sm:min-h-0 px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || !confirmed}
              className="w-full sm:w-auto min-h-[44px] sm:min-h-0 px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
            >
              {submitting ? 'Confirming...' : 'Confirm Payment & Generate Invoice'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface VerifyTransferModalProps {
  request: PaymentRequestRecord | null;
  onClose: () => void;
}

export const VerifyTransferModal: React.FC<VerifyTransferModalProps> = ({ request, onClose }) => {
  const {
    clients,
    subscriptions,
    invoices,
    systemSettings,
    emailTemplates,
    emailDeliveryActive,
    notify,
  } = useFreska();

  const [confirmationDate, setConfirmationDate] = useState(todayIsoDate());
  const [transactionReference, setTransactionReference] = useState('');
  const [sendEmail, setSendEmail] = useState(false);
  const [verifying, setVerifying] = useState(false);

  useEffect(() => {
    if (!request) return;
    setConfirmationDate(todayIsoDate());
    setTransactionReference(request.reference);
    setSendEmail(emailDeliveryActive);
  }, [request, emailDeliveryActive]);

  if (!request) return null;

  const client = clients.find((c) => c.id === request.clientId);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!client) {
      notify('error', 'Client record not found for this payment request.');
      return;
    }

    setVerifying(true);
    try {
      const sub = request.subscriptionId
        ? subscriptions.find((s) => s.id === request.subscriptionId) || null
        : null;

      const res = await confirmPaymentAndGenerateInvoice({
        client,
        amount: request.amount,
        currency: request.currency,
        serviceName: request.serviceName,
        serviceDescription: request.description,
        billingType: request.billingType,
        paymentMethod: 'bank_transfer',
        paymentDate: confirmationDate,
        transactionReference: transactionReference.trim() || request.reference,
        manuallyVerified: true,
        subscription: sub,
        paymentRequest: request,
        existingInvoices: invoices,
        systemSettings,
        templates: emailTemplates,
        sendConfirmationEmail: sendEmail,
      });

      notify(
        'success',
        `Bank transfer verified & Invoice ${res.invoiceNumber} generated.${
          res.emailSent ? ' Sent via Gmail.' : ''
        }`
      );
      if (res.emailError) {
        notify('error', `Invoice created, but Gmail send failed: ${res.emailError}`);
      }
      onClose();
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to verify bank transfer');
    } finally {
      setVerifying(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/40 backdrop-blur-[1px] p-2 sm:p-4">
      <div className="w-full max-w-lg bg-white border border-slate-200 rounded-2xl sm:rounded-xl shadow-lg overflow-hidden max-h-[92dvh] flex flex-col">
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200 shrink-0">
          <h2 className="text-base font-semibold text-slate-900">Verify Received Bank Transfer</h2>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-2 -mr-1 rounded min-h-[40px] min-w-[40px] flex items-center justify-center"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleVerify} className="overflow-y-auto p-4 sm:p-6 space-y-4">
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-sm space-y-1">
            <p className="font-semibold text-slate-900">
              {client?.businessName || 'Client'} · {request.serviceName}
            </p>
            <p className="text-slate-600 tabular-nums font-mono text-xs break-words">
              Amount: {request.amount.toFixed(2)} {request.currency} · Request Ref: {request.reference}
            </p>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Bank Confirmation Date *
            </label>
            <input
              type="date"
              required
              value={confirmationDate}
              onChange={(e) => setConfirmationDate(e.target.value)}
              className="w-full min-h-[44px] sm:min-h-0 px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Bank Transaction Reference *
            </label>
            <input
              type="text"
              required
              value={transactionReference}
              onChange={(e) => setTransactionReference(e.target.value)}
              className="w-full min-h-[44px] sm:min-h-0 px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg"
            />
          </div>

          <label className="flex items-center gap-2.5 text-sm text-slate-700 cursor-pointer pt-1">
            <input
              type="checkbox"
              checked={sendEmail}
              disabled={!emailDeliveryActive}
              onChange={(e) => setSendEmail(e.target.checked)}
              className="rounded border-slate-300 text-slate-900 disabled:opacity-50"
            />
            <span>
              Send invoice &amp; payment confirmation email{' '}
              {!emailDeliveryActive && '(Email sender inactive)'}
            </span>
          </label>

          <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2.5 sm:gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto min-h-[44px] sm:min-h-0 px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={verifying}
              className="w-full sm:w-auto min-h-[44px] sm:min-h-0 px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
            >
              {verifying ? 'Verifying...' : 'Confirm Transfer & Issue Invoice'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
