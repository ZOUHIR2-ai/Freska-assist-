import React, { useState } from 'react';
import {
  LayoutDashboard,
  Users,
  RefreshCw,
  CreditCard,
  FileText,
  Mail,
  Bell,
  Sliders,
  Inbox,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronRight,
  ArrowLeftRight,
  Link2,
  Cloud,
  CloudOff,
  Lock,
} from 'lucide-react';
import { useFreska } from '../context/FreskaContext.tsx';
import type { NavSection } from '../types/freska.ts';

const NAV_ITEMS: Array<{
  id: NavSection;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'clients', label: 'Clients', icon: Users },
  { id: 'subscriptions', label: 'Subscriptions', icon: RefreshCw },
  { id: 'payments', label: 'Payments', icon: CreditCard },
  { id: 'invoices', label: 'Invoices', icon: FileText },
  { id: 'email_center', label: 'Email Center', icon: Mail },
  { id: 'reminders', label: 'Reminders', icon: Bell },
  { id: 'payment_settings', label: 'Payment Settings', icon: Sliders },
  { id: 'gmail_integration', label: 'Gmail Integration', icon: Inbox },
  { id: 'settings', label: 'Settings & Security', icon: Settings },
];

const MOBILE_BOTTOM_TABS: Array<{
  id: NavSection;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  { id: 'overview', label: 'Home', icon: LayoutDashboard },
  { id: 'clients', label: 'Clients', icon: Users },
  { id: 'payments', label: 'Payments', icon: CreditCard },
  { id: 'invoices', label: 'Invoices', icon: FileText },
];

interface SidebarLayoutProps {
  children: React.ReactNode;
  primaryAction?: React.ReactNode;
  breadcrumb?: string;
}

export const SidebarLayout: React.FC<SidebarLayoutProps> = ({
  children,
  primaryAction,
  breadcrumb,
}) => {
  const {
    user,
    authLoading,
    gmailConnected,
    smtpStatus,
    googleConnecting,
    activeSection,
    setActiveSection,
    selectedClientId,
    clients,
    connectGoogle,
    switchGoogleAccount,
    disconnectGoogle,
    lockPlatformNow,
    cloudSyncStatus,
    syncToCloudNow,
    toasts,
    dismissToast,
  } = useFreska();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const activeNavLabel =
    activeSection === 'client_profile'
      ? 'Clients'
      : NAV_ITEMS.find((n) => n.id === activeSection)?.label || 'Overview';

  const selectedClient = selectedClientId
    ? clients.find((c) => c.id === selectedClientId)
    : null;

  const handleSelectNav = (id: NavSection) => {
    setActiveSection(id);
    setMobileMenuOpen(false);
  };

  const renderGoogleFooter = () => {
    if (!user) {
      return (
        <div className="space-y-2.5">
          <div className="min-w-0">
            <p className="text-xs font-medium text-slate-200">Google Account</p>
            <p className="text-[11px] text-slate-400">Not connected</p>
          </div>
          <button
            type="button"
            onClick={() => handleSelectNav('gmail_integration')}
            className="w-full min-h-[44px] flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap"
          >
            <Link2 className="w-3.5 h-3.5 shrink-0" />
            <span>Connect Google Account</span>
          </button>
        </div>
      );
    }

    return (
      <div className="space-y-2.5">
        <div className="flex items-center gap-3">
          {user.photoURL ? (
            <img
              src={user.photoURL}
              alt={user.displayName || 'Google Account'}
              referrerPolicy="no-referrer"
              className="w-8 h-8 rounded-full object-cover border border-slate-700 shrink-0"
            />
          ) : (
            <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-semibold text-slate-200 shrink-0">
              {(user.displayName || user.email || 'G').charAt(0).toUpperCase()}
            </div>
          )}
          <div className="min-w-0 flex-1">
            <p className="text-xs font-medium text-white truncate">
              {user.displayName || 'Google Account'}
            </p>
            <p className="text-[11px] text-slate-400 truncate">{user.email}</p>
            <p className="text-[10px] text-slate-400 truncate mt-0.5">
              {smtpStatus?.enabled && smtpStatus?.connectionVerified
                ? `SMTP Active (${smtpStatus.fromEmail})`
                : gmailConnected
                ? 'Gmail Send Active'
                : 'Profile linked · Email inactive'}
            </p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          <button
            type="button"
            disabled={googleConnecting}
            onClick={() => switchGoogleAccount(true)}
            className="min-h-[40px] flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-[11px] font-medium text-slate-200 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors whitespace-nowrap disabled:opacity-50"
          >
            <ArrowLeftRight className="w-3 h-3 shrink-0" />
            <span>Change</span>
          </button>
          <button
            type="button"
            onClick={disconnectGoogle}
            className="min-h-[40px] flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-[11px] font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors whitespace-nowrap"
          >
            <LogOut className="w-3 h-3 shrink-0" />
            <span>Disconnect</span>
          </button>
        </div>
        <button
          type="button"
          onClick={() => {
            setMobileMenuOpen(false);
            lockPlatformNow();
          }}
          className="w-full min-h-[40px] flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-[11px] font-medium text-slate-200 hover:text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors whitespace-nowrap"
        >
          <Lock className="w-3 h-3 shrink-0" />
          <span>Lock Workspace (24h Code)</span>
        </button>
      </div>
    );
  };

  const isDrawerSectionActive = !MOBILE_BOTTOM_TABS.some(
    (t) => t.id === activeSection || (t.id === 'clients' && activeSection === 'client_profile')
  );

  return (
    <div className="min-h-[100dvh] bg-slate-50 text-slate-900 flex overflow-x-hidden">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 bg-slate-950 text-slate-100 border-r border-slate-800">
        <div className="h-16 px-6 flex items-center border-b border-slate-800/80">
          <button
            type="button"
            onClick={() => handleSelectNav('overview')}
            className="flex items-center gap-2.5 text-left focus:outline-none"
          >
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden="true"
              className="shrink-0"
            >
              <rect width="24" height="24" rx="6" fill="#2563EB" />
              <path
                d="M7 7.5H17M7 12H14M7 7.5V17"
                stroke="white"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <span className="text-base font-semibold tracking-tight text-white whitespace-nowrap">
              FreskaAssist
            </span>
          </button>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto" aria-label="Primary Navigation">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isCurrent =
              activeSection === item.id ||
              (activeSection === 'client_profile' && item.id === 'clients');
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectNav(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                  isCurrent
                    ? 'bg-slate-800 text-white'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-800/80">{renderGoogleFooter()}</div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/60"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-72 max-w-[85vw] bg-slate-950 text-slate-100 flex flex-col z-10 h-full">
            <div className="h-14 px-5 flex items-center justify-between border-b border-slate-800 shrink-0">
              <span className="text-base font-semibold text-white">FreskaAssist</span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-400 hover:text-white -mr-2"
                aria-label="Close navigation"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 px-3 py-3 space-y-1 overflow-y-auto">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isCurrent =
                  activeSection === item.id ||
                  (activeSection === 'client_profile' && item.id === 'clients');
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectNav(item.id)}
                    className={`w-full min-h-[44px] flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg ${
                      isCurrent ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-4 border-t border-slate-800 shrink-0">{renderGoogleFooter()}</div>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <header className="sticky top-0 z-30 h-12 lg:h-16 bg-white border-b border-slate-200 px-3 sm:px-6 lg:px-8 flex items-center justify-between gap-2 sm:gap-4">
          <div className="flex items-center gap-2 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-600 hover:text-slate-900 rounded-lg -ml-1.5"
              aria-label="Open navigation"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-1.5 text-sm min-w-0">
              <span className="font-semibold text-slate-900 truncate">
                {activeNavLabel}
              </span>
              {activeSection === 'client_profile' && selectedClient && (
                <>
                  <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                  <span className="text-slate-600 truncate">
                    {selectedClient.businessName || selectedClient.fullName}
                  </span>
                </>
              )}
              {breadcrumb && (
                <>
                  <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                  <span className="text-slate-500 truncate">{breadcrumb}</span>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
            {primaryAction && <div className="shrink-0">{primaryAction}</div>}
            {!user ? (
              <button
                type="button"
                disabled={googleConnecting}
                onClick={() => connectGoogle({ includeGmail: true, forceAccountSelect: true })}
                title="Connect your Google Account to load & sync your clients"
                className="min-h-[44px] lg:min-h-0 px-2.5 py-1.5 inline-flex items-center gap-1.5 text-xs font-medium text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg whitespace-nowrap disabled:opacity-50"
              >
                <CloudOff className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                <span className="hidden md:inline">Connect Google</span>
              </button>
            ) : cloudSyncStatus === 'synced' || cloudSyncStatus === 'syncing' ? (
              <button
                type="button"
                onClick={syncToCloudNow}
                title="All clients and billing data are backed up to Cloud Firestore"
                className="min-h-[44px] lg:min-h-0 px-2.5 py-1.5 inline-flex items-center gap-1.5 text-xs font-medium text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg whitespace-nowrap"
              >
                <Cloud className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                <span className="hidden md:inline">
                  {cloudSyncStatus === 'syncing' ? 'Syncing...' : 'Cloud Synced'}
                </span>
              </button>
            ) : (
              <button
                type="button"
                onClick={syncToCloudNow}
                title="Retry Cloud Firestore sync for your connected Google Account"
                className="min-h-[44px] lg:min-h-0 px-2.5 py-1.5 inline-flex items-center gap-1.5 text-xs font-medium text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg whitespace-nowrap"
              >
                <CloudOff className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                <span className="hidden md:inline">Retry Sync</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => handleSelectNav('gmail_integration')}
              className="hidden sm:inline-flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg whitespace-nowrap"
            >
              <Inbox className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span className="max-w-[160px] truncate">
                {user ? user.email : 'Connect Google Account'}
              </span>
            </button>
            <button
              type="button"
              onClick={lockPlatformNow}
              title="Lock platform now (requires Gmail verification code to unlock)"
              className="min-h-[44px] lg:min-h-0 px-2.5 py-1.5 inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg whitespace-nowrap"
            >
              <Lock className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden xl:inline">Lock</span>
            </button>
          </div>
        </header>

        <main className="flex-1 p-3.5 sm:p-6 lg:p-8 pb-20 lg:pb-8 max-w-[1400px] w-full mx-auto space-y-4 sm:space-y-5">
          {!authLoading && !user && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start sm:items-center gap-3">
                <CloudOff className="w-4 h-4 text-amber-700 shrink-0 mt-0.5 sm:mt-0" />
                <p className="text-xs text-amber-950 leading-relaxed">
                  <strong>Google Account Disconnected — Workspace is empty.</strong> Connect your
                  Google Account to load your client data and billing records.
                </p>
              </div>
              <button
                type="button"
                disabled={googleConnecting}
                onClick={() => connectGoogle({ includeGmail: true, forceAccountSelect: true })}
                className="min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3.5 py-2 sm:py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg whitespace-nowrap shrink-0 disabled:opacity-50"
              >
                <Link2 className="w-3.5 h-3.5" />
                <span>{googleConnecting ? 'Connecting...' : 'Connect Google Account'}</span>
              </button>
            </div>
          )}
          {!authLoading && user && cloudSyncStatus === 'local_only' && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start sm:items-center gap-3">
                <CloudOff className="w-4 h-4 text-amber-700 shrink-0 mt-0.5 sm:mt-0" />
                <p className="text-xs text-amber-950 leading-relaxed">
                  <strong>Cloud Firestore offline</strong> — using cached data for{' '}
                  <span className="font-mono">{user.email}</span> until reconnected.
                </p>
              </div>
              <button
                type="button"
                onClick={syncToCloudNow}
                className="min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3.5 py-2 sm:py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg whitespace-nowrap shrink-0"
              >
                <Cloud className="w-3.5 h-3.5" />
                <span>Retry Cloud Sync</span>
              </button>
            </div>
          )}
          {children}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <nav
        aria-label="Mobile Navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur border-t border-slate-200 pb-safe"
      >
        <div className="grid grid-cols-5 h-[52px]">
          {MOBILE_BOTTOM_TABS.map((tab) => {
            const Icon = tab.icon;
            const active =
              activeSection === tab.id ||
              (tab.id === 'clients' && activeSection === 'client_profile');
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => handleSelectNav(tab.id)}
                className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors ${
                  active ? 'text-slate-900' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Icon className={`w-4 h-4 ${active ? 'text-slate-900' : 'text-slate-400'}`} />
                <span className="truncate max-w-full px-1">{tab.label}</span>
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(true)}
            className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors ${
              isDrawerSectionActive ? 'text-slate-900' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Menu
              className={`w-4 h-4 ${isDrawerSectionActive ? 'text-slate-900' : 'text-slate-400'}`}
            />
            <span>More</span>
          </button>
        </div>
      </nav>

      {/* Toast Notifications */}
      {toasts.length > 0 && (
        <div className="fixed bottom-16 lg:bottom-5 left-3 right-3 sm:left-auto sm:right-5 z-50 flex flex-col gap-2 sm:max-w-sm sm:w-full">
          {toasts.map((t) => (
            <div
              key={t.id}
              className={`flex items-start justify-between gap-3 px-4 py-3 rounded-lg border shadow-md text-sm ${
                t.type === 'error'
                  ? 'bg-red-50 border-red-200 text-red-900'
                  : t.type === 'success'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-white border-slate-200 text-slate-900'
              }`}
            >
              <span className="leading-snug">{t.message}</span>
              <button
                type="button"
                onClick={() => dismissToast(t.id)}
                className="min-h-[32px] min-w-[32px] flex items-center justify-center text-slate-400 hover:text-slate-700 shrink-0 -mr-1"
                aria-label="Dismiss notification"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
