import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { saveEntity } from '../lib/storeClient.ts';
import {
  calculateNextPaymentDate,
  generateId,
  STANDARD_PACKAGES,
  todayIsoDate,
} from '../lib/billingEngine.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import type {
  BillingFrequency,
  PaymentMethod,
  SubscriptionRecord,
  SubscriptionStatus,
} from '../types/freska.ts';

interface SubscriptionModalProps {
  open: boolean;
  editingSubscription?: SubscriptionRecord | null;
  presetClientId?: string | null;
  onClose: () => void;
}

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({
  open,
  editingSubscription,
  presetClientId,
  onClose,
}) => {
  const { clients, services, systemSettings, notify } = useFreska();

  const [clientId, setClientId] = useState('');
  const [serviceId, setServiceId] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [monthlyPrice, setMonthlyPrice] = useState('599');
  const [currency, setCurrency] = useState(systemSettings.defaultCurrency || 'EUR');
  const [startDate, setStartDate] = useState(todayIsoDate());
  const [nextPaymentDate, setNextPaymentDate] = useState(
    calculateNextPaymentDate(todayIsoDate(), 'monthly')
  );
  const [billingFrequency, setBillingFrequency] = useState<BillingFrequency>('monthly');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('bank_transfer');
  const [status, setStatus] = useState<SubscriptionStatus>('active');
  const [reminderEnabled, setReminderEnabled] = useState(true);
  const [autoRenew, setAutoRenew] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (editingSubscription) {
      setClientId(editingSubscription.clientId);
      setServiceId(editingSubscription.serviceId || '');
      setName(editingSubscription.name);
      setDescription(editingSubscription.description || '');
      setMonthlyPrice(String(editingSubscription.monthlyPrice));
      setCurrency(editingSubscription.currency);
      setStartDate(editingSubscription.startDate);
      setNextPaymentDate(editingSubscription.nextPaymentDate);
      setBillingFrequency(editingSubscription.billingFrequency);
      setPaymentMethod(editingSubscription.paymentMethod);
      setStatus(editingSubscription.status);
      setReminderEnabled(editingSubscription.reminderEnabled);
      setAutoRenew(editingSubscription.autoRenew);
    } else {
      const defaultClient =
        presetClientId || clients.find((c) => c.status !== 'archived')?.id || '';
      const matchedClient = clients.find((c) => c.id === defaultClient);
      const today = todayIsoDate();
      const pkg = STANDARD_PACKAGES.subscription;
      setClientId(defaultClient);
      setServiceId(pkg.id);
      setName(pkg.name);
      setDescription(pkg.description);
      setMonthlyPrice(String(pkg.defaultPrice));
      setCurrency(
        matchedClient?.preferredCurrency || systemSettings.defaultCurrency || 'EUR'
      );
      setStartDate(today);
      setNextPaymentDate(calculateNextPaymentDate(today, 'monthly'));
      setBillingFrequency('monthly');
      setPaymentMethod(matchedClient?.preferredPaymentMethod || 'bank_transfer');
      setStatus('active');
      setReminderEnabled(true);
      setAutoRenew(false);
    }
  }, [open, editingSubscription, presetClientId, clients, systemSettings.defaultCurrency]);

  if (!open) return null;

  const handleSelectService = (svcId: string) => {
    setServiceId(svcId);
    const svc = services.find((s) => s.id === svcId);
    if (svc) {
      setName(svc.name);
      setDescription(svc.description || '');
      setMonthlyPrice(String(svc.defaultPrice));
      setCurrency(svc.currency);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numericPrice = Number(monthlyPrice);
    if (!clientId || !name.trim() || Number.isNaN(numericPrice) || numericPrice < 0) {
      notify('error', 'Select a client, subscription name, and valid price.');
      return;
    }

    setSaving(true);
    try {
      if (editingSubscription) {
        await saveEntity('subscriptions', editingSubscription.id, {
          serviceId,
          name: name.trim(),
          description: description.trim(),
          monthlyPrice: numericPrice,
          currency,
          startDate,
          nextPaymentDate,
          billingFrequency,
          paymentMethod,
          status,
          reminderEnabled,
          autoRenew,
        });
        notify('success', `Subscription "${name.trim()}" updated.`);
      } else {
        const id = generateId('sub');
        await saveEntity(
          'subscriptions',
          id,
          {
            id,
            clientId,
            serviceId,
            name: name.trim(),
            description: description.trim(),
            monthlyPrice: numericPrice,
            currency,
            startDate,
            nextPaymentDate,
            billingFrequency,
            paymentMethod,
            status,
            reminderEnabled,
            autoRenew,
          },
          { isNew: true }
        );
        notify('success', `Subscription "${name.trim()}" created.`);
      }
      onClose();
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to save subscription');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/40 backdrop-blur-[1px] p-2 sm:p-4">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl sm:rounded-xl shadow-lg overflow-hidden max-h-[92dvh] flex flex-col">
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200 shrink-0">
          <h2 className="text-base font-semibold text-slate-900 truncate pr-2">
            {editingSubscription ? 'Edit Subscription' : 'Create Recurring Subscription'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-2 -mr-1 rounded min-h-[40px] min-w-[40px] flex items-center justify-center"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto p-4 sm:p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Client *</label>
              <select
                required
                disabled={Boolean(editingSubscription)}
                value={clientId}
                onChange={(e) => setClientId(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white disabled:bg-slate-100"
              >
                <option value="">Select client...</option>
                {clients
                  .filter((c) => c.status !== 'archived' || c.id === clientId)
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.businessName} ({c.fullName})
                    </option>
                  ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                From Service Catalog (Optional)
              </label>
              <select
                value={serviceId}
                onChange={(e) => handleSelectService(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                <option value="">Custom subscription...</option>
                {services
                  .filter((s) => s.active && s.billingType === 'subscription')
                  .map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.defaultPrice} {s.currency})
                    </option>
                  ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Subscription Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Monthly Operations Retainer"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Price *</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  value={monthlyPrice}
                  onChange={(e) => setMonthlyPrice(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Currency</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full px-2 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="EUR">EUR</option>
                  <option value="USD">USD</option>
                  <option value="GBP">GBP</option>
                  <option value="CAD">CAD</option>
                  <option value="MAD">MAD</option>
                </select>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Service Description
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Included deliverables, maintenance scope, or monthly support hours..."
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Start Date</label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Next Payment Date
              </label>
              <input
                type="date"
                required
                value={nextPaymentDate}
                onChange={(e) => setNextPaymentDate(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Frequency</label>
              <select
                value={billingFrequency}
                onChange={(e) => setBillingFrequency(e.target.value as BillingFrequency)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                <option value="monthly">Monthly</option>
                <option value="quarterly">Quarterly</option>
                <option value="yearly">Yearly</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as SubscriptionStatus)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                <option value="active">Active</option>
                <option value="pending">Pending</option>
                <option value="unpaid">Unpaid</option>
                <option value="overdue">Overdue</option>
                <option value="paused">Paused</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center pt-2">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Payment Method
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                <option value="bank_transfer">Bank Transfer (Virement)</option>
                <option value="manual">Manual Payment</option>
                <option value="card">Credit / Debit Card</option>
              </select>
            </div>
            <div className="flex flex-col gap-2 pt-4">
              <label className="inline-flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={reminderEnabled}
                  onChange={(e) => setReminderEnabled(e.target.checked)}
                  className="rounded border-slate-300 text-slate-900"
                />
                <span>Automated Reminders Enabled</span>
              </label>
              <label className="inline-flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoRenew}
                  onChange={(e) => setAutoRenew(e.target.checked)}
                  className="rounded border-slate-300 text-slate-900"
                />
                <span>Automatic Card Renewal (only when gateway active)</span>
              </label>
            </div>
          </div>

          <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2.5 sm:gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto min-h-[44px] sm:min-h-0 px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="w-full sm:w-auto min-h-[44px] sm:min-h-0 px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
            >
              {saving ? 'Saving...' : editingSubscription ? 'Save Subscription' : 'Create Subscription'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
