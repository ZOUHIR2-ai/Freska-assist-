import React, { useEffect, useState } from 'react';
import { X, Download, Mail, Copy, Check } from 'lucide-react';
import { fetchInvoicePdfBlob } from '../lib/api.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import type { InvoiceRecord } from '../types/freska.ts';

interface InvoicePreviewModalProps {
  invoice: InvoiceRecord | null;
  onClose: () => void;
  onSendEmail: (invoice: InvoiceRecord) => void;
}

export const InvoicePreviewModal: React.FC<InvoicePreviewModalProps> = ({
  invoice,
  onClose,
  onSendEmail,
}) => {
  const { systemSettings, payments, notify } = useFreska();
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!invoice) {
      setPdfUrl(null);
      return;
    }

    let objectUrl: string | null = null;
    setLoading(true);
    setError(null);

    const linkedPayment = payments.find((p) => p.id === invoice.paymentId);

    fetchInvoicePdfBlob({
      invoiceNumber: invoice.invoiceNumber,
      invoiceDate: invoice.invoiceDate,
      paymentDate: invoice.paymentDate,
      status: invoice.status,
      clientName: invoice.clientName,
      businessName: invoice.businessName || invoice.clientName,
      clientEmail: invoice.clientEmail,
      serviceName: invoice.serviceName,
      serviceDescription: invoice.serviceDescription || '',
      paymentType: invoice.paymentType,
      paymentMethod: invoice.paymentMethod,
      paymentReference: invoice.paymentReference || '',
      manuallyVerified: linkedPayment?.manuallyVerified ?? false,
      amount: invoice.amount,
      currency: invoice.currency,
      companyName: systemSettings.businessName || 'FreskaAssist',
      companyAddress: systemSettings.companyAddress || '',
      companyEmail: systemSettings.adminEmail || '',
      taxId: systemSettings.taxId || '',
    })
      .then((blob) => {
        objectUrl = URL.createObjectURL(blob);
        setPdfUrl(objectUrl);
      })
      .catch((err) => {
        setError(err instanceof Error ? err.message : 'Failed to load PDF preview');
      })
      .finally(() => setLoading(false));

    return () => {
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [invoice, payments, systemSettings]);

  if (!invoice) return null;

  const signedPublicUrl = invoice.downloadToken
    ? `${window.location.origin}/api/public/invoice/${encodeURIComponent(invoice.id)}?sig=${
        invoice.downloadToken
      }`
    : '';

  const handleDownload = () => {
    if (!pdfUrl) return;
    const a = document.createElement('a');
    a.href = pdfUrl;
    a.download = `FreskaAssist-${invoice.invoiceNumber}.pdf`;
    a.click();
  };

  const handleCopyPublicLink = () => {
    if (!signedPublicUrl) {
      notify('error', 'Signed download URL is unavailable for this invoice.');
      return;
    }
    navigator.clipboard.writeText(signedPublicUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/50 backdrop-blur-[1px] p-2 sm:p-4">
      <div className="w-full max-w-4xl bg-white border border-slate-200 rounded-2xl sm:rounded-xl shadow-lg overflow-hidden h-[92dvh] sm:h-[88vh] flex flex-col">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200 shrink-0">
          <div className="flex items-start justify-between gap-2 min-w-0">
            <div className="min-w-0">
              <h2 className="text-base font-semibold text-slate-900 truncate">
                Invoice Preview · {invoice.invoiceNumber}
              </h2>
              <p className="text-xs text-slate-500 truncate">
                {invoice.businessName || invoice.clientName} · {invoice.serviceName}
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="sm:hidden text-slate-400 hover:text-slate-600 p-2 -mr-1 rounded min-h-[40px] min-w-[40px] flex items-center justify-center shrink-0"
              aria-label="Close preview"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {signedPublicUrl && (
              <button
                type="button"
                onClick={handleCopyPublicLink}
                className="flex-1 sm:flex-none min-h-[40px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 whitespace-nowrap"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy URL'}</span>
              </button>
            )}
            <button
              type="button"
              onClick={handleDownload}
              disabled={!pdfUrl}
              className="flex-1 sm:flex-none min-h-[40px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-50 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF</span>
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onSendEmail(invoice);
              }}
              className="w-full sm:w-auto min-h-[40px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg whitespace-nowrap"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Send via Gmail</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="hidden sm:inline-flex text-slate-400 hover:text-slate-600 p-1.5 rounded"
              aria-label="Close preview"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 bg-slate-100 p-2 sm:p-4 overflow-hidden flex flex-col gap-2">
          {loading && (
            <div className="h-full flex items-center justify-center text-sm text-slate-600">
              Generating PDF invoice...
            </div>
          )}
          {error && (
            <div className="h-full flex items-center justify-center text-sm text-red-700 px-4 text-center">
              {error}
            </div>
          )}
          {!loading && !error && pdfUrl && (
            <>
              <div className="sm:hidden flex items-center justify-between gap-2 bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs">
                <span className="text-slate-600">Mobile PDF viewer:</span>
                <a
                  href={pdfUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-center px-3 py-2 font-medium text-white bg-slate-900 rounded-md whitespace-nowrap"
                >
                  Open Fullscreen PDF
                </a>
              </div>
              <iframe
                src={pdfUrl}
                title={`Invoice ${invoice.invoiceNumber}`}
                className="w-full flex-1 bg-white border border-slate-200 rounded-lg"
              />
            </>
          )}
        </div>
      </div>
    </div>
  );
};
