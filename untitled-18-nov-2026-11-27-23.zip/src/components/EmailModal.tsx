import React, { useEffect, useState } from 'react';
import { X, AlertCircle, Send } from 'lucide-react';
import { saveEntity } from '../lib/storeClient.ts';
import { sendGmailMessage } from '../lib/api.ts';
import { logEmailDispatch } from '../lib/billingEngine.ts';
import { interpolateTemplate, TEMPLATE_VARIABLES } from '../lib/templates.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import { ConfirmDialog } from './ConfirmDialog.tsx';
import type { ClientRecord, InvoiceRecord, PaymentRequestRecord } from '../types/freska.ts';

interface EmailModalProps {
  open: boolean;
  presetClient?: ClientRecord | null;
  presetInvoice?: InvoiceRecord | null;
  presetPaymentRequest?: PaymentRequestRecord | null;
  presetTemplateKey?: string;
  onClose: () => void;
}

export const EmailModal: React.FC<EmailModalProps> = ({
  open,
  presetClient,
  presetInvoice,
  presetPaymentRequest,
  presetTemplateKey,
  onClose,
}) => {
  const {
    clients,
    subscriptions,
    paymentRequests,
    emailTemplates,
    systemSettings,
    emailDeliveryActive,
    reconnectGmail,
    notify,
  } = useFreska();

  const [clientId, setClientId] = useState('');
  const [recipientEmail, setRecipientEmail] = useState('');
  const [templateKey, setTemplateKey] = useState('custom');
  const [senderName, setSenderName] = useState('FreskaAssist');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [attachInvoiceId, setAttachInvoiceId] = useState('');
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [sending, setSending] = useState(false);

  const { invoices } = useFreska();

  const resolveClientOpenRequest = (
    clientObj: ClientRecord | undefined,
    explicitReq: PaymentRequestRecord | null | undefined
  ): PaymentRequestRecord | null | undefined => {
    if (explicitReq) return explicitReq;
    if (!clientObj) return undefined;
    return paymentRequests
      .filter(
        (r) =>
          r.clientId === clientObj.id &&
          (r.status === 'pending' || r.status === 'overdue') &&
          Boolean(r.paymentUrl)
      )
      .sort((a, b) => b.dueDate.localeCompare(a.dueDate))[0];
  };

  const applyTemplate = (
    key: string,
    clientObj: ClientRecord | undefined,
    inv: InvoiceRecord | null | undefined,
    req: PaymentRequestRecord | null | undefined
  ) => {
    if (key === 'custom') return;
    const tpl = emailTemplates.find((t) => t.templateKey === key);
    if (!tpl) return;

    const resolvedReq = resolveClientOpenRequest(clientObj, req);
    const sub = clientObj
      ? subscriptions.find((s) => s.clientId === clientObj.id && s.status !== 'cancelled')
      : undefined;

    const ctx = {
      client_name: clientObj?.fullName || '',
      business_name: clientObj?.businessName || '',
      service_name: inv?.serviceName || resolvedReq?.serviceName || sub?.name || '',
      amount: (inv?.amount ?? resolvedReq?.amount ?? sub?.monthlyPrice ?? 0).toFixed(2),
      currency:
        inv?.currency ||
        resolvedReq?.currency ||
        sub?.currency ||
        systemSettings.defaultCurrency ||
        'EUR',
      payment_link: resolvedReq?.paymentUrl || '',
      invoice_number: inv?.invoiceNumber || '',
      invoice_link: '',
      due_date: resolvedReq?.dueDate || sub?.nextPaymentDate || '',
      next_payment_date: sub?.nextPaymentDate || '',
    };

    setSenderName(tpl.senderDisplayName || 'FreskaAssist');
    setSubject(interpolateTemplate(tpl.subject, ctx));
    const cleanedBody = interpolateTemplate(tpl.body, ctx)
      .replace(/^(Online copy|Download your receipt and invoice):\s*\n?/gim, '')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
    setBody(cleanedBody);
  };

  useEffect(() => {
    if (!open) return;
    setConfirmOpen(false);

    const targetClient =
      presetClient ||
      (presetInvoice ? clients.find((c) => c.id === presetInvoice.clientId) : undefined) ||
      (presetPaymentRequest
        ? clients.find((c) => c.id === presetPaymentRequest.clientId)
        : undefined) ||
      clients[0];

    setClientId(targetClient?.id || '');
    setRecipientEmail(targetClient?.email || presetInvoice?.clientEmail || '');
    setAttachInvoiceId(presetInvoice?.id || '');

    const initialKey =
      presetTemplateKey ||
      (presetInvoice ? 'invoice_delivery' : presetPaymentRequest ? 'payment_link' : 'payment_link');

    setTemplateKey(initialKey);
    applyTemplate(initialKey, targetClient, presetInvoice, presetPaymentRequest);
  }, [open, presetClient, presetInvoice, presetPaymentRequest, presetTemplateKey]);

  if (!open) return null;

  const selectedClient = clients.find((c) => c.id === clientId);
  const selectedInvoice = invoices.find((i) => i.id === attachInvoiceId) || presetInvoice || null;

  const handleClientChange = (newId: string) => {
    setClientId(newId);
    const c = clients.find((item) => item.id === newId);
    if (c) {
      setRecipientEmail(c.email);
      if (templateKey !== 'custom') {
        applyTemplate(templateKey, c, selectedInvoice, presetPaymentRequest);
      }
    }
  };

  const handleTemplateChange = (newKey: string) => {
    setTemplateKey(newKey);
    if (newKey !== 'custom') {
      applyTemplate(newKey, selectedClient, selectedInvoice, presetPaymentRequest);
    }
  };

  const handleConfirmSend = async () => {
    setSending(true);
    try {
      const invoicePayload = selectedInvoice
        ? {
            invoiceNumber: selectedInvoice.invoiceNumber,
            invoiceDate: selectedInvoice.invoiceDate,
            paymentDate: selectedInvoice.paymentDate,
            status: selectedInvoice.status,
            clientName: selectedInvoice.clientName,
            businessName: selectedInvoice.businessName || selectedInvoice.clientName,
            clientEmail: selectedInvoice.clientEmail,
            serviceName: selectedInvoice.serviceName,
            serviceDescription: selectedInvoice.serviceDescription || '',
            paymentType: selectedInvoice.paymentType,
            paymentMethod: selectedInvoice.paymentMethod,
            paymentReference: selectedInvoice.paymentReference || '',
            manuallyVerified: true,
            amount: selectedInvoice.amount,
            currency: selectedInvoice.currency,
            companyName: systemSettings.businessName || 'FreskaAssist',
            companyAddress: systemSettings.companyAddress || '',
            companyEmail: systemSettings.adminEmail || '',
            taxId: systemSettings.taxId || '',
          }
        : undefined;

      const res = await sendGmailMessage({
        to: recipientEmail.trim(),
        subject: subject.trim(),
        bodyText: body,
        senderDisplayName: senderName.trim(),
        invoicePayload,
      });

      await logEmailDispatch({
        clientId: selectedClient?.id,
        recipient: recipientEmail.trim(),
        subject: subject.trim(),
        emailType: templateKey,
        status: 'sent',
        gmailMessageId: res.messageId,
      });

      if (selectedInvoice) {
        await saveEntity('invoices', selectedInvoice.id, {
          sentViaGmail: true,
          sentAt: new Date().toISOString(),
        });
      }

      notify('success', `Email sent via Gmail to ${recipientEmail.trim()}.`);
      setConfirmOpen(false);
      onClose();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Gmail dispatch failed';
      await logEmailDispatch({
        clientId: selectedClient?.id,
        recipient: recipientEmail.trim(),
        subject: subject.trim(),
        emailType: templateKey,
        status: 'failed',
        errorMessage: msg,
      });
      notify('error', msg);
      setConfirmOpen(false);
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/40 backdrop-blur-[1px] p-2 sm:p-4">
        <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl sm:rounded-xl shadow-lg overflow-hidden max-h-[92dvh] flex flex-col">
          <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200 shrink-0">
            <h2 className="text-base font-semibold text-slate-900">Send Email via Gmail</h2>
            <button
              type="button"
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 p-2 -mr-1 rounded min-h-[40px] min-w-[40px] flex items-center justify-center"
              aria-label="Close modal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="overflow-y-auto p-4 sm:p-6 space-y-4">
            {!emailDeliveryActive && (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-700" />
                  <span>
                    No active email sender. Authorize Gmail or enable Verified SMTP Relay in Email
                    Delivery settings.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={reconnectGmail}
                  className="w-full sm:w-auto min-h-[40px] sm:min-h-0 px-3 py-1.5 bg-slate-900 text-white rounded-md font-medium whitespace-nowrap shrink-0"
                >
                  Authorize Gmail
                </button>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Client</label>
                <select
                  value={clientId}
                  onChange={(e) => handleClientChange(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="">Manual recipient...</option>
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.businessName} ({c.email})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Recipient Email *
                </label>
                <input
                  type="email"
                  required
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Email Template
                </label>
                <select
                  value={templateKey}
                  onChange={(e) => handleTemplateChange(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="custom">Custom Message</option>
                  {emailTemplates.map((t) => (
                    <option key={t.id} value={t.templateKey}>
                      {t.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Attach PDF Invoice (Optional)
                </label>
                <select
                  value={attachInvoiceId}
                  onChange={(e) => setAttachInvoiceId(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="">No PDF attachment</option>
                  {invoices
                    .filter((i) => !clientId || i.clientId === clientId)
                    .map((i) => (
                      <option key={i.id} value={i.id}>
                        {i.invoiceNumber} · {i.serviceName} ({i.amount} {i.currency})
                      </option>
                    ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Sender Name
                </label>
                <input
                  type="text"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-700 mb-1">Subject *</label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Message Body *</label>
              <textarea
                rows={8}
                required
                value={body}
                onChange={(e) => setBody(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg"
              />
              <p className="text-[11px] text-slate-500 mt-1.5">
                Variables supported: {TEMPLATE_VARIABLES.join(' · ')}
              </p>
            </div>
          </div>

          <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2.5 sm:gap-3 px-4 sm:px-6 py-4 border-t border-slate-200 bg-slate-50 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto min-h-[44px] sm:min-h-0 px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={!emailDeliveryActive || !recipientEmail.trim() || !subject.trim() || !body.trim()}
              onClick={() => setConfirmOpen(true)}
              className="w-full sm:w-auto min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Review & Send</span>
            </button>
          </div>
        </div>
      </div>

      <ConfirmDialog
        open={confirmOpen}
        variant="gmail"
        title="Confirm Gmail Dispatch"
        description="This will send an email from your connected Gmail account on your behalf."
        details={[
          `To: ${recipientEmail}`,
          `Subject: ${subject}`,
          selectedInvoice ? `Attachment: FreskaAssist-${selectedInvoice.invoiceNumber}.pdf` : 'Attachment: None',
        ]}
        confirmLabel="Send Email Now"
        busy={sending}
        onConfirm={handleConfirmSend}
        onCancel={() => setConfirmOpen(false)}
      />
    </>
  );
};
