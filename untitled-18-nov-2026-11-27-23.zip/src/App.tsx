import React, { useState } from 'react';
import { FreskaProvider, useFreska } from './context/FreskaContext.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { SidebarLayout } from './components/SidebarLayout.tsx';
import { SecurityGateScreen } from './components/SecurityGateScreen.tsx';
import { ClientModal } from './components/ClientModal.tsx';
import { SubscriptionModal } from './components/SubscriptionModal.tsx';
import {
  PaymentLinkModal,
  ManualPaymentModal,
  VerifyTransferModal,
} from './components/BillingModals.tsx';
import { EmailModal } from './components/EmailModal.tsx';
import { InvoicePreviewModal } from './components/InvoicePreviewModal.tsx';
import { OverviewPage } from './pages/OverviewPage.tsx';
import { ClientsPage } from './pages/ClientsPage.tsx';
import { ClientProfilePage } from './pages/ClientProfilePage.tsx';
import { SubscriptionsPage } from './pages/SubscriptionsPage.tsx';
import { PaymentsPage } from './pages/PaymentsPage.tsx';
import { InvoicesPage } from './pages/InvoicesPage.tsx';
import { EmailCenterPage } from './pages/EmailCenterPage.tsx';
import { RemindersPage } from './pages/RemindersPage.tsx';
import { PaymentSettingsPage } from './pages/PaymentSettingsPage.tsx';
import { GmailIntegrationPage } from './pages/GmailIntegrationPage.tsx';
import { SettingsPage } from './pages/SettingsPage.tsx';
import { PublicBankRequestPage } from './pages/PublicBankRequestPage.tsx';
import type {
  ClientRecord,
  InvoiceRecord,
  PaymentRequestRecord,
  SubscriptionRecord,
} from './types/freska.ts';

const AdminShell: React.FC = () => {
  const {
    activeSection,
    setActiveSection,
    selectedClientId,
    clients,
    securityState,
  } = useFreska();

  // Modal state
  const [clientModalOpen, setClientModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<ClientRecord | null>(null);

  const [subModalOpen, setSubModalOpen] = useState(false);
  const [editingSub, setEditingSub] = useState<SubscriptionRecord | null>(null);
  const [presetSubClientId, setPresetSubClientId] = useState<string | null>(null);

  const [paymentLinkOpen, setPaymentLinkOpen] = useState(false);
  const [linkClientId, setLinkClientId] = useState<string | null>(null);
  const [linkSubId, setLinkSubId] = useState<string | null>(null);

  const [manualPaymentOpen, setManualPaymentOpen] = useState(false);
  const [manualClientId, setManualClientId] = useState<string | null>(null);
  const [manualSubId, setManualSubId] = useState<string | null>(null);

  const [verifyTransferReq, setVerifyTransferReq] = useState<PaymentRequestRecord | null>(null);

  const [emailModalOpen, setEmailModalOpen] = useState(false);
  const [emailClient, setEmailClient] = useState<ClientRecord | null>(null);
  const [emailInvoice, setEmailInvoice] = useState<InvoiceRecord | null>(null);
  const [emailReq, setEmailReq] = useState<PaymentRequestRecord | null>(null);
  const [emailTplKey, setEmailTplKey] = useState<string | undefined>(undefined);

  const [previewInvoice, setPreviewInvoice] = useState<InvoiceRecord | null>(null);

  const openPaymentLinkModal = (clientId?: string, subId?: string) => {
    setLinkClientId(clientId || null);
    setLinkSubId(subId || null);
    setPaymentLinkOpen(true);
  };

  const openManualPaymentModal = (clientId?: string, subId?: string) => {
    setManualClientId(clientId || null);
    setManualSubId(subId || null);
    setManualPaymentOpen(true);
  };

  const openEmailModal = (opts?: {
    client?: ClientRecord | null;
    invoice?: InvoiceRecord | null;
    paymentRequest?: PaymentRequestRecord | null;
    templateKey?: string;
  }) => {
    setEmailClient(opts?.client || null);
    setEmailInvoice(opts?.invoice || null);
    setEmailReq(opts?.paymentRequest || null);
    setEmailTplKey(opts?.templateKey);
    setEmailModalOpen(true);
  };

  if (securityState === 'checking') {
    return (
      <div className="min-h-[100dvh] bg-slate-50 flex flex-col items-center justify-center px-4 text-center">
        <div className="bg-black rounded-xl px-4 py-2.5 shadow-sm border border-slate-900 mb-4">
          <img
            src="/assets/aistudio/IMG-20261117-WA0014_9dd05831.jpg"
            alt="FreskaAssist"
            className="h-7 w-auto object-contain"
          />
        </div>
        <div className="w-6 h-6 border-2 border-slate-300 border-t-slate-900 rounded-full animate-spin mb-3" />
        <p className="text-xs font-medium text-slate-600">Checking 24-hour security status...</p>
      </div>
    );
  }

  if (securityState !== 'unlocked') {
    return <SecurityGateScreen />;
  }

  return (
    <SidebarLayout>
      {activeSection === 'overview' && (
        <OverviewPage
          onNavigate={setActiveSection}
          onOpenPaymentLink={() => openPaymentLinkModal()}
          onOpenManualPayment={() => openManualPaymentModal()}
        />
      )}

      {activeSection === 'clients' && (
        <ClientsPage
          onAddClient={() => {
            setEditingClient(null);
            setClientModalOpen(true);
          }}
          onEditClient={(client) => {
            setEditingClient(client);
            setClientModalOpen(true);
          }}
          onCreatePaymentLink={(cId, sId) => openPaymentLinkModal(cId, sId)}
        />
      )}

      {activeSection === 'client_profile' && selectedClientId && (
        <ClientProfilePage
          clientId={selectedClientId}
          onBack={() => setActiveSection('clients')}
          onEditClient={(client) => {
            setEditingClient(client);
            setClientModalOpen(true);
          }}
          onCreatePaymentLink={(cId, sId) => openPaymentLinkModal(cId, sId)}
          onRegisterManualPayment={(cId, sId) => openManualPaymentModal(cId, sId)}
          onSendEmail={(client, inv) =>
            openEmailModal({
              client,
              invoice: inv || null,
              templateKey: inv ? 'invoice_delivery' : 'payment_link',
            })
          }
          onPreviewInvoice={(inv) => setPreviewInvoice(inv)}
          onManageReminders={() => setActiveSection('reminders')}
        />
      )}

      {activeSection === 'subscriptions' && (
        <SubscriptionsPage
          onAddSubscription={() => {
            setEditingSub(null);
            setPresetSubClientId(null);
            setSubModalOpen(true);
          }}
          onEditSubscription={(sub) => {
            setEditingSub(sub);
            setPresetSubClientId(null);
            setSubModalOpen(true);
          }}
          onGeneratePaymentLink={(cId, sId) => openPaymentLinkModal(cId, sId)}
        />
      )}

      {activeSection === 'payments' && (
        <PaymentsPage
          onOpenPaymentLink={() => openPaymentLinkModal()}
          onOpenManualPayment={() => openManualPaymentModal()}
          onVerifyTransfer={(req) => setVerifyTransferReq(req)}
          onSendPaymentLinkEmail={(req) => {
            const c = clients.find((item) => item.id === req.clientId) || null;
            openEmailModal({
              client: c,
              paymentRequest: req,
              templateKey: 'payment_link',
            });
          }}
        />
      )}

      {activeSection === 'invoices' && (
        <InvoicesPage
          onPreviewInvoice={(inv) => setPreviewInvoice(inv)}
          onSendInvoiceEmail={(client, inv) =>
            openEmailModal({
              client,
              invoice: inv,
              templateKey: 'invoice_delivery',
            })
          }
        />
      )}

      {activeSection === 'email_center' && (
        <EmailCenterPage onComposeEmail={() => openEmailModal({ templateKey: 'custom' })} />
      )}

      {activeSection === 'reminders' && <RemindersPage />}

      {activeSection === 'payment_settings' && <PaymentSettingsPage />}

      {activeSection === 'gmail_integration' && <GmailIntegrationPage />}

      {activeSection === 'settings' && <SettingsPage />}

      {/* Modals */}
      <ClientModal
        open={clientModalOpen}
        editingClient={editingClient}
        onClose={() => setClientModalOpen(false)}
      />

      <SubscriptionModal
        open={subModalOpen}
        editingSubscription={editingSub}
        presetClientId={presetSubClientId}
        onClose={() => setSubModalOpen(false)}
      />

      <PaymentLinkModal
        open={paymentLinkOpen}
        presetClientId={linkClientId}
        presetSubscriptionId={linkSubId}
        onClose={() => setPaymentLinkOpen(false)}
        onSendEmailRequest={(req) => {
          const c = clients.find((item) => item.id === req.clientId) || null;
          openEmailModal({
            client: c,
            paymentRequest: req,
            templateKey: 'payment_link',
          });
        }}
      />

      <ManualPaymentModal
        open={manualPaymentOpen}
        presetClientId={manualClientId}
        presetSubscriptionId={manualSubId}
        onClose={() => setManualPaymentOpen(false)}
      />

      <VerifyTransferModal
        request={verifyTransferReq}
        onClose={() => setVerifyTransferReq(null)}
      />

      <EmailModal
        open={emailModalOpen}
        presetClient={emailClient}
        presetInvoice={emailInvoice}
        presetPaymentRequest={emailReq}
        presetTemplateKey={emailTplKey}
        onClose={() => setEmailModalOpen(false)}
      />

      <InvoicePreviewModal
        invoice={previewInvoice}
        onClose={() => setPreviewInvoice(null)}
        onSendEmail={(inv) => {
          const c = clients.find((item) => item.id === inv.clientId) || null;
          openEmailModal({
            client: c,
            invoice: inv,
            templateKey: 'invoice_delivery',
          });
        }}
      />
    </SidebarLayout>
  );
};

export default function App() {
  const params = new URLSearchParams(window.location.search);
  const bankRequestId = params.get('bank_request');
  const bankSig = params.get('sig');

  if (bankRequestId && bankSig) {
    return <PublicBankRequestPage requestId={bankRequestId} signature={bankSig} />;
  }

  return (
    <ErrorBoundary>
      <FreskaProvider>
        <AdminShell />
      </FreskaProvider>
    </ErrorBoundary>
  );
}
