import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import {
  getFirestore,
  initializeFirestore,
  enableNetwork,
  doc,
  getDocFromServer,
  type Firestore,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db: Firestore = (() => {
  try {
    return initializeFirestore(
      app,
      {
        experimentalForceLongPolling: true,
        ignoreUndefinedProperties: true,
      },
      firebaseConfig.firestoreDatabaseId
    );
  } catch {
    return getFirestore(app, firebaseConfig.firestoreDatabaseId);
  }
})();
export const auth = getAuth(app);

export const PRIMARY_FIRESTORE_ADMIN_EMAIL = 'zwizoo175@gmail.com';

export const BASIC_GOOGLE_SCOPES = [
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
];

export const GMAIL_SCOPES = [
  'https://www.googleapis.com/auth/gmail.send',
  ...BASIC_GOOGLE_SCOPES,
];

let cachedGmailAccessToken: string | null = null;
let cachedHasGmailScope = false;
let cachedTokenTimestamp = 0;

export function getCachedGmailAccessToken(): string | null {
  if (!cachedGmailAccessToken || !cachedHasGmailScope) return null;
  if (Date.now() - cachedTokenTimestamp > 55 * 60 * 1000) {
    cachedGmailAccessToken = null;
    cachedHasGmailScope = false;
    return null;
  }
  return cachedGmailAccessToken;
}

export function clearCachedGmailAccessToken(): void {
  cachedGmailAccessToken = null;
  cachedHasGmailScope = false;
  cachedTokenTimestamp = 0;
}

export function hasVerifiedGoogleAccount(user: User | null): boolean {
  return Boolean(user && user.uid && user.emailVerified);
}

export function isFirestorePrimaryAdmin(user: User | null): boolean {
  return Boolean(
    user &&
      user.email &&
      user.email.toLowerCase() === PRIMARY_FIRESTORE_ADMIN_EMAIL &&
      user.emailVerified
  );
}

export function isEmbeddedIframe(): boolean {
  try {
    return typeof window !== 'undefined' && window.self !== window.top;
  } catch {
    return true;
  }
}

export function formatGoogleAuthError(err: unknown): string {
  const code =
    typeof err === 'object' && err !== null && 'code' in err
      ? String((err as { code?: unknown }).code)
      : '';
  const rawMessage = err instanceof Error ? err.message : String(err || 'Google connection failed');

  if (code === 'auth/popup-blocked') {
    return isEmbeddedIframe()
      ? 'Google sign-in popup was blocked inside the preview frame. Tap "Open App in New Tab" below to sign in directly in your browser.'
      : 'Google sign-in popup was blocked by your browser. Allow popups or tap "Use Full-Page Google Redirect" below.';
  }
  if (code === 'auth/popup-closed-by-user') {
    return isEmbeddedIframe()
      ? 'The mobile/preview browser closed the Google sign-in popup before finishing. Tap "Open App in New Tab" below to complete Google Sign-In reliably.'
      : 'Google sign-in popup was closed before completing. Tap "Use Full-Page Google Redirect" below or try again.';
  }
  if (code === 'auth/cancelled-popup-request') {
    return 'Previous Google sign-in request was replaced. Please wait a moment and try again.';
  }
  if (code === 'auth/unauthorized-domain') {
    return `This domain (${window.location.hostname}) is not authorized in Firebase Auth settings.`;
  }
  if (code === 'auth/operation-not-allowed') {
    return 'Google sign-in provider is not enabled in Firebase Authentication.';
  }
  if (code === 'auth/network-request-failed') {
    return 'Network error while contacting Google authentication servers. Check your connection and retry.';
  }
  if (rawMessage.toLowerCase().includes('access_denied')) {
    return 'Google denied Gmail permission (often because the OAuth app is in Testing mode and the selected account is not listed as a Test User). Try "Sign in with Google Profile" or add your Gmail address as a Test User in Google Cloud.';
  }
  return rawMessage;
}

function createGoogleProvider(options: {
  includeGmail: boolean;
  forceAccountSelect: boolean;
  forceConsent?: boolean;
}): GoogleAuthProvider {
  const provider = new GoogleAuthProvider();
  const scopes = options.includeGmail ? GMAIL_SCOPES : BASIC_GOOGLE_SCOPES;
  for (const scope of scopes) {
    provider.addScope(scope);
  }
  const params: Record<string, string> = {
    access_type: 'online',
  };
  if (options.forceConsent) {
    params.prompt = options.forceAccountSelect ? 'select_account consent' : 'consent';
  } else if (options.forceAccountSelect) {
    params.prompt = 'select_account';
  }
  provider.setCustomParameters(params);
  return provider;
}

export async function connectGoogleAccount(options?: {
  includeGmail?: boolean;
  forceAccountSelect?: boolean;
  forceConsent?: boolean;
}): Promise<{
  user: User;
  gmailAccessToken: string | null;
  hasGmailScope: boolean;
}> {
  const includeGmail = options?.includeGmail ?? true;
  const forceAccountSelect = options?.forceAccountSelect ?? true;
  const forceConsent = options?.forceConsent ?? false;
  const provider = createGoogleProvider({ includeGmail, forceAccountSelect, forceConsent });

  const result = await signInWithPopup(auth, provider);
  const credential = GoogleAuthProvider.credentialFromResult(result);
  const token = credential?.accessToken ?? null;

  if (token && includeGmail) {
    cachedGmailAccessToken = token;
    cachedHasGmailScope = true;
    cachedTokenTimestamp = Date.now();
  } else {
    cachedGmailAccessToken = null;
    cachedHasGmailScope = false;
    cachedTokenTimestamp = 0;
  }

  return {
    user: result.user,
    gmailAccessToken: includeGmail ? token : null,
    hasGmailScope: Boolean(token && includeGmail),
  };
}

export async function startGoogleRedirectSignIn(options?: {
  includeGmail?: boolean;
  forceAccountSelect?: boolean;
}): Promise<void> {
  const includeGmail = options?.includeGmail ?? true;
  const forceAccountSelect = options?.forceAccountSelect ?? true;
  const provider = createGoogleProvider({ includeGmail, forceAccountSelect });
  if (typeof window !== 'undefined') {
    window.sessionStorage.setItem('freska_pending_redirect_gmail', includeGmail ? '1' : '0');
  }
  await signInWithRedirect(auth, provider);
}

export async function resolveGoogleRedirectResult(): Promise<{
  user: User | null;
  hasGmailScope: boolean;
} | null> {
  if (isEmbeddedIframe()) return null;
  try {
    const result = await getRedirectResult(auth);
    if (!result) return null;
    const includeGmail =
      typeof window !== 'undefined' &&
      window.sessionStorage.getItem('freska_pending_redirect_gmail') !== '0';
    if (typeof window !== 'undefined') {
      window.sessionStorage.removeItem('freska_pending_redirect_gmail');
    }
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const token = credential?.accessToken ?? null;
    if (token && includeGmail) {
      cachedGmailAccessToken = token;
      cachedHasGmailScope = true;
      cachedTokenTimestamp = Date.now();
    }
    return {
      user: result.user,
      hasGmailScope: Boolean(token && includeGmail),
    };
  } catch (err) {
    if (typeof window !== 'undefined') {
      window.sessionStorage.removeItem('freska_pending_redirect_gmail');
    }
    throw err;
  }
}

export async function signInWithGoogleWorkspace(): Promise<{
  user: User;
  gmailAccessToken: string | null;
}> {
  const res = await connectGoogleAccount({ includeGmail: true, forceAccountSelect: true });
  return { user: res.user, gmailAccessToken: res.gmailAccessToken };
}

export async function refreshGmailTokenPopup(): Promise<string | null> {
  const res = await connectGoogleAccount({
    includeGmail: true,
    forceAccountSelect: false,
    forceConsent: true,
  });
  return res.gmailAccessToken;
}

export async function switchGoogleAccount(includeGmail = true): Promise<{
  user: User;
  gmailAccessToken: string | null;
  hasGmailScope: boolean;
}> {
  clearCachedGmailAccessToken();
  return connectGoogleAccount({ includeGmail, forceAccountSelect: true });
}

export async function signOutAdmin(): Promise<void> {
  clearCachedGmailAccessToken();
  await signOut(auth);
}

export function subscribeToAuth(callback: (user: User | null) => void) {
  return onAuthStateChanged(auth, (user) => {
    if (!user) {
      clearCachedGmailAccessToken();
    }
    callback(user);
  });
}

export async function testFirestoreConnection(uid?: string): Promise<boolean> {
  if (!uid) return false;
  const retryDelays = [0, 800, 1800];
  for (let i = 0; i < retryDelays.length; i++) {
    if (retryDelays[i] > 0) {
      await new Promise((resolve) => setTimeout(resolve, retryDelays[i]));
    }
    try {
      await enableNetwork(db).catch(() => {});
      await getDocFromServer(doc(db, 'users', uid));
      return true;
    } catch (error) {
      const code =
        typeof error === 'object' && error !== null && 'code' in error
          ? String((error as { code?: unknown }).code)
          : '';
      const msg = error instanceof Error ? error.message : String(error || '');
      const isTransientOffline =
        code === 'unavailable' ||
        msg.includes('the client is offline') ||
        msg.includes('Failed to get document from server');

      if (!isTransientOffline) {
        return true;
      }
      if (i === retryDelays.length - 1) {
        console.warn('Firestore temporarily unreachable; continuing with account cache until online.');
        return false;
      }
    }
  }
  return false;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}
