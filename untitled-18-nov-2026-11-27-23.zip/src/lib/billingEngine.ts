import {
  fetchLocalStore,
  isEmailDeliveryAvailable,
  registerPublicInvoiceSnapshot,
  sendGmailMessage,
  registerBankInstructionSnapshot,
  markBankInstructionPaid,
} from './api.ts';
import { saveEntity } from './storeClient.ts';
import { interpolateTemplate } from './templates.ts';
import type {
  BillingFrequency,
  BillingType,
  ClientRecord,
  EmailLogRecord,
  EmailTemplateRecord,
  InvoiceRecord,
  PaymentGatewaySettingRecord,
  PaymentMethod,
  PaymentRecord,
  PaymentRequestRecord,
  ReminderLogRecord,
  ReminderSettingRecord,
  ReminderStage,
  SubscriptionRecord,
  SystemSettingRecord,
} from '../types/freska.ts';

export function todayIsoDate(): string {
  return new Date().toISOString().slice(0, 10);
}

export function generateId(prefix: string): string {
  const rand = Math.random().toString(36).slice(2, 8);
  return `${prefix}_${Date.now()}_${rand}`;
}

export function addDays(dateStr: string, days: number): string {
  const d = new Date(`${dateStr}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export function diffDays(fromDateStr: string, toDateStr: string): number {
  const a = new Date(`${fromDateStr}T00:00:00Z`).getTime();
  const b = new Date(`${toDateStr}T00:00:00Z`).getTime();
  return Math.round((b - a) / (1000 * 60 * 60 * 24));
}

export function calculateNextPaymentDate(
  baseDateStr: string,
  frequency: BillingFrequency
): string {
  const d = new Date(`${baseDateStr}T00:00:00Z`);
  if (frequency === 'monthly') {
    d.setUTCMonth(d.getUTCMonth() + 1);
  } else if (frequency === 'quarterly') {
    d.setUTCMonth(d.getUTCMonth() + 3);
  } else if (frequency === 'yearly') {
    d.setUTCFullYear(d.getUTCFullYear() + 1);
  }
  return d.toISOString().slice(0, 10);
}

export function formatMoney(amount: number, currency = 'EUR'): string {
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency || 'EUR',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  } catch {
    return `${currency} ${amount.toFixed(2)}`;
  }
}

export function formatPaymentMethodLabel(method: PaymentMethod): string {
  if (method === 'bank_transfer') return 'Bank Transfer (Virement)';
  if (method === 'manual') return 'Manual Payment';
  return 'Credit / Debit Card';
}

export function buildNextInvoiceNumber(
  existingInvoices: InvoiceRecord[],
  prefix = 'FA'
): string {
  const year = new Date().getFullYear();
  const seq = existingInvoices.length + 1;
  return `${prefix}-${year}-${String(seq).padStart(4, '0')}`;
}

export const STANDARD_PACKAGES = {
  subscription: {
    id: 'svc_sub_599',
    name: 'Subscription Plan',
    description: 'Recurring monthly subscription package (599€ / month)',
    billingType: 'subscription' as BillingType,
    defaultPrice: 599,
    currency: 'EUR',
    active: true,
  },
  one_time: {
    id: 'svc_onetime_1199',
    name: 'One-Time Payment Plan',
    description: 'Single one-time payment package (1199€)',
    billingType: 'one_time' as BillingType,
    defaultPrice: 1199,
    currency: 'EUR',
    active: true,
  },
} as const;

export const DEFAULT_SERVICE_PACKAGES = [
  STANDARD_PACKAGES.subscription,
  STANDARD_PACKAGES.one_time,
];

export function computeClientFinancials(
  clientId: string,
  subscriptions: SubscriptionRecord[],
  payments: PaymentRecord[],
  paymentRequests: PaymentRequestRecord[]
) {
  const clientSubs = subscriptions.filter((s) => s.clientId === clientId);
  const activeSub =
    clientSubs.find((s) => s.status === 'active') ||
    clientSubs.find((s) => s.status !== 'cancelled') ||
    null;

  const clientPayments = payments
    .filter((p) => p.clientId === clientId)
    .sort((a, b) => b.paymentDate.localeCompare(a.paymentDate));

  const paidPayments = clientPayments.filter((p) => p.status === 'paid');
  const totalPaid = paidPayments.reduce((sum, p) => sum + Number(p.amount || 0), 0);

  const clientOneTimeRequests = paymentRequests
    .filter((r) => r.clientId === clientId && r.billingType === 'one_time')
    .sort((a, b) => (b.dueDate || '').localeCompare(a.dueDate || ''));
  const openOneTimeRequest =
    clientOneTimeRequests.find((r) => r.status === 'pending' || r.status === 'overdue') || null;
  const latestOneTimePayment =
    paidPayments.find((p) => p.billingType === 'one_time') || null;
  const latestOneTimeRequest = clientOneTimeRequests[0] || null;

  const openRequests = paymentRequests.filter(
    (r) => r.clientId === clientId && (r.status === 'pending' || r.status === 'overdue')
  );
  const outstandingFromRequests = openRequests.reduce(
    (sum, r) => sum + Number(r.amount || 0),
    0
  );
  const overdueSubs = clientSubs.filter(
    (s) => s.status === 'overdue' || s.status === 'unpaid'
  );
  const outstandingFromSubs =
    openRequests.length === 0
      ? overdueSubs.reduce((sum, s) => sum + Number(s.monthlyPrice || 0), 0)
      : 0;

  const outstandingBalance = outstandingFromRequests + outstandingFromSubs;
  const lastPaymentDate = paidPayments[0]?.paymentDate || activeSub?.lastPaymentDate || null;
  const nextPaymentDate =
    activeSub && activeSub.status !== 'cancelled' && activeSub.status !== 'paused'
      ? activeSub.nextPaymentDate
      : openOneTimeRequest?.dueDate || null;

  const billingMode: 'subscription' | 'one_time' | null = activeSub
    ? 'subscription'
    : openOneTimeRequest || latestOneTimePayment || latestOneTimeRequest
    ? 'one_time'
    : null;

  const oneTimeAmount =
    openOneTimeRequest?.amount ??
    latestOneTimePayment?.amount ??
    latestOneTimeRequest?.amount ??
    0;

  const currency =
    activeSub?.currency ||
    openOneTimeRequest?.currency ||
    latestOneTimePayment?.currency ||
    paidPayments[0]?.currency ||
    'EUR';

  return {
    activeSub,
    billingMode,
    openOneTimeRequest,
    latestOneTimePayment,
    latestOneTimeRequest,
    oneTimeAmount,
    totalPaid,
    outstandingBalance,
    lastPaymentDate,
    nextPaymentDate,
    monthlyRate: activeSub ? activeSub.monthlyPrice : 0,
    currency,
    paymentMethod:
      activeSub?.paymentMethod ||
      openOneTimeRequest?.paymentMethod ||
      paidPayments[0]?.paymentMethod ||
      'bank_transfer',
  };
}

const PACKAGE_LABELS = [
  'Subscription Plan (599 EUR/mo)',
  'One-Time Payment Plan (1,199 EUR)',
  'Subscription Plan (599€)',
  'One-Time Payment Plan (1199€)',
];

export async function assignClientBillingPlan(params: {
  client: ClientRecord;
  planType: 'subscription' | 'one_time';
  customAmount?: number;
  currency?: string;
  paymentMethod?: PaymentMethod;
  existingSubscriptions: SubscriptionRecord[];
  existingPaymentRequests: PaymentRequestRecord[];
  gatewaySettings: PaymentGatewaySettingRecord;
  systemSettings: SystemSettingRecord;
  cardPaymentsActive?: boolean;
}): Promise<{
  mode: 'subscription' | 'one_time';
  amount: number;
  currency: string;
  paymentUrl: string;
  requestId: string;
}> {
  const pkg = STANDARD_PACKAGES[params.planType];
  const amount =
    params.customAmount !== undefined && !Number.isNaN(params.customAmount) && params.customAmount > 0
      ? Number(params.customAmount)
      : pkg.defaultPrice;
  const currency = params.currency || pkg.currency;
  const rawMethod = params.paymentMethod || params.client.preferredPaymentMethod || 'bank_transfer';
  const method: PaymentMethod =
    rawMethod === 'card' && !params.cardPaymentsActive ? 'bank_transfer' : rawMethod;

  const today = todayIsoDate();
  const planTag =
    params.planType === 'subscription'
      ? `Subscription Plan (${amount} ${currency}/mo)`
      : `One-Time Payment Plan (${amount} ${currency})`;

  const cleanedServices = (params.client.servicesPurchased || []).filter(
    (s) =>
      !PACKAGE_LABELS.includes(s) &&
      !s.startsWith('Subscription Plan (') &&
      !s.startsWith('One-Time Payment Plan (')
  );
  const nextServices = [planTag, ...cleanedServices].slice(0, 50);

  await saveEntity(
    'clients',
    params.client.id,
    {
      preferredCurrency: currency,
      preferredPaymentMethod: method,
      servicesPurchased: nextServices,
    },
    { silent: true }
  );

  if (params.planType === 'subscription') {
    const openOneTimeReqs = params.existingPaymentRequests.filter(
      (r) =>
        r.clientId === params.client.id &&
        r.billingType === 'one_time' &&
        (r.status === 'pending' || r.status === 'overdue')
    );
    for (const req of openOneTimeReqs) {
      await saveEntity('payment_requests', req.id, { status: 'cancelled' }, { silent: true });
    }

    const existingSub =
      params.existingSubscriptions.find(
        (s) => s.clientId === params.client.id && s.status !== 'cancelled'
      ) || null;

    let targetSubId: string;
    if (existingSub) {
      targetSubId = existingSub.id;
      await saveEntity('subscriptions', existingSub.id, {
        serviceId: pkg.id,
        name: pkg.name,
        description: pkg.description,
        monthlyPrice: amount,
        currency,
        paymentMethod: method,
        status: existingSub.status === 'paused' ? 'active' : existingSub.status,
        reminderEnabled: true,
      });
    } else {
      targetSubId = generateId('sub');
      await saveEntity(
        'subscriptions',
        targetSubId,
        {
          id: targetSubId,
          clientId: params.client.id,
          serviceId: pkg.id,
          name: pkg.name,
          description: pkg.description,
          monthlyPrice: amount,
          currency,
          startDate: today,
          nextPaymentDate: calculateNextPaymentDate(today, 'monthly'),
          billingFrequency: 'monthly',
          paymentMethod: method,
          status: 'active',
          reminderEnabled: true,
          autoRenew: false,
        },
        { isNew: true }
      );
    }

    const openSubReq =
      params.existingPaymentRequests.find(
        (r) =>
          r.clientId === params.client.id &&
          r.billingType === 'subscription' &&
          (r.status === 'pending' || r.status === 'overdue')
      ) || null;

    if (openSubReq && openSubReq.paymentUrl) {
      await saveEntity('payment_requests', openSubReq.id, {
        subscriptionId: targetSubId,
        serviceId: pkg.id,
        serviceName: pkg.name,
        description: pkg.description,
        amount,
        currency,
        paymentMethod: method,
      });
      return {
        mode: 'subscription',
        amount,
        currency,
        paymentUrl: openSubReq.paymentUrl,
        requestId: openSubReq.id,
      };
    }

    const requestId = openSubReq?.id || generateId('req');
    const dueDate = openSubReq?.dueDate || addDays(today, 2);
    const reference =
      openSubReq?.reference || `FA-REF-${Math.floor(100000 + Math.random() * 900000)}`;
    let paymentUrl = '';
    try {
      paymentUrl = await createBankTransferPaymentUrl({
        requestId,
        reference,
        client: params.client,
        serviceName: pkg.name,
        description: pkg.description,
        amount,
        currency,
        dueDate,
        billingType: 'subscription',
        subscriptionId: targetSubId,
        gatewaySettings: params.gatewaySettings,
        systemSettings: params.systemSettings,
      });
    } catch {
      paymentUrl = '';
    }

    await saveEntity(
      'payment_requests',
      requestId,
      {
        id: requestId,
        clientId: params.client.id,
        subscriptionId: targetSubId,
        serviceId: pkg.id,
        serviceName: pkg.name,
        description: pkg.description,
        billingType: 'subscription',
        paymentMethod: method,
        reference,
        amount,
        currency,
        dueDate,
        paymentUrl,
        gatewaySessionId: '',
        status: 'pending',
      },
      { isNew: !openSubReq }
    );

    return { mode: 'subscription', amount, currency, paymentUrl, requestId };
  }

  // Switching/assigning One-Time Payment Plan
  const activeSubs = params.existingSubscriptions.filter(
    (s) => s.clientId === params.client.id && s.status !== 'cancelled'
  );
  for (const sub of activeSubs) {
    await saveEntity(
      'subscriptions',
      sub.id,
      {
        status: 'cancelled',
        reminderEnabled: false,
        autoRenew: false,
      },
      { silent: true }
    );
  }

  const openOneTimeReq =
    params.existingPaymentRequests.find(
      (r) =>
        r.clientId === params.client.id &&
        r.billingType === 'one_time' &&
        (r.status === 'pending' || r.status === 'overdue')
    ) || null;

  if (openOneTimeReq && openOneTimeReq.paymentUrl) {
    await saveEntity('payment_requests', openOneTimeReq.id, {
      serviceId: pkg.id,
      serviceName: pkg.name,
      description: pkg.description,
      amount,
      currency,
      paymentMethod: method,
    });
    return {
      mode: 'one_time',
      amount,
      currency,
      paymentUrl: openOneTimeReq.paymentUrl,
      requestId: openOneTimeReq.id,
    };
  }

  const requestId = openOneTimeReq?.id || generateId('req');
  const dueDate = openOneTimeReq?.dueDate || addDays(today, 7);
  const reference =
    openOneTimeReq?.reference || `FA-REF-${Math.floor(100000 + Math.random() * 900000)}`;
  let paymentUrl = '';
  try {
    paymentUrl = await createBankTransferPaymentUrl({
      requestId,
      reference,
      client: params.client,
      serviceName: pkg.name,
      description: pkg.description,
      amount,
      currency,
      dueDate,
      billingType: 'one_time',
      gatewaySettings: params.gatewaySettings,
      systemSettings: params.systemSettings,
    });
  } catch {
    paymentUrl = '';
  }

  await saveEntity(
    'payment_requests',
    requestId,
    {
      id: requestId,
      clientId: params.client.id,
      subscriptionId: '',
      serviceId: pkg.id,
      serviceName: pkg.name,
      description: pkg.description,
      billingType: 'one_time',
      paymentMethod: method,
      reference,
      amount,
      currency,
      dueDate,
      paymentUrl,
      gatewaySessionId: '',
      status: 'pending',
    },
    { isNew: !openOneTimeReq }
  );

  return { mode: 'one_time', amount, currency, paymentUrl, requestId };
}

export async function sendClientWelcomeEmail(params: {
  client: ClientRecord;
  planType: 'subscription' | 'one_time' | 'none';
  amount: number;
  currency: string;
  paymentUrl?: string;
  templates: EmailTemplateRecord[];
}): Promise<{ sent: boolean; error?: string }> {
  if (!isEmailDeliveryAvailable()) {
    return { sent: false, error: 'No active email sender (enable SMTP Relay or authorize Gmail).' };
  }
  if (!params.client.email) {
    return { sent: false, error: 'Client email address is missing.' };
  }

  const tpl = params.templates.find((t) => t.templateKey === 'client_welcome');
  const serviceName =
    params.planType === 'subscription'
      ? STANDARD_PACKAGES.subscription.name
      : params.planType === 'one_time'
      ? STANDARD_PACKAGES.one_time.name
      : params.client.servicesPurchased?.[0] || 'FreskaAssist Services';

  let paymentLinkSection = '\n';
  if (params.planType === 'one_time' && params.paymentUrl) {
    paymentLinkSection = `\nYou can complete your one-time payment (Bank Transfer or Card Checkout) using the link below:\n${params.paymentUrl}\n\n`;
  } else if (params.planType === 'subscription') {
    paymentLinkSection = `\nYour monthly subscription account is set up — your dedicated payment link will be sent to you automatically in 2 days.\n\n`;
  }

  const ctx = {
    client_name: params.client.fullName,
    business_name: params.client.businessName || params.client.fullName,
    service_name: serviceName,
    amount: params.amount > 0 ? params.amount.toFixed(2) : '',
    currency: params.currency || 'EUR',
    payment_link: params.paymentUrl || '',
    payment_link_section: paymentLinkSection,
    due_date: todayIsoDate(),
  };

  const subject = interpolateTemplate(
    tpl?.subject || 'Welcome to FreskaAssist, {{business_name}}!',
    ctx
  );
  const bodyText = interpolateTemplate(
    tpl?.body ||
      `Hello {{client_name}},\n\nWelcome to FreskaAssist! We are glad to have {{business_name}} on board.\n{{payment_link_section}}Best regards,\nFreskaAssist`,
    ctx
  );

  try {
    const sentRes = await sendGmailMessage({
      to: params.client.email,
      subject,
      bodyText,
      senderDisplayName: tpl?.senderDisplayName || 'FreskaAssist',
    });

    await logEmailDispatch({
      clientId: params.client.id,
      recipient: params.client.email,
      subject,
      emailType: 'client_welcome',
      status: 'sent',
      gmailMessageId: sentRes.messageId,
    });

    return { sent: true };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Failed to send welcome email';
    await logEmailDispatch({
      clientId: params.client.id,
      recipient: params.client.email,
      subject,
      emailType: 'client_welcome',
      status: 'failed',
      errorMessage: msg,
    });
    return { sent: false, error: msg };
  }
}

export async function logEmailDispatch(params: {
  clientId?: string;
  recipient: string;
  subject: string;
  emailType: string;
  status: 'sent' | 'failed';
  gmailMessageId?: string;
  errorMessage?: string;
}) {
  const id = generateId('email');
  const payload: Record<string, unknown> = {
    id,
    recipient: params.recipient,
    subject: params.subject,
    emailType: params.emailType,
    status: params.status,
  };
  if (params.clientId) payload.clientId = params.clientId;
  if (params.gmailMessageId) payload.gmailMessageId = params.gmailMessageId;
  if (params.errorMessage) payload.errorMessage = params.errorMessage.slice(0, 950);
  if (params.status === 'sent') payload.sentAt = new Date().toISOString();

  await saveEntity('email_logs', id, payload, { isNew: true });
  return id;
}

export async function confirmPaymentAndGenerateInvoice(params: {
  client: ClientRecord;
  amount: number;
  currency: string;
  serviceName: string;
  serviceDescription?: string;
  billingType: BillingType;
  paymentMethod: PaymentMethod;
  paymentDate: string;
  transactionReference: string;
  manuallyVerified: boolean;
  notes?: string;
  subscription?: SubscriptionRecord | null;
  paymentRequest?: PaymentRequestRecord | null;
  existingPayment?: PaymentRecord | null;
  existingInvoices: InvoiceRecord[];
  systemSettings: SystemSettingRecord;
  templates: EmailTemplateRecord[];
  sendConfirmationEmail?: boolean;
}): Promise<{
  paymentId: string;
  invoiceId: string;
  invoiceNumber: string;
  emailSent: boolean;
  emailError?: string;
}> {
  const nowIso = new Date().toISOString();
  const paymentId = params.existingPayment?.id || generateId('pay');

  // Guard against duplicate invoices for the same transaction
  const memoryDuplicate = params.existingInvoices.find((inv) => inv.paymentId === paymentId);
  if (memoryDuplicate) {
    return {
      paymentId,
      invoiceId: memoryDuplicate.id,
      invoiceNumber: memoryDuplicate.invoiceNumber,
      emailSent: false,
    };
  }
  try {
    const store = await fetchLocalStore();
    const storeDuplicate = store.invoices.find((inv) => inv.paymentId === paymentId);
    if (storeDuplicate) {
      return {
        paymentId,
        invoiceId: storeDuplicate.id,
        invoiceNumber: storeDuplicate.invoiceNumber,
        emailSent: false,
      };
    }
  } catch {
    // Continue if store lookup throws
  }

  const invoiceId = generateId('inv');
  const invoiceNumber = buildNextInvoiceNumber(
    params.existingInvoices,
    params.systemSettings.invoicePrefix || 'FA'
  );
  const paymentCode =
    params.existingPayment?.paymentCode ||
    `PAY-${new Date().getFullYear()}-${String(Math.floor(1000 + Math.random() * 9000))}`;

  // 1. Write/Update Payment record as PAID
  const paymentPayload: Record<string, unknown> = {
    id: paymentId,
    paymentCode,
    clientId: params.client.id,
    serviceName: params.serviceName,
    description: params.serviceDescription || '',
    billingType: params.billingType,
    paymentMethod: params.paymentMethod,
    amount: Number(params.amount),
    currency: params.currency,
    paymentDate: params.paymentDate,
    confirmedAt: nowIso,
    transactionReference: params.transactionReference || paymentCode,
    manuallyVerified: params.manuallyVerified,
    notes: params.notes || '',
    status: 'paid',
    invoiceId,
    invoiceNumber,
  };
  if (params.subscription?.id) paymentPayload.subscriptionId = params.subscription.id;
  if (params.paymentRequest?.id) paymentPayload.paymentRequestId = params.paymentRequest.id;

  await saveEntity('payments', paymentId, paymentPayload, {
    isNew: !params.existingPayment,
    silent: true,
  });

  // 2. Update linked PaymentRequest if present
  if (params.paymentRequest) {
    await saveEntity(
      'payment_requests',
      params.paymentRequest.id,
      {
        status: 'paid',
        paidAt: nowIso,
        paymentId,
      },
      { silent: true }
    );
    markBankInstructionPaid(params.paymentRequest.id, {
      paymentMethod: params.paymentMethod,
      transactionReference: params.transactionReference || paymentCode,
    }).catch(() => {});
  }

  // 3. Advance Subscription cycle & cancel cycle reminders if subscription
  let nextPaymentDateStr = '';
  if (params.subscription && params.billingType === 'subscription') {
    const previousCycleDate = params.subscription.nextPaymentDate;
    const isInitialOrEarlyPayment =
      !params.subscription.lastPaymentDate ||
      diffDays(params.paymentDate, params.subscription.nextPaymentDate) > 14;
    const baseForNext =
      !isInitialOrEarlyPayment && params.subscription.nextPaymentDate >= params.paymentDate
        ? params.subscription.nextPaymentDate
        : params.paymentDate;
    nextPaymentDateStr = calculateNextPaymentDate(
      baseForNext,
      params.subscription.billingFrequency
    );

    await saveEntity(
      'subscriptions',
      params.subscription.id,
      {
        lastPaymentDate: params.paymentDate,
        nextPaymentDate: nextPaymentDateStr,
        status: 'active',
      },
      { silent: true }
    );

    try {
      const store = await fetchLocalStore();
      const cycleLogs = store.reminder_logs.filter(
        (l) =>
          l.subscriptionId === params.subscription?.id &&
          l.billingCycleDate === previousCycleDate &&
          l.status === 'failed'
      );
      for (const l of cycleLogs) {
        await saveEntity('reminder_logs', l.id, { status: 'cancelled' }, { silent: true });
      }
    } catch {
      // Non-fatal
    }
  }

  // 4. Register signed public PDF snapshot on backend
  const pdfPayload = {
    invoiceNumber,
    invoiceDate: todayIsoDate(),
    paymentDate: params.paymentDate,
    status: 'paid',
    clientName: params.client.fullName,
    businessName: params.client.businessName,
    clientEmail: params.client.email,
    serviceName: params.serviceName,
    serviceDescription: params.serviceDescription || '',
    paymentType: params.billingType,
    paymentMethod: params.paymentMethod,
    paymentReference: params.transactionReference || paymentCode,
    manuallyVerified: params.manuallyVerified,
    amount: Number(params.amount),
    currency: params.currency,
    companyName: params.systemSettings.businessName || 'FreskaAssist',
    companyAddress: params.systemSettings.companyAddress || '',
    companyEmail: params.systemSettings.adminEmail || '',
    taxId: params.systemSettings.taxId || '',
  };

  let downloadToken = '';
  try {
    const reg = await registerPublicInvoiceSnapshot(invoiceId, pdfPayload);
    downloadToken = reg.downloadToken;
  } catch (err) {
    console.warn('Could not register public invoice snapshot:', err);
  }

  // 5. Create Invoice & Invoice Item (strictly AFTER payment confirmation)
  const invoicePayload: Record<string, unknown> = {
    id: invoiceId,
    invoiceNumber,
    clientId: params.client.id,
    clientName: params.client.fullName,
    businessName: params.client.businessName,
    clientEmail: params.client.email,
    paymentId,
    serviceName: params.serviceName,
    serviceDescription: params.serviceDescription || '',
    paymentType: params.billingType,
    paymentMethod: params.paymentMethod,
    amount: Number(params.amount),
    currency: params.currency,
    invoiceDate: todayIsoDate(),
    paymentDate: params.paymentDate,
    paymentReference: params.transactionReference || paymentCode,
    status: 'paid',
    downloadToken,
    sentViaGmail: false,
  };
  if (params.paymentRequest?.id) invoicePayload.paymentRequestId = params.paymentRequest.id;
  if (params.subscription?.id) invoicePayload.subscriptionId = params.subscription.id;

  await saveEntity('invoices', invoiceId, invoicePayload, { isNew: true, silent: true });
  const itemId = generateId('item');
  await saveEntity(
    'invoice_items',
    itemId,
    {
      id: itemId,
      invoiceId,
      description: `${params.serviceName}${
        params.serviceDescription ? ` — ${params.serviceDescription}` : ''
      }`,
      quantity: 1,
      unitPrice: Number(params.amount),
      total: Number(params.amount),
    },
    { isNew: true }
  );

  // 6. Auto-send PDF Invoice ONLY (no invoice URL link) via Gmail when enabled & token active
  let emailSent = false;
  let emailError: string | undefined;
  const shouldSendEmail = params.sendConfirmationEmail !== false;

  if (shouldSendEmail && isEmailDeliveryAvailable()) {
    const tpl =
      params.templates.find((t) => t.templateKey === 'invoice_delivery') ||
      params.templates.find((t) => t.templateKey === 'payment_confirmation');

    const subject = interpolateTemplate(
      tpl?.subject || 'Invoice {{invoice_number}} — {{service_name}}',
      {
        client_name: params.client.fullName,
        business_name: params.client.businessName,
        service_name: params.serviceName,
        amount: params.amount.toFixed(2),
        currency: params.currency,
        invoice_number: invoiceNumber,
        invoice_link: '',
        next_payment_date: nextPaymentDateStr || 'One-Time Purchase',
      }
    );

    const rawBody = interpolateTemplate(
      tpl?.body ||
        'Hello {{client_name}},\n\nYour payment of {{amount}} {{currency}} has been confirmed. Please find your official PDF invoice {{invoice_number}} attached to this email.',
      {
        client_name: params.client.fullName,
        business_name: params.client.businessName,
        service_name: params.serviceName,
        amount: params.amount.toFixed(2),
        currency: params.currency,
        invoice_number: invoiceNumber,
        invoice_link: '',
        next_payment_date: nextPaymentDateStr || 'One-Time Purchase',
      }
    );

    // Strip any residual online-link header lines from older custom templates so ONLY PDF is delivered
    const bodyText = rawBody
      .replace(/^(Online copy|Download your receipt and invoice):\s*\n?/gim, '')
      .replace(/\n{3,}/g, '\n\n')
      .trim();

    try {
      const sentRes = await sendGmailMessage({
        to: params.client.email,
        subject,
        bodyText,
        senderDisplayName: tpl?.senderDisplayName || 'FreskaAssist Billing',
        invoicePayload: pdfPayload,
      });

      emailSent = true;
      await saveEntity('invoices', invoiceId, {
        sentViaGmail: true,
        sentAt: new Date().toISOString(),
      });
      await logEmailDispatch({
        clientId: params.client.id,
        recipient: params.client.email,
        subject,
        emailType: 'invoice_delivery',
        status: 'sent',
        gmailMessageId: sentRes.messageId,
      });
    } catch (err) {
      emailError = err instanceof Error ? err.message : 'Failed to dispatch invoice email';
      await logEmailDispatch({
        clientId: params.client.id,
        recipient: params.client.email,
        subject,
        emailType: 'invoice_delivery',
        status: 'failed',
        errorMessage: emailError,
      });
    }
  }

  return { paymentId, invoiceId, invoiceNumber, emailSent, emailError };
}

export async function createBankTransferPaymentUrl(params: {
  requestId: string;
  reference: string;
  client: ClientRecord;
  serviceName: string;
  description: string;
  amount: number;
  currency: string;
  dueDate: string;
  billingType?: BillingType;
  subscriptionId?: string;
  gatewaySettings: PaymentGatewaySettingRecord;
  systemSettings: SystemSettingRecord;
}): Promise<string> {
  const res = await registerBankInstructionSnapshot({
    requestId: params.requestId,
    reference: params.reference,
    clientId: params.client.id,
    subscriptionId: params.subscriptionId || '',
    billingType: params.billingType || 'one_time',
    clientName: params.client.fullName,
    businessName: params.client.businessName,
    serviceName: params.serviceName,
    description: params.description,
    amount: params.amount,
    currency: params.currency,
    dueDate: params.dueDate,
    status: 'pending',
    bankAccountName: params.gatewaySettings.bankAccountName || '',
    bankName: params.gatewaySettings.bankName || '',
    bankIban: params.gatewaySettings.bankIban || '',
    bankBic: params.gatewaySettings.bankBic || '',
    bankInstructions: params.gatewaySettings.bankInstructions || '',
    companyName: params.systemSettings.businessName || 'FreskaAssist',
    updatedAt: new Date().toISOString(),
  });
  return res.paymentUrl;
}

export interface ReminderEvaluationSummary {
  evaluated: number;
  sent: number;
  failed: number;
  skipped: number;
  details: string[];
}

function extractIsoDateOnly(value: unknown): string | null {
  if (!value) return null;
  if (typeof value === 'string') {
    const match = value.match(/^\d{4}-\d{2}-\d{2}/);
    return match ? match[0] : null;
  }
  if (
    typeof value === 'object' &&
    'toDate' in value &&
    typeof (value as { toDate: () => Date }).toDate === 'function'
  ) {
    return (value as { toDate: () => Date }).toDate().toISOString().slice(0, 10);
  }
  if (value instanceof Date) {
    return value.toISOString().slice(0, 10);
  }
  return null;
}

async function ensureClientPaymentLink(params: {
  client: ClientRecord;
  subscription?: SubscriptionRecord | null;
  existingRequests: PaymentRequestRecord[];
  gatewaySettings?: PaymentGatewaySettingRecord;
  systemSettings?: SystemSettingRecord;
}): Promise<string> {
  const targetBillingType: BillingType = params.subscription ? 'subscription' : 'one_time';
  const existing = params.existingRequests.find(
    (r) =>
      r.clientId === params.client.id &&
      (params.subscription ? r.subscriptionId === params.subscription.id : r.billingType === 'one_time') &&
      (r.status === 'pending' || r.status === 'overdue') &&
      Boolean(r.paymentUrl)
  );
  if (existing?.paymentUrl) {
    return existing.paymentUrl;
  }

  if (!params.gatewaySettings || !params.systemSettings) {
    const fallbackReq = params.existingRequests.find(
      (r) =>
        r.clientId === params.client.id &&
        (r.status === 'pending' || r.status === 'overdue') &&
        Boolean(r.paymentUrl)
    );
    return fallbackReq?.paymentUrl || '';
  }

  const pkg = STANDARD_PACKAGES[targetBillingType];
  const amount = params.subscription ? params.subscription.monthlyPrice : pkg.defaultPrice;
  const currency =
    params.subscription?.currency ||
    params.client.preferredCurrency ||
    params.systemSettings.defaultCurrency ||
    'EUR';
  const serviceName = params.subscription?.name || pkg.name;
  const description = params.subscription?.description || pkg.description;
  const dueDate = params.subscription?.nextPaymentDate || todayIsoDate();

  const requestId = generateId('req');
  const reference = `FA-REF-${Math.floor(100000 + Math.random() * 900000)}`;
  let paymentUrl = '';
  try {
    paymentUrl = await createBankTransferPaymentUrl({
      requestId,
      reference,
      client: params.client,
      serviceName,
      description,
      amount,
      currency,
      dueDate,
      billingType: targetBillingType,
      subscriptionId: params.subscription?.id,
      gatewaySettings: params.gatewaySettings,
      systemSettings: params.systemSettings,
    });
  } catch {
    return '';
  }

  await saveEntity(
    'payment_requests',
    requestId,
    {
      id: requestId,
      clientId: params.client.id,
      subscriptionId: params.subscription?.id || '',
      serviceId: params.subscription?.serviceId || pkg.id,
      serviceName,
      description,
      billingType: targetBillingType,
      paymentMethod: params.subscription?.paymentMethod || params.client.preferredPaymentMethod || 'bank_transfer',
      reference,
      amount,
      currency,
      dueDate,
      paymentUrl,
      gatewaySessionId: '',
      status: 'pending',
    },
    { isNew: true }
  );

  return paymentUrl;
}

export async function evaluateAndDispatchReminders(params: {
  clients: ClientRecord[];
  subscriptions: SubscriptionRecord[];
  payments: PaymentRecord[];
  paymentRequests: PaymentRequestRecord[];
  reminderSettings: ReminderSettingRecord[];
  reminderLogs: ReminderLogRecord[];
  emailLogs?: EmailLogRecord[];
  templates: EmailTemplateRecord[];
  gatewaySettings?: PaymentGatewaySettingRecord;
  systemSettings?: SystemSettingRecord;
  sentKeysGuard?: Set<string>;
}): Promise<ReminderEvaluationSummary> {
  const today = todayIsoDate();
  const hasGmail = isEmailDeliveryAvailable();
  const summary: ReminderEvaluationSummary = {
    evaluated: 0,
    sent: 0,
    failed: 0,
    skipped: 0,
    details: [],
  };

  // PART 1: 2-Day Post-Onboarding Payment Link Dispatch (Subscription clients wait 2 days after added)
  for (const client of params.clients) {
    if (client.status === 'archived' || !client.email) continue;
    const createdDate = extractIsoDateOnly(client.createdAt);
    if (!createdDate) continue;

    const daysSinceCreated = diffDays(createdDate, today);
    if (daysSinceCreated < 2) continue;

    const hasPaidPayment = params.payments.some(
      (p) => p.clientId === client.id && p.status === 'paid'
    );
    if (hasPaidPayment) continue;

    const guardKey = `onb:${client.id}`;
    if (params.sentKeysGuard?.has(guardKey)) continue;

    const alreadySentOnboardingLink = (params.emailLogs || []).some(
      (e) =>
        e.clientId === client.id &&
        e.emailType === 'onboarding_payment_link' &&
        e.status === 'sent'
    );
    if (alreadySentOnboardingLink) continue;

    const activeSub =
      params.subscriptions.find((s) => s.clientId === client.id && s.status !== 'cancelled') || null;
    const openOneTimeReq =
      params.paymentRequests.find(
        (r) =>
          r.clientId === client.id &&
          r.billingType === 'one_time' &&
          (r.status === 'pending' || r.status === 'overdue')
      ) || null;

    // One-time payment clients already receive their link immediately on Day 0 welcome if Gmail was active;
    // only dispatch Day-2 onboarding link for one-time if welcome email was never sent, OR always for Subscription clients after 2 days.
    if (!activeSub) {
      const welcomedOnDay0 = (params.emailLogs || []).some(
        (e) => e.clientId === client.id && e.emailType === 'client_welcome' && e.status === 'sent'
      );
      if (welcomedOnDay0 || !openOneTimeReq) continue;
    }

    summary.evaluated += 1;
    if (!hasGmail) {
      summary.failed += 1;
      summary.details.push(`${client.businessName}: 2-day payment link waiting for Gmail auth`);
      continue;
    }

    const paymentUrl = await ensureClientPaymentLink({
      client,
      subscription: activeSub,
      existingRequests: params.paymentRequests,
      gatewaySettings: params.gatewaySettings,
      systemSettings: params.systemSettings,
    });

    if (!paymentUrl) {
      summary.skipped += 1;
      continue;
    }

    const tpl =
      params.templates.find((t) => t.templateKey === 'onboarding_payment_link') ||
      params.templates.find((t) => t.templateKey === 'payment_link');
    const amount = activeSub
      ? activeSub.monthlyPrice
      : openOneTimeReq?.amount ?? STANDARD_PACKAGES.one_time.defaultPrice;
    const currency =
      activeSub?.currency ||
      openOneTimeReq?.currency ||
      client.preferredCurrency ||
      'EUR';
    const serviceName =
      activeSub?.name || openOneTimeReq?.serviceName || STANDARD_PACKAGES.subscription.name;

    const ctx = {
      client_name: client.fullName,
      business_name: client.businessName,
      service_name: serviceName,
      amount: amount.toFixed(2),
      currency,
      payment_link: paymentUrl,
      due_date: today,
    };

    const subject = interpolateTemplate(
      tpl?.subject || 'Complete your {{service_name}} setup — {{business_name}}',
      ctx
    );
    const bodyText = interpolateTemplate(
      tpl?.body ||
        `Hello {{client_name}},\n\nHere is your payment link for {{service_name}} ({{amount}} {{currency}}):\n{{payment_link}}\n\nBest regards,\nFreskaAssist`,
      ctx
    );

    try {
      params.sentKeysGuard?.add(guardKey);
      const sent = await sendGmailMessage({
        to: client.email,
        subject,
        bodyText,
        senderDisplayName: tpl?.senderDisplayName || 'FreskaAssist Billing',
      });
      await logEmailDispatch({
        clientId: client.id,
        recipient: client.email,
        subject,
        emailType: 'onboarding_payment_link',
        status: 'sent',
        gmailMessageId: sent.messageId,
      });
      summary.sent += 1;
      summary.details.push(`${client.businessName}: Sent 2-day payment link`);
    } catch (err) {
      params.sentKeysGuard?.delete(guardKey);
      const msg = err instanceof Error ? err.message : 'Failed to send 2-day payment link';
      await logEmailDispatch({
        clientId: client.id,
        recipient: client.email,
        subject,
        emailType: 'onboarding_payment_link',
        status: 'failed',
        errorMessage: msg,
      });
      summary.failed += 1;
      summary.details.push(`${client.businessName}: 2-day link failed (${msg})`);
    }
  }

  // PART 2: 1-Month Subscription Renewal & Service Suspension Reminders
  for (const sub of params.subscriptions) {
    summary.evaluated += 1;

    if (sub.status === 'cancelled' || sub.status === 'paused') {
      summary.skipped += 1;
      continue;
    }

    if (!sub.reminderEnabled) {
      summary.skipped += 1;
      continue;
    }

    const client = params.clients.find((c) => c.id === sub.clientId);
    if (!client || client.status === 'archived') {
      summary.skipped += 1;
      continue;
    }

    const clientSetting = params.reminderSettings.find((r) => r.clientId === client.id);
    if (clientSetting && !clientSetting.enabled) {
      summary.skipped += 1;
      continue;
    }

    if (sub.lastPaymentDate && sub.lastPaymentDate >= sub.nextPaymentDate) {
      summary.skipped += 1;
      continue;
    }

    const daysBefore = clientSetting?.daysBeforeDue ?? 3;
    const sendOnDue = clientSetting?.sendOnDueDate ?? true;
    const daysAfter1 = clientSetting?.daysAfterDueFirst ?? 3;
    const daysAfter2 = clientSetting?.daysAfterDueSecond ?? 7;

    const daysUntilDue = diffDays(today, sub.nextPaymentDate);

    let stage: ReminderStage | null = null;
    if (sub.lastPaymentDate && daysUntilDue > 0 && daysUntilDue <= daysBefore && daysBefore > 0) {
      stage = 'before_due';
    } else if (daysUntilDue <= 0 && daysUntilDue > -Math.max(1, daysAfter1) && sendOnDue) {
      stage = 'due_today';
    } else if (
      daysUntilDue <= -Math.max(1, daysAfter1) &&
      daysUntilDue > -Math.max(daysAfter1 + 1, daysAfter2) &&
      daysAfter1 > 0
    ) {
      stage = 'overdue_1';
    } else if (daysUntilDue <= -Math.max(1, daysAfter2) && daysAfter2 > 0) {
      stage = 'overdue_2';
    }

    if (daysUntilDue < 0 && sub.status !== 'overdue') {
      await saveEntity('subscriptions', sub.id, { status: 'overdue' }, { silent: true });
    }

    if (!stage) {
      summary.skipped += 1;
      continue;
    }

    const deterministicLogId = `rem_${sub.id}_${sub.nextPaymentDate}_${stage}`.replace(
      /[^a-zA-Z0-9_\-]/g,
      '_'
    );
    if (params.sentKeysGuard?.has(deterministicLogId)) {
      summary.skipped += 1;
      continue;
    }
    const alreadyLogged = params.reminderLogs.find((l) => l.id === deterministicLogId);
    if (alreadyLogged && alreadyLogged.status === 'sent') {
      summary.skipped += 1;
      continue;
    }

    const paymentLink = await ensureClientPaymentLink({
      client,
      subscription: sub,
      existingRequests: params.paymentRequests,
      gatewaySettings: params.gatewaySettings,
      systemSettings: params.systemSettings,
    });

    const templateKey =
      stage === 'before_due'
        ? 'upcoming_reminder'
        : stage === 'due_today'
        ? 'payment_due_today'
        : 'overdue_reminder';

    const tpl = params.templates.find((t) => t.templateKey === templateKey);
    const ctx = {
      client_name: client.fullName,
      business_name: client.businessName,
      service_name: sub.name,
      amount: sub.monthlyPrice.toFixed(2),
      currency: sub.currency,
      payment_link: paymentLink || 'Please reply to request a payment link.',
      due_date: sub.nextPaymentDate,
      next_payment_date: sub.nextPaymentDate,
    };

    const subject = interpolateTemplate(
      tpl?.subject || 'Action required: {{service_name}} renewal due {{due_date}}',
      ctx
    );
    const bodyText = interpolateTemplate(
      tpl?.body ||
        'Hello {{client_name}}, your monthly subscription payment of {{amount}} {{currency}} is due on {{due_date}}. Please pay promptly using {{payment_link}} or your service will be paused.',
      ctx
    );

    if (!hasGmail) {
      await saveEntity(
        'reminder_logs',
        deterministicLogId,
        {
          id: deterministicLogId,
          clientId: client.id,
          subscriptionId: sub.id,
          billingCycleDate: sub.nextPaymentDate,
          stage,
          status: 'failed',
          errorMessage: 'Gmail authorization token is not active in current session.',
          scheduledFor: today,
        },
        { isNew: true }
      );
      summary.failed += 1;
      summary.details.push(`${client.businessName}: Gmail session inactive`);
      continue;
    }

    try {
      params.sentKeysGuard?.add(deterministicLogId);
      const sent = await sendGmailMessage({
        to: client.email,
        subject,
        bodyText,
        senderDisplayName: tpl?.senderDisplayName || 'FreskaAssist Billing',
      });

      const emailLogId = await logEmailDispatch({
        clientId: client.id,
        recipient: client.email,
        subject,
        emailType: templateKey,
        status: 'sent',
        gmailMessageId: sent.messageId,
      });

      await saveEntity(
        'reminder_logs',
        deterministicLogId,
        {
          id: deterministicLogId,
          clientId: client.id,
          subscriptionId: sub.id,
          billingCycleDate: sub.nextPaymentDate,
          stage,
          emailLogId,
          status: 'sent',
          scheduledFor: today,
          sentAt: new Date().toISOString(),
        },
        { isNew: true }
      );

      summary.sent += 1;
      summary.details.push(`${client.businessName}: Sent ${stage} reminder`);
    } catch (err) {
      params.sentKeysGuard?.delete(deterministicLogId);
      const msg = err instanceof Error ? err.message : 'Failed to send reminder email';
      const emailLogId = await logEmailDispatch({
        clientId: client.id,
        recipient: client.email,
        subject,
        emailType: templateKey,
        status: 'failed',
        errorMessage: msg,
      });
      await saveEntity(
        'reminder_logs',
        deterministicLogId,
        {
          id: deterministicLogId,
          clientId: client.id,
          subscriptionId: sub.id,
          billingCycleDate: sub.nextPaymentDate,
          stage,
          emailLogId,
          status: 'failed',
          errorMessage: msg.slice(0, 950),
          scheduledFor: today,
        },
        { isNew: true }
      );
      summary.failed += 1;
      summary.details.push(`${client.businessName}: Failed (${msg})`);
    }
  }

  return summary;
}

export function exportPaymentsToCsv(
  payments: PaymentRecord[],
  clients: ClientRecord[]
): string {
  const headers = [
    'Payment ID',
    'Payment Code',
    'Client Name',
    'Business Name',
    'Service',
    'Billing Type',
    'Payment Method',
    'Amount',
    'Currency',
    'Payment Date',
    'Status',
    'Invoice Number',
    'Transaction Reference',
    'Manually Verified',
  ];

  const rows = payments.map((p) => {
    const client = clients.find((c) => c.id === p.clientId);
    const cols = [
      p.id,
      p.paymentCode,
      client?.fullName || '',
      client?.businessName || '',
      p.serviceName,
      p.billingType,
      p.paymentMethod,
      p.amount.toFixed(2),
      p.currency,
      p.paymentDate,
      p.status,
      p.invoiceNumber || '',
      p.transactionReference || '',
      p.manuallyVerified ? 'Yes' : 'No',
    ];
    return cols.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}
