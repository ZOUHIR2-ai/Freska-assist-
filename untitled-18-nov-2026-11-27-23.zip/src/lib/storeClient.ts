import { auth, hasVerifiedGoogleAccount } from './firebase.ts';
import { putStoreDocument, deleteStoreDocument } from './api.ts';
import {
  deleteDocFromFirestore,
  SyncCollectionName,
  writeDocToFirestore,
} from './firestoreSync.ts';

type StoreRefreshListener = () => Promise<void> | void;

const listeners = new Set<StoreRefreshListener>();

export function registerStoreSyncCallback(fn: StoreRefreshListener): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

function notifyStoreMutated() {
  for (const fn of listeners) {
    try {
      fn();
    } catch {
      // Ignore refresh listener errors
    }
  }
}

export async function saveEntity(
  collectionName: string,
  docId: string,
  data: Record<string, unknown>,
  options?: { isNew?: boolean; silent?: boolean }
): Promise<void> {
  if (!auth.currentUser) {
    throw new Error('Connect your Google Account first so client data stays saved in your account.');
  }

  const nowIso = new Date().toISOString();
  const cleanPayload: Record<string, unknown> = {
    ...data,
    id: docId,
    updatedAt: nowIso,
  };
  if (options?.isNew && !cleanPayload.createdAt) {
    cleanPayload.createdAt = nowIso;
  }

  let cloudSynced = false;
  if (hasVerifiedGoogleAccount(auth.currentUser)) {
    try {
      cloudSynced = await writeDocToFirestore(
        collectionName as SyncCollectionName,
        docId,
        cleanPayload,
        { isNew: options?.isNew }
      );
    } catch (err) {
      console.warn(`Cloud Firestore write deferred for ${collectionName}/${docId}:`, err);
      cloudSynced = false;
    }
  }

  await putStoreDocument(collectionName, docId, {
    ...cleanPayload,
    _cloudSynced: cloudSynced,
  });

  if (!options?.silent) {
    notifyStoreMutated();
  }
}

export async function deleteEntity(collectionName: string, docId: string): Promise<void> {
  if (!auth.currentUser) {
    throw new Error('Connect your Google Account first to manage client data.');
  }

  if (hasVerifiedGoogleAccount(auth.currentUser)) {
    try {
      await deleteDocFromFirestore(collectionName as SyncCollectionName, docId);
    } catch (err) {
      console.warn(`Firestore delete skipped for ${collectionName}/${docId}:`, err);
    }
  }

  await deleteStoreDocument(collectionName, docId);
  notifyStoreMutated();
}
