import type { EmailTemplateRecord } from '../types/freska.ts';

export const TEMPLATE_VARIABLES = [
  '{{client_name}}',
  '{{business_name}}',
  '{{service_name}}',
  '{{amount}}',
  '{{currency}}',
  '{{payment_link}}',
  '{{invoice_number}}',
  '{{due_date}}',
  '{{next_payment_date}}',
];

export const DEFAULT_EMAIL_TEMPLATES: Omit<EmailTemplateRecord, 'updatedAt'>[] = [
  {
    id: 'tpl_payment_link',
    templateKey: 'payment_link',
    label: '1. Payment Link',
    senderDisplayName: 'FreskaAssist',
    subject: 'Billing summary for {{business_name}} — {{service_name}}',
    body: `Hello {{client_name}},

Here are the billing details for {{business_name}} ({{service_name}}).

Amount: {{amount}} {{currency}}
Due date: {{due_date}}

You can view your payment instructions (bank transfer or card) at:
{{payment_link}}

Let me know if you have any questions.

Best regards,
FreskaAssist`,
  },
  {
    id: 'tpl_payment_confirmation',
    templateKey: 'payment_confirmation',
    label: '2. Payment Confirmation (PDF Attached)',
    senderDisplayName: 'FreskaAssist',
    subject: 'Payment confirmation — {{service_name}} ({{invoice_number}})',
    body: `Hello {{client_name}},

Thank you. We have recorded your payment of {{amount}} {{currency}} for {{service_name}} ({{business_name}}).

Invoice number: {{invoice_number}}
Next billing date: {{next_payment_date}}

Your official PDF invoice is attached directly to this email.

Best regards,
FreskaAssist`,
  },
  {
    id: 'tpl_invoice_delivery',
    templateKey: 'invoice_delivery',
    label: '3. Invoice Delivery (PDF Only)',
    senderDisplayName: 'FreskaAssist',
    subject: 'Invoice {{invoice_number}} for {{business_name}}',
    body: `Hello {{client_name}},

Thank you for your payment. Please find your official invoice {{invoice_number}} for {{business_name}} attached as a PDF file to this email.

Service: {{service_name}}
Amount settled: {{amount}} {{currency}}
Next billing date: {{next_payment_date}}

Best regards,
FreskaAssist`,
  },
  {
    id: 'tpl_upcoming_reminder',
    templateKey: 'upcoming_reminder',
    label: '4. Upcoming Payment Reminder',
    senderDisplayName: 'FreskaAssist',
    subject: 'Upcoming billing notice — {{service_name}} ({{due_date}})',
    body: `Hello {{client_name}},

Just a quick note that your next billing cycle for {{service_name}} ({{business_name}}) is scheduled for {{due_date}}.

Amount: {{amount}} {{currency}}

Payment link (Bank Transfer & Card Checkout):
{{payment_link}}

Please reply if you need any adjustments.

Best regards,
FreskaAssist`,
  },
  {
    id: 'tpl_payment_due_today',
    templateKey: 'payment_due_today',
    label: '5. Monthly Renewal Due (Service Pause Notice)',
    senderDisplayName: 'FreskaAssist',
    subject: 'Monthly renewal for {{service_name}} — {{business_name}}',
    body: `Hello {{client_name}},

Your monthly subscription renewal of {{amount}} {{currency}} for {{service_name}} ({{business_name}}) is due today ({{due_date}}).

Please complete your payment using the link below so your service remains active without interruption. If payment is not received, the service will be paused until the balance is settled:
{{payment_link}}

Thank you,
FreskaAssist`,
  },
  {
    id: 'tpl_overdue_reminder',
    templateKey: 'overdue_reminder',
    label: '6. Overdue Renewal Follow-Up (Service Pause Notice)',
    senderDisplayName: 'FreskaAssist',
    subject: 'Follow-up: {{service_name}} renewal ({{business_name}})',
    body: `Hello {{client_name}},

Following up on your monthly subscription payment for {{service_name}} ({{business_name}}) of {{amount}} {{currency}}, which was due on {{due_date}}.

Please settle this balance using the link below, otherwise your service will be paused until payment is confirmed:
{{payment_link}}

If you already sent a bank transfer, simply reply with your reference number so I can verify it right away.

Best regards,
FreskaAssist`,
  },
  {
    id: 'tpl_subscription_update',
    templateKey: 'subscription_update',
    label: '7. Subscription Update',
    senderDisplayName: 'FreskaAssist',
    subject: 'Plan update for {{business_name}} — {{service_name}}',
    body: `Hello {{client_name}},

Your service plan for {{service_name}} ({{business_name}}) has been updated.

Monthly rate: {{amount}} {{currency}}
Next billing date: {{next_payment_date}}

Please reply to this email if you have any questions.

Best regards,
FreskaAssist`,
  },
  {
    id: 'tpl_subscription_cancellation',
    templateKey: 'subscription_cancellation',
    label: '8. Subscription Cancellation',
    senderDisplayName: 'FreskaAssist',
    subject: 'Plan cancellation confirmation — {{service_name}}',
    body: `Hello {{client_name}},

This confirms that your recurring plan for {{service_name}} ({{business_name}}) has been cancelled. No further automated billing reminders will be sent for this service.

Your previous invoices remain available for your records.

Best regards,
FreskaAssist`,
  },
  {
    id: 'tpl_client_welcome',
    templateKey: 'client_welcome',
    label: '9. Client Welcome',
    senderDisplayName: 'FreskaAssist',
    subject: 'Welcome to FreskaAssist — {{business_name}}',
    body: `Hello {{client_name}},

Welcome to FreskaAssist. Your account for {{business_name}} is now set up for {{service_name}} ({{amount}} {{currency}}).
{{payment_link_section}}
If you have any questions, simply reply to this email.

Best regards,
FreskaAssist`,
  },
  {
    id: 'tpl_onboarding_payment_link',
    templateKey: 'onboarding_payment_link',
    label: '10. Onboarding Payment Link (2-Day Follow-Up)',
    senderDisplayName: 'FreskaAssist',
    subject: 'Complete your {{service_name}} setup — {{business_name}}',
    body: `Hello {{client_name}},

Following up on your welcome to FreskaAssist for {{business_name}}.

Here is your dedicated payment link for {{service_name}} ({{amount}} {{currency}}). You can pay securely by Bank Transfer (Virement) or Card Checkout:
{{payment_link}}

Please let us know if you need anything at all.

Best regards,
FreskaAssist`,
  },
];

export interface TemplateContext {
  client_name?: string;
  business_name?: string;
  service_name?: string;
  amount?: string | number;
  currency?: string;
  payment_link?: string;
  payment_link_section?: string;
  invoice_number?: string;
  invoice_link?: string;
  due_date?: string;
  next_payment_date?: string;
}

export function interpolateTemplate(text: string, ctx: TemplateContext): string {
  const map: Record<string, string> = {
    '{{client_name}}': ctx.client_name ?? '',
    '{{business_name}}': ctx.business_name ?? '',
    '{{service_name}}': ctx.service_name ?? '',
    '{{amount}}': ctx.amount !== undefined ? String(ctx.amount) : '',
    '{{currency}}': ctx.currency ?? 'EUR',
    '{{payment_link}}': ctx.payment_link || '',
    '{{payment_link_section}}': ctx.payment_link_section ?? '',
    '{{invoice_number}}': ctx.invoice_number || 'N/A',
    '{{invoice_link}}': '',
    '{{due_date}}': ctx.due_date || 'N/A',
    '{{next_payment_date}}': ctx.next_payment_date || 'N/A',
  };

  let out = text;
  for (const [token, value] of Object.entries(map)) {
    out = out.split(token).join(value);
  }
  return out;
}
