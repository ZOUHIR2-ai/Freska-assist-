import { auth, getCachedGmailAccessToken } from './firebase.ts';
import type {
  ClientRecord,
  EmailLogRecord,
  EmailTemplateRecord,
  InvoiceItemRecord,
  InvoiceRecord,
  PaymentGatewaySettingRecord,
  PaymentRecord,
  PaymentRequestRecord,
  PublicGatewayStatus,
  ReminderLogRecord,
  ReminderSettingRecord,
  ServiceRecord,
  SubscriptionRecord,
  SystemSettingRecord,
  WebhookEventRecord,
} from '../types/freska.ts';

export interface LocalStorePayload {
  clients: ClientRecord[];
  services: ServiceRecord[];
  subscriptions: SubscriptionRecord[];
  payments: PaymentRecord[];
  payment_requests: PaymentRequestRecord[];
  invoices: InvoiceRecord[];
  invoice_items: InvoiceItemRecord[];
  reminder_settings: ReminderSettingRecord[];
  reminder_logs: ReminderLogRecord[];
  email_logs: EmailLogRecord[];
  email_templates: EmailTemplateRecord[];
  payment_gateway_settings: PaymentGatewaySettingRecord[];
  webhook_events: WebhookEventRecord[];
  system_settings: SystemSettingRecord[];
}

async function getAdminHeaders(
  extra?: Record<string, string>,
  forceRefresh = false
): Promise<Record<string, string>> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...extra,
  };
  const user = auth.currentUser;
  if (user) {
    try {
      const idToken = await user.getIdToken(forceRefresh);
      if (idToken) {
        headers['X-Firebase-Id-Token'] = idToken;
      }
    } catch {
      if (!forceRefresh) {
        try {
          const freshToken = await user.getIdToken(true);
          if (freshToken) {
            headers['X-Firebase-Id-Token'] = freshToken;
          }
        } catch {
          // Proceed without Firebase ID token if offline
        }
      }
    }
  }
  return headers;
}

async function apiFetch(
  input: string,
  init?: {
    method?: string;
    extraHeaders?: Record<string, string>;
    body?: string;
  }
): Promise<Response> {
  const headers = await getAdminHeaders(init?.extraHeaders, false);
  const res = await fetch(input, {
    method: init?.method,
    headers,
    body: init?.body,
  });

  if (res.status === 401 && auth.currentUser) {
    const retryHeaders = await getAdminHeaders(init?.extraHeaders, true);
    if (retryHeaders['X-Firebase-Id-Token']) {
      return fetch(input, {
        method: init?.method,
        headers: retryHeaders,
        body: init?.body,
      });
    }
  }

  return res;
}

async function handleJsonResponse<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const errMsg = (data as { error?: string }).error || `Request failed with status ${res.status}`;
    throw new Error(errMsg);
  }
  return data as T;
}

export async function fetchLocalStore(): Promise<LocalStorePayload> {
  const res = await apiFetch('/api/store');
  return handleJsonResponse<LocalStorePayload>(res);
}

export async function putStoreDocument(
  collectionName: string,
  docId: string,
  data: Record<string, unknown>
): Promise<Record<string, unknown>> {
  const res = await apiFetch(
    `/api/store/${encodeURIComponent(collectionName)}/${encodeURIComponent(docId)}`,
    {
      method: 'PUT',
      body: JSON.stringify(data),
    }
  );
  return handleJsonResponse<Record<string, unknown>>(res);
}

export async function deleteStoreDocument(collectionName: string, docId: string): Promise<void> {
  const res = await apiFetch(
    `/api/store/${encodeURIComponent(collectionName)}/${encodeURIComponent(docId)}`,
    {
      method: 'DELETE',
    }
  );
  await handleJsonResponse(res);
}

export async function fetchGatewayStatus(): Promise<PublicGatewayStatus> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/gateway/status', { headers });
  return handleJsonResponse<PublicGatewayStatus>(res);
}

export async function saveGatewayConfig(payload: {
  provider: 'stripe';
  environment: 'test' | 'live';
  publicKey: string;
  secretKey: string;
  webhookSecret: string;
}): Promise<PublicGatewayStatus> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/gateway/config', {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
  });
  return handleJsonResponse<PublicGatewayStatus>(res);
}

export async function clearGatewayConfig(): Promise<PublicGatewayStatus> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/gateway/clear', {
    method: 'POST',
    headers,
  });
  return handleJsonResponse<PublicGatewayStatus>(res);
}

export async function testGatewayConnection(): Promise<{
  verified: boolean;
  accountId: string;
  status: PublicGatewayStatus;
}> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/gateway/test', {
    method: 'POST',
    headers,
  });
  return handleJsonResponse(res);
}

export async function toggleGatewayEnabled(enabled: boolean): Promise<PublicGatewayStatus> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/gateway/toggle', {
    method: 'POST',
    headers,
    body: JSON.stringify({ enabled }),
  });
  return handleJsonResponse<PublicGatewayStatus>(res);
}

export async function createHostedCheckoutSession(payload: {
  paymentRequestId: string;
  clientId: string;
  clientEmail: string;
  serviceName: string;
  description?: string;
  amount: number;
  currency: string;
  billingType: 'subscription' | 'one_time';
  subscriptionId?: string;
}): Promise<{ checkoutUrl: string; sessionId: string }> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/gateway/checkout', {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
  });
  return handleJsonResponse(res);
}

export async function checkCheckoutSessionStatus(sessionId: string): Promise<{
  id: string;
  paymentStatus: string;
  status: string;
  amountTotal: number;
  currency: string;
  paymentIntent: string;
  metadata: Record<string, string>;
}> {
  const headers = await getAdminHeaders();
  const res = await fetch(`/api/admin/gateway/session/${encodeURIComponent(sessionId)}`, {
    headers,
  });
  return handleJsonResponse(res);
}

export async function registerPublicInvoiceSnapshot(
  invoiceId: string,
  payload: Record<string, unknown>
): Promise<{ downloadToken: string; downloadUrl: string }> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/invoices/register-public', {
    method: 'POST',
    headers,
    body: JSON.stringify({ invoiceId, payload }),
  });
  return handleJsonResponse(res);
}

export async function fetchInvoicePdfBlob(payload: Record<string, unknown>): Promise<Blob> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/invoices/pdf', {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error((err as { error?: string }).error || 'Failed to generate PDF');
  }
  return res.blob();
}

export async function registerBankInstructionSnapshot(
  snapshot: Record<string, unknown>
): Promise<{ paymentUrl: string; signature: string }> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/payment-requests/register-bank', {
    method: 'POST',
    headers,
    body: JSON.stringify(snapshot),
  });
  return handleJsonResponse(res);
}

export async function markBankInstructionPaid(
  requestId: string,
  payload?: { paymentMethod?: string; transactionReference?: string }
): Promise<void> {
  const headers = await getAdminHeaders();
  const res = await fetch(
    `/api/admin/payment-requests/${encodeURIComponent(requestId)}/mark-paid`,
    {
      method: 'POST',
      headers,
      body: JSON.stringify(payload || {}),
    }
  );
  await handleJsonResponse(res);
}

export type SmtpPreset = 'custom' | 'brevo' | 'resend' | 'sendgrid' | 'gmail_smtp';

export interface PublicSmtpStatus {
  preset: SmtpPreset;
  host: string;
  port: number;
  secure: boolean;
  username: string;
  hasPassword: boolean;
  passwordLast4: string;
  fromName: string;
  fromEmail: string;
  replyTo: string;
  publicPortalUrl: string;
  enabled: boolean;
  connectionVerified: boolean;
  lastVerifiedAt: string | null;
  updatedAt: string;
}

let cachedServerSmtpActive = false;

export function setServerSmtpActive(active: boolean): void {
  cachedServerSmtpActive = active;
}

export function isEmailDeliveryAvailable(): boolean {
  return Boolean(getCachedGmailAccessToken()) || cachedServerSmtpActive;
}

export async function fetchSmtpStatus(): Promise<PublicSmtpStatus> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/email/status', { headers });
  const data = await handleJsonResponse<PublicSmtpStatus>(res);
  cachedServerSmtpActive = Boolean(data.enabled && data.connectionVerified);
  return data;
}

export async function saveSmtpConfig(payload: {
  preset?: SmtpPreset;
  host?: string;
  port?: number;
  secure?: boolean;
  username?: string;
  password?: string;
  fromName?: string;
  fromEmail?: string;
  replyTo?: string;
  publicPortalUrl?: string;
}): Promise<PublicSmtpStatus> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/email/config', {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
  });
  const data = await handleJsonResponse<PublicSmtpStatus>(res);
  cachedServerSmtpActive = Boolean(data.enabled && data.connectionVerified);
  return data;
}

export async function testSmtpConnection(): Promise<{
  verified: boolean;
  status: PublicSmtpStatus;
}> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/email/test', {
    method: 'POST',
    headers,
  });
  const data = await handleJsonResponse<{ verified: boolean; status: PublicSmtpStatus }>(res);
  cachedServerSmtpActive = Boolean(data.status.enabled && data.status.connectionVerified);
  return data;
}

export async function toggleSmtpEnabled(enabled: boolean): Promise<PublicSmtpStatus> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/email/toggle', {
    method: 'POST',
    headers,
    body: JSON.stringify({ enabled }),
  });
  const data = await handleJsonResponse<PublicSmtpStatus>(res);
  cachedServerSmtpActive = Boolean(data.enabled && data.connectionVerified);
  return data;
}

export async function clearSmtpConfig(): Promise<PublicSmtpStatus> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/email/clear', {
    method: 'POST',
    headers,
  });
  const data = await handleJsonResponse<PublicSmtpStatus>(res);
  cachedServerSmtpActive = false;
  return data;
}

export async function sendGmailMessage(payload: {
  to: string;
  subject: string;
  bodyText: string;
  senderDisplayName?: string;
  invoicePayload?: Record<string, unknown>;
}): Promise<{
  sent: boolean;
  messageId: string;
  fromEmail?: string;
  transport?: 'smtp' | 'gmail_api';
}> {
  const gmailToken = getCachedGmailAccessToken();
  if (!gmailToken && !cachedServerSmtpActive) {
    throw new Error(
      'No active email sender. Enable Verified SMTP Relay or connect your Google Account in Email & Gmail Integration.'
    );
  }
  const extraHeaders: Record<string, string> = gmailToken
    ? { Authorization: `Bearer ${gmailToken}` }
    : {};
  const headers = await getAdminHeaders(extraHeaders);
  const res = await fetch('/api/admin/gmail/send', {
    method: 'POST',
    headers,
    body: JSON.stringify({
      ...payload,
      senderEmail: auth.currentUser?.email || '',
      senderGoogleName: auth.currentUser?.displayName || '',
    }),
  });
  return handleJsonResponse(res);
}

export async function fetchPendingWebhooks(): Promise<{
  events: Array<{
    externalEventId: string;
    provider: string;
    eventType: string;
    paymentRequestId?: string;
    sessionId?: string;
    amountPaid?: number;
    currency?: string;
    transactionReference?: string;
    summary: string;
    receivedAt: string;
  }>;
}> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/webhooks/pending', { headers });
  return handleJsonResponse(res);
}

export async function ackWebhookEvent(externalEventId: string): Promise<void> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/webhooks/ack', {
    method: 'POST',
    headers,
    body: JSON.stringify({ externalEventId }),
  });
  await handleJsonResponse(res);
}

export async function fetchServerLogs(): Promise<{
  logs: Array<{
    id: string;
    source: string;
    message: string;
    details?: string;
    timestamp: string;
  }>;
  cron: {
    timezone: string;
    schedule: string;
    lastRunAt: string | null;
  };
}> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/logs', { headers });
  return handleJsonResponse(res);
}

export async function updateServerCronTimezone(timezone: string): Promise<void> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/cron/config', {
    method: 'POST',
    headers,
    body: JSON.stringify({ timezone }),
  });
  await handleJsonResponse(res);
}

export type IntegrationApiScope =
  | 'clients:read'
  | 'clients:write'
  | 'payments:read'
  | 'payments:write'
  | 'subscriptions:read'
  | 'subscriptions:write'
  | 'invoices:read'
  | 'services:read';

export interface IntegrationApiKeyRecord {
  id: string;
  name: string;
  keyPrefix: string;
  scopes: IntegrationApiScope[];
  active: boolean;
  createdAt: string;
  lastUsedAt: string | null;
  requestCount: number;
}

export interface ApiActivityEntry {
  id: string;
  keyId: string;
  keyName: string;
  method: string;
  path: string;
  statusCode: number;
  timestamp: string;
}

export async function fetchApiKeys(): Promise<{
  keys: IntegrationApiKeyRecord[];
  activity: ApiActivityEntry[];
  availableScopes: IntegrationApiScope[];
}> {
  const res = await apiFetch('/api/admin/api-keys');
  return handleJsonResponse(res);
}

export async function createIntegrationApiKey(payload: {
  name: string;
  scopes: IntegrationApiScope[];
}): Promise<{ key: IntegrationApiKeyRecord; plaintextKey: string }> {
  const res = await apiFetch('/api/admin/api-keys', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  return handleJsonResponse(res);
}

export async function toggleIntegrationApiKey(
  id: string,
  active: boolean
): Promise<{ key: IntegrationApiKeyRecord }> {
  const res = await apiFetch(`/api/admin/api-keys/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    body: JSON.stringify({ active }),
  });
  return handleJsonResponse(res);
}

export async function deleteIntegrationApiKey(id: string): Promise<void> {
  const res = await apiFetch(`/api/admin/api-keys/${encodeURIComponent(id)}`, {
    method: 'DELETE',
  });
  await handleJsonResponse(res);
}

export async function syncCloudSnapshotToLocalStore(
  collections: Partial<Record<keyof LocalStorePayload, Array<Record<string, unknown>>>>,
  allowEmptyCollections: Array<keyof LocalStorePayload> = []
): Promise<{ ok: boolean; clientsCount: number }> {
  const res = await apiFetch('/api/store/sync-cloud', {
    method: 'POST',
    body: JSON.stringify({ collections, allowEmptyCollections }),
  });
  return handleJsonResponse(res);
}

// --- 24-Hour Gmail Security Verification Code ---
const SECURITY_TOKEN_STORAGE_KEY = 'freska_security_tokens_v1';

export function getStoredSecurityToken(email: string): string {
  if (typeof window === 'undefined' || !email) return '';
  try {
    const raw = window.localStorage.getItem(SECURITY_TOKEN_STORAGE_KEY);
    if (!raw) return '';
    const map = JSON.parse(raw) as Record<string, string>;
    return map[email.trim().toLowerCase()] || '';
  } catch {
    return '';
  }
}

export function setStoredSecurityToken(email: string, token: string): void {
  if (typeof window === 'undefined' || !email) return;
  try {
    const raw = window.localStorage.getItem(SECURITY_TOKEN_STORAGE_KEY);
    const map = raw ? (JSON.parse(raw) as Record<string, string>) : {};
    const key = email.trim().toLowerCase();
    if (token) {
      map[key] = token;
    } else {
      delete map[key];
    }
    window.localStorage.setItem(SECURITY_TOKEN_STORAGE_KEY, JSON.stringify(map));
  } catch {
    // Ignore storage error
  }
}

export interface SecurityStatusResponse {
  unlocked: boolean;
  require24hOtp: boolean;
  email: string;
  maskedEmail: string;
  verifiedAt: string | null;
  expiresAt: string | null;
  remainingSeconds: number;
  hasActiveChallenge: boolean;
  challengeCooldownSeconds: number;
}

export interface SendSecurityCodeResponse {
  sent: boolean;
  requiresGmailAuth?: boolean;
  reusedActiveChallenge?: boolean;
  cooldownSeconds?: number;
  expiresInSeconds?: number;
  maskedEmail: string;
  deliveryMethod?: 'smtp' | 'gmail_api';
  message?: string;
}

export async function fetchSecurityStatus(email: string): Promise<SecurityStatusResponse> {
  const token = getStoredSecurityToken(email);
  const headers = await getAdminHeaders(token ? { 'X-Freska-Security-Token': token } : undefined);
  const res = await fetch(
    `/api/admin/security/status?email=${encodeURIComponent(email)}`,
    { headers }
  );
  return handleJsonResponse<SecurityStatusResponse>(res);
}

export async function sendSecurityCode(email: string): Promise<SendSecurityCodeResponse> {
  const gmailToken = getCachedGmailAccessToken();
  const extra: Record<string, string> = gmailToken
    ? { Authorization: `Bearer ${gmailToken}` }
    : {};
  const headers = await getAdminHeaders(extra);
  const res = await fetch('/api/admin/security/send-code', {
    method: 'POST',
    headers,
    body: JSON.stringify({
      email,
      senderGoogleName: auth.currentUser?.displayName || '',
    }),
  });
  return handleJsonResponse<SendSecurityCodeResponse>(res);
}

export async function verifySecurityCode(
  email: string,
  code: string
): Promise<{
  verified: boolean;
  securityToken: string;
  status: SecurityStatusResponse;
}> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/security/verify-code', {
    method: 'POST',
    headers,
    body: JSON.stringify({ email, code }),
  });
  return handleJsonResponse(res);
}

export async function lockSecuritySession(email: string): Promise<void> {
  const token = getStoredSecurityToken(email);
  const headers = await getAdminHeaders(token ? { 'X-Freska-Security-Token': token } : undefined);
  await fetch('/api/admin/security/lock', {
    method: 'POST',
    headers,
    body: JSON.stringify({ email }),
  });
  setStoredSecurityToken(email, '');
}

export async function updateSecuritySettings(require24hOtp: boolean): Promise<{
  require24hOtp: boolean;
}> {
  const headers = await getAdminHeaders();
  const res = await fetch('/api/admin/security/settings', {
    method: 'POST',
    headers,
    body: JSON.stringify({ require24hOtp }),
  });
  return handleJsonResponse(res);
}

