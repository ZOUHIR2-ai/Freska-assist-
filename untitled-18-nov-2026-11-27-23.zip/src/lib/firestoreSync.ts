import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  serverTimestamp,
  Timestamp,
} from 'firebase/firestore';
import {
  auth,
  db,
  hasVerifiedGoogleAccount,
  isFirestorePrimaryAdmin,
  handleFirestoreError,
  OperationType,
} from './firebase.ts';
import { fetchLocalStore, LocalStorePayload, putStoreDocument } from './api.ts';

export type SyncCollectionName = keyof LocalStorePayload;

interface CollectionSchemaSpec {
  allowedKeys: string[];
  hasCreatedAt: boolean;
  hasUpdatedAt: boolean;
  updateAllowed: boolean;
  deleteAllowed: boolean;
}

const COLLECTION_SPECS: Record<SyncCollectionName, CollectionSchemaSpec> = {
  clients: {
    allowedKeys: [
      'id',
      'clientCode',
      'fullName',
      'businessName',
      'email',
      'phone',
      'businessType',
      'servicesPurchased',
      'notes',
      'status',
      'preferredCurrency',
      'preferredPaymentMethod',
    ],
    hasCreatedAt: true,
    hasUpdatedAt: true,
    updateAllowed: true,
    deleteAllowed: true,
  },
  services: {
    allowedKeys: [
      'id',
      'name',
      'description',
      'billingType',
      'defaultPrice',
      'currency',
      'active',
    ],
    hasCreatedAt: true,
    hasUpdatedAt: true,
    updateAllowed: true,
    deleteAllowed: true,
  },
  subscriptions: {
    allowedKeys: [
      'id',
      'clientId',
      'serviceId',
      'name',
      'description',
      'monthlyPrice',
      'currency',
      'startDate',
      'lastPaymentDate',
      'nextPaymentDate',
      'billingFrequency',
      'paymentMethod',
      'status',
      'reminderEnabled',
      'autoRenew',
    ],
    hasCreatedAt: true,
    hasUpdatedAt: true,
    updateAllowed: true,
    deleteAllowed: true,
  },
  payments: {
    allowedKeys: [
      'id',
      'paymentCode',
      'clientId',
      'subscriptionId',
      'paymentRequestId',
      'invoiceId',
      'invoiceNumber',
      'serviceName',
      'description',
      'billingType',
      'paymentMethod',
      'amount',
      'currency',
      'paymentDate',
      'confirmedAt',
      'transactionReference',
      'manuallyVerified',
      'notes',
      'status',
    ],
    hasCreatedAt: true,
    hasUpdatedAt: true,
    updateAllowed: true,
    deleteAllowed: true,
  },
  payment_requests: {
    allowedKeys: [
      'id',
      'clientId',
      'subscriptionId',
      'serviceId',
      'serviceName',
      'description',
      'billingType',
      'paymentMethod',
      'reference',
      'amount',
      'currency',
      'dueDate',
      'paymentUrl',
      'gatewaySessionId',
      'status',
      'paidAt',
      'paymentId',
    ],
    hasCreatedAt: true,
    hasUpdatedAt: true,
    updateAllowed: true,
    deleteAllowed: true,
  },
  invoices: {
    allowedKeys: [
      'id',
      'invoiceNumber',
      'clientId',
      'clientName',
      'businessName',
      'clientEmail',
      'paymentId',
      'paymentRequestId',
      'subscriptionId',
      'serviceName',
      'serviceDescription',
      'paymentType',
      'paymentMethod',
      'amount',
      'currency',
      'invoiceDate',
      'paymentDate',
      'paymentReference',
      'status',
      'downloadToken',
      'sentViaGmail',
      'sentAt',
    ],
    hasCreatedAt: true,
    hasUpdatedAt: true,
    updateAllowed: true,
    deleteAllowed: false,
  },
  invoice_items: {
    allowedKeys: ['id', 'invoiceId', 'description', 'quantity', 'unitPrice', 'total'],
    hasCreatedAt: true,
    hasUpdatedAt: false,
    updateAllowed: false,
    deleteAllowed: false,
  },
  reminder_settings: {
    allowedKeys: [
      'id',
      'clientId',
      'enabled',
      'daysBeforeDue',
      'sendOnDueDate',
      'daysAfterDueFirst',
      'daysAfterDueSecond',
      'customOffsets',
    ],
    hasCreatedAt: false,
    hasUpdatedAt: true,
    updateAllowed: true,
    deleteAllowed: true,
  },
  reminder_logs: {
    allowedKeys: [
      'id',
      'clientId',
      'subscriptionId',
      'billingCycleDate',
      'stage',
      'emailLogId',
      'status',
      'errorMessage',
      'scheduledFor',
      'sentAt',
    ],
    hasCreatedAt: true,
    hasUpdatedAt: false,
    updateAllowed: true,
    deleteAllowed: false,
  },
  email_logs: {
    allowedKeys: [
      'id',
      'clientId',
      'recipient',
      'subject',
      'emailType',
      'gmailMessageId',
      'status',
      'errorMessage',
      'sentAt',
    ],
    hasCreatedAt: true,
    hasUpdatedAt: false,
    updateAllowed: false,
    deleteAllowed: false,
  },
  email_templates: {
    allowedKeys: ['id', 'templateKey', 'label', 'senderDisplayName', 'subject', 'body'],
    hasCreatedAt: false,
    hasUpdatedAt: true,
    updateAllowed: true,
    deleteAllowed: true,
  },
  payment_gateway_settings: {
    allowedKeys: [
      'id',
      'provider',
      'environment',
      'cardEnabled',
      'credentialsConfigured',
      'connectionVerified',
      'bankAccountName',
      'bankName',
      'bankIban',
      'bankBic',
      'bankInstructions',
    ],
    hasCreatedAt: false,
    hasUpdatedAt: true,
    updateAllowed: true,
    deleteAllowed: false,
  },
  webhook_events: {
    allowedKeys: ['id', 'provider', 'eventType', 'externalEventId', 'status', 'summary', 'receivedAt'],
    hasCreatedAt: true,
    hasUpdatedAt: false,
    updateAllowed: false,
    deleteAllowed: false,
  },
  system_settings: {
    allowedKeys: [
      'id',
      'businessName',
      'adminEmail',
      'timezone',
      'defaultCurrency',
      'invoicePrefix',
      'companyAddress',
      'taxId',
    ],
    hasCreatedAt: false,
    hasUpdatedAt: true,
    updateAllowed: true,
    deleteAllowed: false,
  },
};

export const DEPENDENCY_ORDERED_COLLECTIONS: SyncCollectionName[] = [
  'clients',
  'services',
  'subscriptions',
  'payments',
  'payment_requests',
  'invoices',
  'invoice_items',
  'reminder_settings',
  'reminder_logs',
  'email_logs',
  'email_templates',
  'payment_gateway_settings',
  'webhook_events',
  'system_settings',
];

function buildSanitizedPayload(
  collectionName: SyncCollectionName,
  docId: string,
  raw: Record<string, unknown>,
  mode: 'create' | 'update'
): Record<string, unknown> {
  const spec = COLLECTION_SPECS[collectionName];
  const allowed = new Set(spec.allowedKeys);
  const out: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(raw)) {
    if (!allowed.has(key)) continue;
    if (value === undefined || value === null) continue;
    out[key] = value;
  }

  if (mode === 'create') {
    out.id = docId;
    if (collectionName === 'clients') {
      if (!out.businessName && typeof out.fullName === 'string') {
        out.businessName = out.fullName;
      }
      if (!out.status) out.status = 'active';
      if (!out.clientCode) out.clientCode = `CL-${docId.slice(-4).toUpperCase()}`;
    }
    if (spec.hasCreatedAt) {
      out.createdAt = serverTimestamp();
    }
    if (spec.hasUpdatedAt) {
      out.updatedAt = serverTimestamp();
    }
  } else {
    if (spec.hasUpdatedAt) {
      out.updatedAt = serverTimestamp();
    }
  }

  return out;
}

export function normalizeFirestoreDoc<T extends Record<string, unknown>>(data: T): T {
  const out: Record<string, unknown> = { ...data };
  for (const key of ['createdAt', 'updatedAt']) {
    const val = out[key];
    if (val instanceof Timestamp) {
      out[key] = val.toDate().toISOString();
    } else if (
      val &&
      typeof val === 'object' &&
      'toDate' in val &&
      typeof (val as { toDate: () => Date }).toDate === 'function'
    ) {
      out[key] = (val as { toDate: () => Date }).toDate().toISOString();
    }
  }
  return out as T;
}

export function userCollectionRef(uid: string, collectionName: SyncCollectionName) {
  return collection(db, 'users', uid, collectionName);
}

export function userDocRef(uid: string, collectionName: SyncCollectionName, docId: string) {
  return doc(db, 'users', uid, collectionName, docId);
}

export async function writeDocToFirestore(
  collectionName: SyncCollectionName,
  docId: string,
  data: Record<string, unknown>,
  options?: { isNew?: boolean }
): Promise<boolean> {
  const currentUser = auth.currentUser;
  if (!hasVerifiedGoogleAccount(currentUser) || !currentUser) {
    return false;
  }

  const spec = COLLECTION_SPECS[collectionName];
  if (!spec) return false;

  const uid = currentUser.uid;
  const docRef = userDocRef(uid, collectionName, docId);
  const path = `users/${uid}/${collectionName}/${docId}`;

  try {
    const existingSnap = await getDoc(docRef);
    if (existingSnap.exists()) {
      if (!spec.updateAllowed) {
        return true;
      }
      const updatePayload = buildSanitizedPayload(collectionName, docId, data, 'update');
      await setDoc(docRef, updatePayload, { merge: true });
      return true;
    }

    // Document does not exist in Firestore yet — assemble complete create payload
    let fullData = data;
    if (!options?.isNew) {
      try {
        const store = await fetchLocalStore();
        const rows = (store[collectionName] as unknown as Array<Record<string, unknown>>) || [];
        const localRecord = rows.find((r) => r.id === docId);
        if (localRecord) {
          fullData = { ...localRecord, ...data };
        }
      } catch {
        // Fallback to provided data
      }
    }

    const createPayload = buildSanitizedPayload(collectionName, docId, fullData, 'create');
    await setDoc(docRef, createPayload);
    return true;
  } catch (err) {
    handleFirestoreError(err, options?.isNew ? OperationType.CREATE : OperationType.UPDATE, path);
  }
}

export async function deleteDocFromFirestore(
  collectionName: SyncCollectionName,
  docId: string
): Promise<boolean> {
  const currentUser = auth.currentUser;
  if (!hasVerifiedGoogleAccount(currentUser) || !currentUser) {
    return false;
  }
  const spec = COLLECTION_SPECS[collectionName];
  if (!spec?.deleteAllowed) return false;

  const uid = currentUser.uid;
  const path = `users/${uid}/${collectionName}/${docId}`;
  try {
    await deleteDoc(userDocRef(uid, collectionName, docId));
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function syncUnsyncedLocalDocsToFirestore(): Promise<{
  pushed: number;
  failed: number;
}> {
  const currentUser = auth.currentUser;
  if (!hasVerifiedGoogleAccount(currentUser) || !currentUser) {
    return { pushed: 0, failed: 0 };
  }

  const uid = currentUser.uid;
  let pushed = 0;
  let failed = 0;
  const store = await fetchLocalStore();

  for (const colName of DEPENDENCY_ORDERED_COLLECTIONS) {
    const spec = COLLECTION_SPECS[colName];
    const docs = (store[colName] as unknown as Array<Record<string, unknown>>) || [];

    for (const item of docs) {
      const docId = typeof item.id === 'string' ? item.id : '';
      if (!docId) continue;
      if (item._cloudSynced === true) continue;

      const docRef = userDocRef(uid, colName, docId);
      try {
        const snap = await getDoc(docRef);
        if (snap.exists()) {
          if (spec.updateAllowed) {
            const updatePayload = buildSanitizedPayload(colName, docId, item, 'update');
            await setDoc(docRef, updatePayload, { merge: true });
          }
        } else {
          const createPayload = buildSanitizedPayload(colName, docId, item, 'create');
          await setDoc(docRef, createPayload);
        }

        await putStoreDocument(colName, docId, {
          ...item,
          _cloudSynced: true,
        });
        pushed += 1;
      } catch (err) {
        failed += 1;
        console.warn(`Cloud sync skipped for users/${uid}/${colName}/${docId}:`, err);
      }
    }
  }

  return { pushed, failed };
}

export async function hydrateUserWorkspaceFromFirestore(uid: string): Promise<{
  collections: Partial<Record<SyncCollectionName, Array<Record<string, unknown>>>>;
  confirmedServerCollections: SyncCollectionName[];
  totalDocs: number;
}> {
  const currentUser = auth.currentUser;
  if (!hasVerifiedGoogleAccount(currentUser) || !currentUser || currentUser.uid !== uid) {
    return { collections: {}, confirmedServerCollections: [], totalDocs: 0 };
  }

  const collections: Partial<Record<SyncCollectionName, Array<Record<string, unknown>>>> = {};
  const confirmedServerCollections: SyncCollectionName[] = [];
  let totalDocs = 0;

  await Promise.all(
    DEPENDENCY_ORDERED_COLLECTIONS.map(async (colName) => {
      try {
        const snap = await getDocs(userCollectionRef(uid, colName));
        if (snap.metadata.fromCache && snap.empty) {
          return;
        }
        const rows = snap.docs.map((d) =>
          normalizeFirestoreDoc(d.data() as Record<string, unknown>)
        );
        collections[colName] = rows;
        totalDocs += rows.length;
        if (!snap.metadata.fromCache) {
          confirmedServerCollections.push(colName);
        }
      } catch (err) {
        console.warn(`Firestore hydration warning for users/${uid}/${colName}:`, err);
      }
    })
  );

  return { collections, confirmedServerCollections, totalDocs };
}

export async function migrateLegacyRootCollectionsToUserWorkspace(uid: string): Promise<number> {
  const currentUser = auth.currentUser;
  if (!currentUser || currentUser.uid !== uid || !isFirestorePrimaryAdmin(currentUser)) {
    return 0;
  }

  const migrationKey = `freska_legacy_migrated_v2_${uid}`;
  if (typeof window !== 'undefined' && window.localStorage.getItem(migrationKey) === '1') {
    return 0;
  }

  let migratedCount = 0;
  let hadCollectionError = false;
  try {
    for (const colName of DEPENDENCY_ORDERED_COLLECTIONS) {
      try {
        const [legacySnap, existingUserSnap] = await Promise.all([
          getDocs(collection(db, colName)),
          getDocs(userCollectionRef(uid, colName)),
        ]);

        if (legacySnap.empty) continue;

        const existingIds = new Set(existingUserSnap.docs.map((d) => d.id));
        const missingDocs = legacySnap.docs.filter((d) => !existingIds.has(d.id));
        if (missingDocs.length === 0) continue;

        await Promise.all(
          missingDocs.map(async (legacyDoc) => {
            const docId = legacyDoc.id;
            const targetRef = userDocRef(uid, colName, docId);
            const normalized = normalizeFirestoreDoc(legacyDoc.data() as Record<string, unknown>);
            const payload = buildSanitizedPayload(colName, docId, normalized, 'create');
            await setDoc(targetRef, payload);
            migratedCount += 1;
          })
        );
      } catch {
        // Legacy collection may be empty or absent, or network hiccup
        hadCollectionError = true;
      }
    }

    if (!hadCollectionError && typeof window !== 'undefined') {
      window.localStorage.setItem(migrationKey, '1');
    }
  } catch (err) {
    console.warn('Legacy root collection migration skipped:', err);
  }

  return migratedCount;
}
