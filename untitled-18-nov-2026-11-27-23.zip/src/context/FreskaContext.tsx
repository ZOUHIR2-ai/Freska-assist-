import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import { User } from 'firebase/auth';
import {
  doc,
  onSnapshot,
  setDoc,
  serverTimestamp,
  getDoc,
} from 'firebase/firestore';
import {
  auth,
  db,
  subscribeToAuth,
  connectGoogleAccount,
  startGoogleRedirectSignIn,
  resolveGoogleRedirectResult,
  switchGoogleAccount as switchGooglePopup,
  signOutAdmin,
  getCachedGmailAccessToken,
  hasVerifiedGoogleAccount,
  formatGoogleAuthError,
  testFirestoreConnection,
} from '../lib/firebase.ts';
import { DEFAULT_EMAIL_TEMPLATES } from '../lib/templates.ts';
import {
  fetchLocalStore,
  fetchGatewayStatus,
  fetchSmtpStatus,
  PublicSmtpStatus,
  fetchPendingWebhooks,
  ackWebhookEvent,
  checkCheckoutSessionStatus,
  updateServerCronTimezone,
  syncCloudSnapshotToLocalStore,
  fetchSecurityStatus,
  sendSecurityCode,
  verifySecurityCode,
  lockSecuritySession,
  updateSecuritySettings,
  setStoredSecurityToken,
  SecurityStatusResponse,
} from '../lib/api.ts';
import {
  saveEntity,
  registerStoreSyncCallback,
} from '../lib/storeClient.ts';
import {
  hydrateUserWorkspaceFromFirestore,
  migrateLegacyRootCollectionsToUserWorkspace,
  normalizeFirestoreDoc,
  syncUnsyncedLocalDocsToFirestore,
  SyncCollectionName,
  userCollectionRef,
  userDocRef,
} from '../lib/firestoreSync.ts';
import {
  handleFirestoreError,
  OperationType,
} from '../lib/firebase.ts';
import {
  confirmPaymentAndGenerateInvoice,
  DEFAULT_SERVICE_PACKAGES,
  evaluateAndDispatchReminders,
} from '../lib/billingEngine.ts';
import type {
  ClientRecord,
  EmailLogRecord,
  EmailTemplateRecord,
  InvoiceItemRecord,
  InvoiceRecord,
  NavSection,
  PaymentGatewaySettingRecord,
  PaymentRecord,
  PaymentRequestRecord,
  PublicGatewayStatus,
  ReminderLogRecord,
  ReminderSettingRecord,
  ServiceRecord,
  SubscriptionRecord,
  SystemSettingRecord,
  WebhookEventRecord,
} from '../types/freska.ts';

const DEFAULT_SYSTEM_SETTINGS: SystemSettingRecord = {
  id: 'default',
  businessName: 'FreskaAssist',
  adminEmail: '',
  timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
  defaultCurrency: 'EUR',
  invoicePrefix: 'FA',
  companyAddress: '',
  taxId: '',
};

const DEFAULT_GATEWAY_DB_SETTINGS: PaymentGatewaySettingRecord = {
  id: 'default',
  provider: 'stripe',
  environment: 'test',
  cardEnabled: false,
  credentialsConfigured: false,
  connectionVerified: false,
  bankAccountName: '',
  bankName: '',
  bankIban: '',
  bankBic: '',
  bankInstructions:
    'Please include your Payment Reference in the transfer memo so we can verify your payment promptly.',
};

export interface ToastNotice {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface FreskaContextValue {
  user: User | null;
  authLoading: boolean;
  authError: string | null;
  googleConnecting: boolean;
  googleProfileConnected: boolean;
  gmailConnected: boolean;
  gmailEmail: string | null;
  smtpStatus: PublicSmtpStatus | null;
  emailDeliveryActive: boolean;
  activeSection: NavSection;
  selectedClientId: string | null;
  setActiveSection: (section: NavSection) => void;
  openClientProfile: (clientId: string) => void;
  connectGoogle: (options?: {
    includeGmail?: boolean;
    forceAccountSelect?: boolean;
    forceConsent?: boolean;
  }) => Promise<void>;
  connectGoogleWithRedirect: (includeGmail?: boolean) => Promise<void>;
  switchGoogleAccount: (includeGmail?: boolean) => Promise<void>;
  disconnectGoogle: () => Promise<void>;
  signIn: () => Promise<void>;
  reconnectGmail: () => Promise<void>;
  logout: () => Promise<void>;

  // Domain Collections
  clients: ClientRecord[];
  services: ServiceRecord[];
  subscriptions: SubscriptionRecord[];
  payments: PaymentRecord[];
  paymentRequests: PaymentRequestRecord[];
  invoices: InvoiceRecord[];
  invoiceItems: InvoiceItemRecord[];
  reminderSettings: ReminderSettingRecord[];
  reminderLogs: ReminderLogRecord[];
  emailLogs: EmailLogRecord[];
  emailTemplates: EmailTemplateRecord[];
  gatewayDbSettings: PaymentGatewaySettingRecord;
  gatewayServerStatus: PublicGatewayStatus | null;
  webhookEvents: WebhookEventRecord[];
  systemSettings: SystemSettingRecord;
  dataLoading: boolean;

  refreshStore: () => Promise<void>;
  refreshGatewayStatus: () => Promise<void>;
  refreshSmtpStatus: () => Promise<void>;
  cloudSyncStatus: 'synced' | 'syncing' | 'local_only';
  lastCloudSyncAt: string | null;
  syncToCloudNow: () => Promise<void>;
  toasts: ToastNotice[];
  notify: (type: ToastNotice['type'], message: string) => void;
  dismissToast: (id: string) => void;

  // 24-Hour Gmail Security Verification Code
  securityState: 'checking' | 'locked_no_google' | 'locked_otp_required' | 'unlocked';
  securityStatus: SecurityStatusResponse | null;
  securityLoading: boolean;
  securityCodeSending: boolean;
  securityVerifying: boolean;
  securityCodeSent: boolean;
  securityRequiresGmailAuth: boolean;
  securityDeliveryMethod: 'smtp' | 'gmail_api' | null;
  securityMaskedEmail: string;
  securityError: string | null;
  securityCooldownSeconds: number;
  checkSecurityStatus: () => Promise<void>;
  requestSecurityCode: () => Promise<void>;
  submitSecurityCode: (code: string) => Promise<boolean>;
  lockPlatformNow: () => Promise<void>;
  toggleRequire24hOtp: (enabled: boolean) => Promise<void>;
}

const FreskaContext = createContext<FreskaContextValue | null>(null);

export const FreskaProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [googleConnecting, setGoogleConnecting] = useState(false);
  const [gmailConnected, setGmailConnected] = useState(false);

  const [activeSection, setActiveSection] = useState<NavSection>('overview');
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);

  const [clients, setClients] = useState<ClientRecord[]>([]);
  const [services, setServices] = useState<ServiceRecord[]>([]);
  const [subscriptions, setSubscriptions] = useState<SubscriptionRecord[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [paymentRequests, setPaymentRequests] = useState<PaymentRequestRecord[]>([]);
  const [invoices, setInvoices] = useState<InvoiceRecord[]>([]);
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItemRecord[]>([]);
  const [reminderSettings, setReminderSettings] = useState<ReminderSettingRecord[]>([]);
  const [reminderLogs, setReminderLogs] = useState<ReminderLogRecord[]>([]);
  const [emailLogs, setEmailLogs] = useState<EmailLogRecord[]>([]);
  const [emailTemplates, setEmailTemplates] = useState<EmailTemplateRecord[]>([]);
  const [gatewayDbSettings, setGatewayDbSettings] = useState<PaymentGatewaySettingRecord>(
    DEFAULT_GATEWAY_DB_SETTINGS
  );
  const [gatewayServerStatus, setGatewayServerStatus] = useState<PublicGatewayStatus | null>(null);
  const [smtpStatus, setSmtpStatus] = useState<PublicSmtpStatus | null>(null);
  const [webhookEvents, setWebhookEvents] = useState<WebhookEventRecord[]>([]);
  const [systemSettings, setSystemSettings] = useState<SystemSettingRecord>(DEFAULT_SYSTEM_SETTINGS);
  const [dataLoading, setDataLoading] = useState(true);
  const [cloudSyncStatus, setCloudSyncStatus] = useState<'synced' | 'syncing' | 'local_only'>(
    'local_only'
  );
  const [lastCloudSyncAt, setLastCloudSyncAt] = useState<string | null>(null);
  const [cloudBootstrappedUid, setCloudBootstrappedUid] = useState<string | null>(null);

  const seededRef = useRef(false);
  const packagesSeededRef = useRef(false);
  const userRef = useRef<User | null>(null);
  const lastAuthUidRef = useRef<string | null>(null);
  const [toasts, setToasts] = useState<ToastNotice[]>([]);

  const [securityLoading, setSecurityLoading] = useState(true);
  const [securityStatus, setSecurityStatus] = useState<SecurityStatusResponse | null>(null);
  const [securityCodeSending, setSecurityCodeSending] = useState(false);
  const [securityVerifying, setSecurityVerifying] = useState(false);
  const [securityCodeSent, setSecurityCodeSent] = useState(false);
  const [securityRequiresGmailAuth, setSecurityRequiresGmailAuth] = useState(false);
  const [securityDeliveryMethod, setSecurityDeliveryMethod] = useState<'smtp' | 'gmail_api' | null>(
    null
  );
  const [securityMaskedEmail, setSecurityMaskedEmail] = useState('');
  const [securityError, setSecurityError] = useState<string | null>(null);
  const [securityCooldownSeconds, setSecurityCooldownSeconds] = useState(0);
  const autoOtpAttemptedKeyRef = useRef('');
  const autoSentGuardRef = useRef<Set<string>>(new Set());

  const clearWorkspaceState = useCallback(() => {
    setClients([]);
    setServices([]);
    setSubscriptions([]);
    setPayments([]);
    setPaymentRequests([]);
    setInvoices([]);
    setInvoiceItems([]);
    setReminderSettings([]);
    setReminderLogs([]);
    setEmailLogs([]);
    setEmailTemplates([]);
    setWebhookEvents([]);
    setSelectedClientId(null);
    setGatewayDbSettings(DEFAULT_GATEWAY_DB_SETTINGS);
    setSystemSettings(DEFAULT_SYSTEM_SETTINGS);
    setCloudBootstrappedUid(null);
    setCloudSyncStatus('local_only');
    setLastCloudSyncAt(null);
    seededRef.current = false;
    packagesSeededRef.current = false;
    autoSentGuardRef.current.clear();
    setActiveSection((prev) => (prev === 'client_profile' ? 'overview' : prev));
  }, []);

  const notify = useCallback((type: ToastNotice['type'], message: string) => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 5500);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const openClientProfile = useCallback((clientId: string) => {
    setSelectedClientId(clientId);
    setActiveSection('client_profile');
  }, []);

  const refreshGatewayStatus = useCallback(async () => {
    try {
      const status = await fetchGatewayStatus();
      setGatewayServerStatus(status);
    } catch {
      // Ignore network hiccup
    }
  }, []);

  const refreshSmtpStatus = useCallback(async () => {
    try {
      const status = await fetchSmtpStatus();
      setSmtpStatus(status);
    } catch {
      // Ignore network hiccup
    }
  }, []);

  const emailDeliveryActive =
    gmailConnected || Boolean(smtpStatus?.enabled && smtpStatus?.connectionVerified);

  const refreshStore = useCallback(async () => {
    const activeUser = userRef.current;
    if (!activeUser || !auth.currentUser || auth.currentUser.uid !== activeUser.uid) {
      clearWorkspaceState();
      setDataLoading(false);
      return;
    }

    const isStillActiveSession = () =>
      Boolean(
        userRef.current &&
          userRef.current.uid === activeUser.uid &&
          auth.currentUser &&
          auth.currentUser.uid === activeUser.uid
      );

    try {
      const data = await fetchLocalStore();
      if (!isStillActiveSession()) {
        return;
      }

      setClients(data.clients || []);
      const loadedServices = data.services || [];
      const seedStorageKey = `freska_default_eur_packages_${activeUser.uid}_v1`;
      const hasSeedFlag =
        typeof window !== 'undefined' &&
        window.localStorage.getItem(seedStorageKey) === '1';

      if (!packagesSeededRef.current && (!hasSeedFlag || loadedServices.length === 0)) {
        packagesSeededRef.current = true;
        const existingIds = new Set(loadedServices.map((s) => s.id));
        const nextServices = [...loadedServices];
        for (const pkg of DEFAULT_SERVICE_PACKAGES) {
          if (!existingIds.has(pkg.id)) {
            if (!hasVerifiedGoogleAccount(activeUser) && isStillActiveSession()) {
              await saveEntity('services', pkg.id, { ...pkg }, { isNew: true, silent: true }).catch(
                () => {}
              );
            }
            nextServices.push({ ...pkg });
          }
        }
        if (typeof window !== 'undefined') {
          window.localStorage.setItem(seedStorageKey, '1');
        }
        setServices(nextServices);
      } else {
        setServices(loadedServices);
      }

      setSubscriptions(data.subscriptions || []);
      setPayments(data.payments || []);
      setPaymentRequests(data.payment_requests || []);
      setInvoices(data.invoices || []);
      setInvoiceItems(data.invoice_items || []);
      setReminderSettings(data.reminder_settings || []);
      setReminderLogs(data.reminder_logs || []);
      setEmailLogs(data.email_logs || []);

      if (data.email_templates && data.email_templates.length > 0) {
        const mergedTemplates = [...data.email_templates];
        for (const defTpl of DEFAULT_EMAIL_TEMPLATES) {
          const idx = mergedTemplates.findIndex((t) => t.id === defTpl.id);
          if (idx === -1) {
            if (!hasVerifiedGoogleAccount(activeUser) && isStillActiveSession()) {
              await saveEntity(
                'email_templates',
                defTpl.id,
                { ...defTpl },
                { isNew: true, silent: true }
              ).catch(() => {});
            }
            mergedTemplates.push({ ...defTpl });
          } else {
            const existing = mergedTemplates[idx];
            const needsPdfOnlyUpgrade =
              (defTpl.id === 'tpl_invoice_delivery' || defTpl.id === 'tpl_payment_confirmation') &&
              existing.body.includes('{{invoice_link}}');
            const needsSuspensionUpgrade =
              (defTpl.id === 'tpl_payment_due_today' &&
                (existing.body.includes('This is a friendly note that the billing cycle') ||
                  existing.subject.startsWith('Action required:'))) ||
              (defTpl.id === 'tpl_overdue_reminder' &&
                (existing.body.includes('Following up regarding {{service_name}} for {{business_name}}') ||
                  existing.body.includes('Following up regarding {{service_name}} invoice due') ||
                  existing.subject.startsWith('Urgent:')));

            if (needsPdfOnlyUpgrade || needsSuspensionUpgrade) {
              if (isStillActiveSession()) {
                await saveEntity('email_templates', defTpl.id, { ...defTpl }, { silent: true }).catch(
                  () => {}
                );
              }
              mergedTemplates[idx] = { ...defTpl };
            }
          }
        }
        setEmailTemplates(mergedTemplates);
      } else if (!seededRef.current) {
        seededRef.current = true;
        if (!hasVerifiedGoogleAccount(activeUser) && isStillActiveSession()) {
          for (const tpl of DEFAULT_EMAIL_TEMPLATES) {
            await saveEntity('email_templates', tpl.id, { ...tpl }, { isNew: true, silent: true }).catch(
              () => {}
            );
          }
        }
        setEmailTemplates(DEFAULT_EMAIL_TEMPLATES);
      }

      if (data.payment_gateway_settings && data.payment_gateway_settings.length > 0) {
        const foundGw =
          data.payment_gateway_settings.find((g) => g.id === 'default') ||
          data.payment_gateway_settings[0];
        setGatewayDbSettings(foundGw);
      } else {
        if (!hasVerifiedGoogleAccount(activeUser) && isStillActiveSession()) {
          await saveEntity(
            'payment_gateway_settings',
            'default',
            { ...DEFAULT_GATEWAY_DB_SETTINGS },
            { isNew: true, silent: true }
          ).catch(() => {});
        }
        setGatewayDbSettings(DEFAULT_GATEWAY_DB_SETTINGS);
      }

      if (data.system_settings && data.system_settings.length > 0) {
        const foundSys =
          data.system_settings.find((s) => s.id === 'default') || data.system_settings[0];
        setSystemSettings(foundSys);
        if (foundSys.timezone) {
          updateServerCronTimezone(foundSys.timezone).catch(() => {});
        }
      } else {
        if (!hasVerifiedGoogleAccount(activeUser) && isStillActiveSession()) {
          await saveEntity(
            'system_settings',
            'default',
            { ...DEFAULT_SYSTEM_SETTINGS, adminEmail: activeUser.email || '' },
            { isNew: true, silent: true }
          ).catch(() => {});
        }
        setSystemSettings({ ...DEFAULT_SYSTEM_SETTINGS, adminEmail: activeUser.email || '' });
      }

      setWebhookEvents(data.webhook_events || []);
    } catch (err) {
      if (isStillActiveSession()) {
        console.warn('Workspace store refresh warning:', err);
      }
    } finally {
      setDataLoading(false);
    }
  }, [clearWorkspaceState]);

  // Refresh gateway/SMTP status on startup and sync pending local/API records ONLY while connected
  useEffect(() => {
    refreshGatewayStatus();
    refreshSmtpStatus();
    const unsubSync = registerStoreSyncCallback(() => {
      if (userRef.current && !hasVerifiedGoogleAccount(userRef.current)) {
        refreshStore();
      }
    });

    const pollExternalOrLocal = async () => {
      const currentUser = userRef.current;
      if (!currentUser) return;
      if (hasVerifiedGoogleAccount(currentUser)) {
        try {
          const store = await fetchLocalStore();
          const hasPending = Object.values(store).some(
            (arr) =>
              Array.isArray(arr) &&
              arr.some((docItem) => (docItem as { _cloudSynced?: boolean })._cloudSynced !== true)
          );
          if (hasPending) {
            await syncUnsyncedLocalDocsToFirestore();
            setLastCloudSyncAt(new Date().toISOString());
          }
        } catch {
          // Non-fatal background check
        }
      } else {
        refreshStore();
      }
    };

    const storePollId = window.setInterval(pollExternalOrLocal, 10000);
    const onWindowFocus = () => {
      pollExternalOrLocal();
    };
    const onWindowOnline = () => {
      const currentUser = userRef.current;
      if (currentUser && hasVerifiedGoogleAccount(currentUser)) {
        testFirestoreConnection(currentUser.uid).then((connected) => {
          if (connected) {
            setCloudSyncStatus('synced');
            pollExternalOrLocal();
          }
        });
      }
    };
    window.addEventListener('focus', onWindowFocus);
    window.addEventListener('online', onWindowOnline);
    return () => {
      unsubSync();
      window.clearInterval(storePollId);
      window.removeEventListener('focus', onWindowFocus);
      window.removeEventListener('online', onWindowOnline);
    };
  }, [refreshStore, refreshGatewayStatus, refreshSmtpStatus]);

  const applyCloudCollections = useCallback(
    (
      collections: Partial<Record<SyncCollectionName, Array<Record<string, unknown>>>>,
      confirmedServerCols: SyncCollectionName[]
    ) => {
      const confirmedSet = new Set(confirmedServerCols);
      const canApply = (colName: SyncCollectionName, rows?: Array<Record<string, unknown>>) =>
        Array.isArray(rows) && (rows.length > 0 || confirmedSet.has(colName));

      if (canApply('clients', collections.clients)) {
        setClients(collections.clients as unknown as ClientRecord[]);
      }
      if (collections.services && collections.services.length > 0) {
        setServices(collections.services as unknown as ServiceRecord[]);
      }
      if (canApply('subscriptions', collections.subscriptions)) {
        setSubscriptions(collections.subscriptions as unknown as SubscriptionRecord[]);
      }
      if (canApply('payments', collections.payments)) {
        setPayments(collections.payments as unknown as PaymentRecord[]);
      }
      if (canApply('payment_requests', collections.payment_requests)) {
        setPaymentRequests(collections.payment_requests as unknown as PaymentRequestRecord[]);
      }
      if (canApply('invoices', collections.invoices)) {
        setInvoices(collections.invoices as unknown as InvoiceRecord[]);
      }
      if (canApply('invoice_items', collections.invoice_items)) {
        setInvoiceItems(collections.invoice_items as unknown as InvoiceItemRecord[]);
      }
      if (canApply('reminder_settings', collections.reminder_settings)) {
        setReminderSettings(collections.reminder_settings as unknown as ReminderSettingRecord[]);
      }
      if (canApply('reminder_logs', collections.reminder_logs)) {
        setReminderLogs(collections.reminder_logs as unknown as ReminderLogRecord[]);
      }
      if (canApply('email_logs', collections.email_logs)) {
        setEmailLogs(collections.email_logs as unknown as EmailLogRecord[]);
      }
      if (collections.email_templates && collections.email_templates.length > 0) {
        setEmailTemplates(collections.email_templates as unknown as EmailTemplateRecord[]);
      }
      if (collections.payment_gateway_settings && collections.payment_gateway_settings.length > 0) {
        const rows = collections.payment_gateway_settings as unknown as PaymentGatewaySettingRecord[];
        const found = rows.find((g) => g.id === 'default') || rows[0];
        if (found) setGatewayDbSettings(found);
      }
      if (canApply('webhook_events', collections.webhook_events)) {
        setWebhookEvents(collections.webhook_events as unknown as WebhookEventRecord[]);
      }
      if (collections.system_settings && collections.system_settings.length > 0) {
        const rows = collections.system_settings as unknown as SystemSettingRecord[];
        const found = rows.find((s) => s.id === 'default') || rows[0];
        if (found) {
          setSystemSettings(found);
          if (found.timezone) {
            updateServerCronTimezone(found.timezone).catch(() => {});
          }
        }
      }
    },
    []
  );

  const bootstrapFirestoreForUser = useCallback(
    async (firebaseUser: User) => {
      if (!hasVerifiedGoogleAccount(firebaseUser)) return;
      const uid = firebaseUser.uid;
      setCloudSyncStatus('syncing');
      try {
        const connected = await testFirestoreConnection(uid);
        if (!connected) {
          if (userRef.current?.uid === uid) {
            setCloudBootstrappedUid(null);
            setCloudSyncStatus('local_only');
          }
          return;
        }
        if (userRef.current?.uid !== uid) return;

        const userRootRef = doc(db, 'users', uid);
        const userRootSnap = await getDoc(userRootRef);
        if (!userRootSnap.exists()) {
          await setDoc(userRootRef, {
            uid,
            email: firebaseUser.email || '',
            displayName: firebaseUser.displayName || 'Google Account',
            role: 'admin',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }

        const migratedLegacy = await migrateLegacyRootCollectionsToUserWorkspace(uid);
        if (migratedLegacy > 0) {
          notify('success', `Restored ${migratedLegacy} record(s) into your Google Account.`);
        }

        const ensureSystemSettings = async () => {
          const sysRef = userDocRef(uid, 'system_settings', 'default');
          const sysSnap = await getDoc(sysRef);
          if (!sysSnap.exists()) {
            await setDoc(sysRef, {
              ...DEFAULT_SYSTEM_SETTINGS,
              adminEmail: firebaseUser.email || '',
              updatedAt: serverTimestamp(),
            });
          }
        };

        const ensureGatewaySettings = async () => {
          const gwRef = userDocRef(uid, 'payment_gateway_settings', 'default');
          const gwSnap = await getDoc(gwRef);
          if (!gwSnap.exists()) {
            await setDoc(gwRef, {
              ...DEFAULT_GATEWAY_DB_SETTINGS,
              updatedAt: serverTimestamp(),
            });
          }
        };

        await Promise.all([
          ensureSystemSettings(),
          ensureGatewaySettings(),
          ...DEFAULT_EMAIL_TEMPLATES.map(async (tpl) => {
            const tplRef = userDocRef(uid, 'email_templates', tpl.id);
            const tplSnap = await getDoc(tplRef);
            if (!tplSnap.exists()) {
              await setDoc(tplRef, {
                ...tpl,
                updatedAt: serverTimestamp(),
              });
            } else {
              const existingData = tplSnap.data() as Partial<EmailTemplateRecord>;
              const bodyStr = String(existingData.body || '');
              const subjectStr = String(existingData.subject || '');
              const needsPdfOnlyUpgrade =
                (tpl.id === 'tpl_invoice_delivery' || tpl.id === 'tpl_payment_confirmation') &&
                bodyStr.includes('{{invoice_link}}');
              const needsSuspensionUpgrade =
                (tpl.id === 'tpl_payment_due_today' &&
                  (bodyStr.includes('This is a friendly note that the billing cycle') ||
                    subjectStr.startsWith('Action required:'))) ||
                (tpl.id === 'tpl_overdue_reminder' &&
                  (bodyStr.includes('Following up regarding {{service_name}} for {{business_name}}') ||
                    bodyStr.includes('Following up regarding {{service_name}} invoice due') ||
                    subjectStr.startsWith('Urgent:')));
              if (needsPdfOnlyUpgrade || needsSuspensionUpgrade) {
                await setDoc(
                  tplRef,
                  {
                    ...tpl,
                    updatedAt: serverTimestamp(),
                  },
                  { merge: true }
                );
              }
            }
          }),
          ...DEFAULT_SERVICE_PACKAGES.map(async (pkg) => {
            const pkgRef = userDocRef(uid, 'services', pkg.id);
            const pkgSnap = await getDoc(pkgRef);
            if (!pkgSnap.exists()) {
              await setDoc(pkgRef, {
                ...pkg,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
              });
            }
          }),
        ]);

        // Push any locally created or /api/v1/-created records to this Google Account's Cloud Firestore
        const syncRes = await syncUnsyncedLocalDocsToFirestore();
        if (syncRes.pushed > 0) {
          notify('success', `Synced ${syncRes.pushed} local record(s) to your Google Account.`);
        }

        // Hydrate client state and local server cache immediately from Cloud Firestore
        const hydrated = await hydrateUserWorkspaceFromFirestore(uid);
        if (userRef.current?.uid !== uid) return;

        if (Object.keys(hydrated.collections).length > 0) {
          applyCloudCollections(hydrated.collections, hydrated.confirmedServerCollections);
          syncCloudSnapshotToLocalStore(
            hydrated.collections,
            hydrated.confirmedServerCollections
          ).catch(() => {});
        }

        setCloudBootstrappedUid(uid);
        setCloudSyncStatus('synced');
        setLastCloudSyncAt(new Date().toISOString());
        setDataLoading(false);
      } catch (err) {
        console.warn('Firestore bootstrap deferred (will retry when online):', err);
        if (userRef.current?.uid === uid) {
          setCloudBootstrappedUid(null);
          setCloudSyncStatus('local_only');
          setDataLoading(false);
        }
      }
    },
    [notify, applyCloudCollections]
  );

  useEffect(() => {
    if (!user || !hasVerifiedGoogleAccount(user) || cloudBootstrappedUid === user.uid) return;
    const handleOnline = () => {
      void bootstrapFirestoreForUser(user);
    };
    window.addEventListener('online', handleOnline);
    return () => window.removeEventListener('online', handleOnline);
  }, [user, cloudBootstrappedUid, bootstrapFirestoreForUser]);

  const syncToCloudNow = useCallback(async () => {
    const activeUser = userRef.current;
    if (!hasVerifiedGoogleAccount(activeUser) || !activeUser) {
      notify('info', 'Connect your Google Account to sync client data to Cloud.');
      return;
    }
    setCloudSyncStatus('syncing');
    try {
      if (cloudBootstrappedUid !== activeUser.uid) {
        await bootstrapFirestoreForUser(activeUser);
      }
      const res = await syncUnsyncedLocalDocsToFirestore();
      setLastCloudSyncAt(new Date().toISOString());
      setCloudSyncStatus('synced');
      if (res.pushed > 0) {
        notify('success', `Backed up ${res.pushed} record(s) to your Google Account.`);
      } else {
        notify('success', 'All client & billing records are synced with your Google Account.');
      }
    } catch (err) {
      setCloudSyncStatus('local_only');
      notify('error', err instanceof Error ? err.message : 'Cloud sync failed');
    }
  }, [notify, cloudBootstrappedUid, bootstrapFirestoreForUser]);

  const checkSecurityStatus = useCallback(async (overrideUser?: User | null) => {
    const activeUser = overrideUser !== undefined ? overrideUser : userRef.current;
    const email = activeUser?.email || '';
    setSecurityLoading(true);
    try {
      const status = await fetchSecurityStatus(email);
      setSecurityStatus(status);
      if (status.maskedEmail) {
        setSecurityMaskedEmail(status.maskedEmail);
      } else if (!email) {
        setSecurityMaskedEmail('');
      }
      if (status.challengeCooldownSeconds > 0) {
        setSecurityCooldownSeconds(status.challengeCooldownSeconds);
      }
      if (!status.unlocked && status.require24hOtp && email) {
        setStoredSecurityToken(email, '');
      }
    } catch {
      // Keep safe fail-closed state unless status already verified
    } finally {
      setSecurityLoading(false);
    }
  }, []);

  const securityState: 'checking' | 'locked_no_google' | 'locked_otp_required' | 'unlocked' = (() => {
    if (authLoading || securityLoading) return 'checking';
    if (securityStatus && !securityStatus.require24hOtp) return 'unlocked';
    if (!user?.email) return 'locked_no_google';
    if (securityStatus?.unlocked) return 'unlocked';
    return 'locked_otp_required';
  })();

  const requestSecurityCode = useCallback(async () => {
    const email = userRef.current?.email || '';
    if (!email) return;
    setSecurityCodeSending(true);
    setSecurityError(null);
    try {
      const res = await sendSecurityCode(email);
      if (res.maskedEmail) {
        setSecurityMaskedEmail(res.maskedEmail);
      }
      if (res.sent) {
        setSecurityCodeSent(true);
        setSecurityRequiresGmailAuth(false);
        setSecurityDeliveryMethod(res.deliveryMethod || null);
        if (typeof res.cooldownSeconds === 'number' && res.cooldownSeconds > 0) {
          setSecurityCooldownSeconds(res.cooldownSeconds);
        }
        if (!res.reusedActiveChallenge) {
          notify('success', `Security code sent to ${res.maskedEmail || email}`);
        }
      } else if (res.requiresGmailAuth) {
        setSecurityCodeSent(false);
        setSecurityRequiresGmailAuth(true);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to send security code';
      setSecurityError(msg);
      notify('error', msg);
    } finally {
      setSecurityCodeSending(false);
    }
  }, [notify]);

  const submitSecurityCode = useCallback(
    async (code: string): Promise<boolean> => {
      const email = userRef.current?.email || '';
      if (!email) return false;
      setSecurityVerifying(true);
      setSecurityError(null);
      try {
        const res = await verifySecurityCode(email, code);
        setStoredSecurityToken(email, res.securityToken);
        setSecurityStatus(res.status);
        setSecurityCodeSent(false);
        setSecurityRequiresGmailAuth(false);
        setSecurityCooldownSeconds(0);
        autoOtpAttemptedKeyRef.current = '';
        notify('success', 'Workspace unlocked for 24 hours.');
        return true;
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Invalid security code';
        setSecurityError(msg);
        return false;
      } finally {
        setSecurityVerifying(false);
      }
    },
    [notify]
  );

  const lockPlatformNow = useCallback(async () => {
    const email = userRef.current?.email || '';
    try {
      await lockSecuritySession(email);
    } catch {
      if (email) setStoredSecurityToken(email, '');
    }
    autoOtpAttemptedKeyRef.current = '';
    setSecurityCodeSent(false);
    setSecurityError(null);
    await checkSecurityStatus(userRef.current);
    notify('info', 'Platform locked. Verify your Gmail security code to re-enter.');
  }, [checkSecurityStatus, notify]);

  const toggleRequire24hOtp = useCallback(
    async (enabled: boolean) => {
      try {
        await updateSecuritySettings(enabled);
        await checkSecurityStatus(userRef.current);
        notify(
          'success',
          enabled
            ? '24-hour Gmail security code enforcement enabled.'
            : '24-hour Gmail security code requirement disabled.'
        );
      } catch (err) {
        notify('error', err instanceof Error ? err.message : 'Failed to update security policy');
      }
    },
    [checkSecurityStatus, notify]
  );

  useEffect(() => {
    if (securityCooldownSeconds <= 0) return;
    const id = window.setInterval(() => {
      setSecurityCooldownSeconds((prev) => (prev <= 1 ? 0 : prev - 1));
    }, 1000);
    return () => window.clearInterval(id);
  }, [securityCooldownSeconds]);

  // Re-check 24h security status on focus and every 60s so 24h expiry locks automatically
  useEffect(() => {
    if (authLoading) return;
    const check = () => {
      checkSecurityStatus();
    };
    window.addEventListener('focus', check);
    const intervalId = window.setInterval(check, 60_000);
    return () => {
      window.removeEventListener('focus', check);
      window.clearInterval(intervalId);
    };
  }, [authLoading, checkSecurityStatus]);

  // Auto-send OTP once when locked with a linked Google account and active SMTP or Gmail token
  useEffect(() => {
    if (securityState !== 'locked_otp_required' || !user?.email) return;
    const smtpActive = Boolean(smtpStatus?.enabled && smtpStatus?.connectionVerified);
    const attemptKey = `${user.email.toLowerCase()}:${gmailConnected ? 'gmail' : 'nogmail'}:${
      smtpActive ? 'smtp' : 'nosmtp'
    }`;
    if (autoOtpAttemptedKeyRef.current === attemptKey) return;
    autoOtpAttemptedKeyRef.current = attemptKey;
    requestSecurityCode();
  }, [securityState, user?.email, gmailConnected, smtpStatus, requestSecurityCode]);

  // Track connected Google account: stay empty when disconnected, load account data when connected
  useEffect(() => {
    let mounted = true;
    resolveGoogleRedirectResult()
      .then((redirectRes) => {
        if (!mounted || !redirectRes) return;
        if (redirectRes.hasGmailScope) {
          setGmailConnected(true);
        }
      })
      .catch((err) => {
        if (!mounted) return;
        const friendly = formatGoogleAuthError(err);
        setAuthError(friendly);
      });

    const unsub = subscribeToAuth(async (firebaseUser) => {
      userRef.current = firebaseUser;
      setUser(firebaseUser);
      setGmailConnected(Boolean(getCachedGmailAccessToken()));

      if (!firebaseUser) {
        lastAuthUidRef.current = null;
        clearWorkspaceState();
        setDataLoading(false);
        await refreshGatewayStatus();
        await checkSecurityStatus(null);
        setAuthLoading(false);
        return;
      }

      if (lastAuthUidRef.current && lastAuthUidRef.current !== firebaseUser.uid) {
        clearWorkspaceState();
      }
      lastAuthUidRef.current = firebaseUser.uid;
      setDataLoading(true);

      // Ensure Firebase ID token is ready before server store requests
      await firebaseUser.getIdToken().catch(() => firebaseUser.getIdToken(true).catch(() => null));

      // Load account-scoped store immediately so saved clients appear right away without waiting on Firestore bootstrap
      await refreshStore();
      await Promise.all([refreshGatewayStatus(), checkSecurityStatus(firebaseUser)]);
      setAuthLoading(false);

      if (hasVerifiedGoogleAccount(firebaseUser)) {
        void bootstrapFirestoreForUser(firebaseUser);
      } else {
        setCloudBootstrappedUid(null);
        setCloudSyncStatus('local_only');
      }
    });
    return () => {
      mounted = false;
      unsub();
    };
  }, [clearWorkspaceState, refreshStore, bootstrapFirestoreForUser, refreshGatewayStatus, checkSecurityStatus]);

  // Authoritative Cloud Firestore listeners scoped to the connected Google Account (/users/{uid}/...)
  useEffect(() => {
    if (!user || !hasVerifiedGoogleAccount(user) || cloudBootstrappedUid !== user.uid) return;

    const uid = user.uid;
    const unsubscribers: Array<() => void> = [];
    const listen = <T extends object>(
      colName: SyncCollectionName,
      onRows: (rows: T[]) => void
    ) => {
      const unsub = onSnapshot(
        userCollectionRef(uid, colName),
        (snapshot) => {
          // Never wipe local/UI client records from an empty offline cache snapshot
          if (snapshot.metadata.fromCache && snapshot.empty) {
            return;
          }

          const rows = snapshot.docs.map(
            (d) => normalizeFirestoreDoc(d.data() as Record<string, unknown>) as unknown as T
          );
          onRows(rows);
          if (colName === 'clients') {
            setDataLoading(false);
          }
          if (!snapshot.metadata.fromCache) {
            setLastCloudSyncAt(new Date().toISOString());
            setCloudSyncStatus('synced');
          }
          syncCloudSnapshotToLocalStore(
            {
              [colName]: rows as unknown as Array<Record<string, unknown>>,
            },
            snapshot.metadata.fromCache ? [] : [colName]
          ).catch(() => {});
        },
        (error) => {
          const code =
            typeof error === 'object' && error !== null && 'code' in error
              ? String((error as { code?: unknown }).code)
              : '';
          if (code === 'unavailable') {
            setCloudSyncStatus('local_only');
            return;
          }
          try {
            handleFirestoreError(error, OperationType.LIST, `users/${uid}/${colName}`);
          } catch {
            // Surface details in console while keeping workspace resilient
          }
        }
      );
      unsubscribers.push(unsub);
    };

    listen<ClientRecord>('clients', setClients);
    listen<ServiceRecord>('services', (rows) => {
      if (rows.length > 0) setServices(rows);
    });
    listen<SubscriptionRecord>('subscriptions', setSubscriptions);
    listen<PaymentRecord>('payments', setPayments);
    listen<PaymentRequestRecord>('payment_requests', setPaymentRequests);
    listen<InvoiceRecord>('invoices', setInvoices);
    listen<InvoiceItemRecord>('invoice_items', setInvoiceItems);
    listen<ReminderSettingRecord>('reminder_settings', setReminderSettings);
    listen<ReminderLogRecord>('reminder_logs', setReminderLogs);
    listen<EmailLogRecord>('email_logs', setEmailLogs);
    listen<EmailTemplateRecord>('email_templates', (rows) => {
      if (rows.length > 0) setEmailTemplates(rows);
    });
    listen<PaymentGatewaySettingRecord>('payment_gateway_settings', (rows) => {
      const found = rows.find((g) => g.id === 'default') || rows[0];
      if (found) setGatewayDbSettings(found);
    });
    listen<WebhookEventRecord>('webhook_events', setWebhookEvents);
    listen<SystemSettingRecord>('system_settings', (rows) => {
      const found = rows.find((s) => s.id === 'default') || rows[0];
      if (found) {
        setSystemSettings(found);
        if (found.timezone) {
          updateServerCronTimezone(found.timezone).catch(() => {});
        }
      }
    });

    return () => {
      for (const u of unsubscribers) u();
    };
  }, [user, cloudBootstrappedUid]);

  const syncingWebhooksRef = useRef(false);

  // Sync Stripe return URL or pending verified/test webhooks automatically
  const syncPendingWebhooks = useCallback(async () => {
    if (dataLoading || clients.length === 0 || syncingWebhooksRef.current) return;
    syncingWebhooksRef.current = true;
    try {
      const { events } = await fetchPendingWebhooks();
      for (const evt of events) {
        const whDocId = `wh_${evt.externalEventId.replace(/[^a-zA-Z0-9_\-]/g, '_')}`;
        await saveEntity(
          'webhook_events',
          whDocId,
          {
            id: whDocId,
            provider: evt.provider,
            eventType: evt.eventType,
            externalEventId: evt.externalEventId,
            status: 'processed',
            summary: evt.summary,
            receivedAt: evt.receivedAt,
          },
          { isNew: true }
        );

        if (evt.eventType === 'checkout.session.completed' && evt.paymentRequestId) {
          const reqDoc = paymentRequests.find((r) => r.id === evt.paymentRequestId);
          const client = reqDoc ? clients.find((c) => c.id === reqDoc.clientId) : null;
          if (reqDoc && reqDoc.status !== 'paid' && client) {
            const sub = reqDoc.subscriptionId
              ? subscriptions.find((s) => s.id === reqDoc.subscriptionId) || null
              : null;
            const res = await confirmPaymentAndGenerateInvoice({
              client,
              amount: evt.amountPaid || reqDoc.amount,
              currency: evt.currency || reqDoc.currency,
              serviceName: reqDoc.serviceName,
              serviceDescription: reqDoc.description,
              billingType: reqDoc.billingType,
              paymentMethod: 'card',
              paymentDate: new Date().toISOString().slice(0, 10),
              transactionReference: evt.transactionReference || evt.sessionId || evt.externalEventId,
              manuallyVerified: false,
              subscription: sub,
              paymentRequest: reqDoc,
              existingInvoices: invoices,
              systemSettings,
              templates: emailTemplates,
              sendConfirmationEmail: true,
            });
            notify(
              'success',
              `${
                evt.provider === 'test_checkout' ? 'Test Checkout' : 'Card payment'
              } confirmed & Invoice ${res.invoiceNumber} issued for ${client.businessName}.`
            );
          }
        }
        await ackWebhookEvent(evt.externalEventId);
      }
    } catch {
      // Non-blocking background sync
    } finally {
      syncingWebhooksRef.current = false;
    }
  }, [
    dataLoading,
    clients,
    paymentRequests,
    subscriptions,
    invoices,
    systemSettings,
    emailTemplates,
    notify,
  ]);

  useEffect(() => {
    if (securityState !== 'unlocked' || dataLoading || clients.length === 0) return;

    const params = new URLSearchParams(window.location.search);
    const checkoutState = params.get('checkout');
    const sessionId = params.get('session_id');
    const reqId = params.get('request_id');

    if (checkoutState === 'success' && sessionId && reqId) {
      (async () => {
        try {
          const session = await checkCheckoutSessionStatus(sessionId);
          if (session.paymentStatus === 'paid') {
            const reqDoc = paymentRequests.find((r) => r.id === reqId);
            const client = reqDoc ? clients.find((c) => c.id === reqDoc.clientId) : null;
            if (reqDoc && reqDoc.status !== 'paid' && client) {
              const sub = reqDoc.subscriptionId
                ? subscriptions.find((s) => s.id === reqDoc.subscriptionId) || null
                : null;
              await confirmPaymentAndGenerateInvoice({
                client,
                amount: reqDoc.amount,
                currency: reqDoc.currency,
                serviceName: reqDoc.serviceName,
                serviceDescription: reqDoc.description,
                billingType: reqDoc.billingType,
                paymentMethod: 'card',
                paymentDate: new Date().toISOString().slice(0, 10),
                transactionReference: session.paymentIntent || session.id,
                manuallyVerified: false,
                subscription: sub,
                paymentRequest: reqDoc,
                existingInvoices: invoices,
                systemSettings,
                templates: emailTemplates,
                sendConfirmationEmail: true,
              });
              notify('success', `Card payment verified & invoice generated for ${client.businessName}`);
            }
          }
        } catch (err) {
          notify(
            'error',
            err instanceof Error ? err.message : 'Failed to verify Stripe checkout return'
          );
        } finally {
          window.history.replaceState({}, document.title, window.location.pathname);
        }
      })();
    }

    syncPendingWebhooks();
    const intervalId = window.setInterval(syncPendingWebhooks, 8000);
    const onFocus = () => {
      syncPendingWebhooks();
    };
    window.addEventListener('focus', onFocus);

    return () => {
      window.clearInterval(intervalId);
      window.removeEventListener('focus', onFocus);
    };
  }, [
    dataLoading,
    clients,
    paymentRequests,
    subscriptions,
    invoices,
    systemSettings,
    emailTemplates,
    notify,
    syncPendingWebhooks,
  ]);

  const autoEvalBusyRef = useRef(false);
  const lastAutoSweepRef = useRef(0);

  // Automatic 2-day onboarding payment links & 1-month renewal / service-pause emails when SMTP or Gmail is active
  useEffect(() => {
    if (securityState !== 'unlocked' || !emailDeliveryActive || dataLoading || clients.length === 0) {
      return;
    }

    const runSweep = async (forceInterval = false) => {
      const now = Date.now();
      if (autoEvalBusyRef.current) return;
      if (!forceInterval && now - lastAutoSweepRef.current < 120_000) return;

      autoEvalBusyRef.current = true;
      lastAutoSweepRef.current = now;
      try {
        const res = await evaluateAndDispatchReminders({
          clients,
          subscriptions,
          payments,
          paymentRequests,
          reminderSettings,
          reminderLogs,
          emailLogs,
          templates: emailTemplates,
          gatewaySettings: gatewayDbSettings,
          systemSettings,
          sentKeysGuard: autoSentGuardRef.current,
        });
        if (res.sent > 0) {
          notify(
            'success',
            `Automated billing sent ${res.sent} email${res.sent === 1 ? '' : 's'} via Gmail.`
          );
        }
      } catch {
        // Non-blocking background automation
      } finally {
        autoEvalBusyRef.current = false;
      }
    };

    runSweep(false);
    const sweepInterval = window.setInterval(() => {
      runSweep(true);
    }, 15 * 60 * 1000);

    return () => {
      window.clearInterval(sweepInterval);
    };
  }, [
    securityState,
    emailDeliveryActive,
    dataLoading,
    clients,
    subscriptions,
    payments,
    paymentRequests,
    reminderSettings,
    reminderLogs,
    emailLogs,
    emailTemplates,
    gatewayDbSettings,
    systemSettings,
    notify,
  ]);

  const connectGoogle = async (options?: {
    includeGmail?: boolean;
    forceAccountSelect?: boolean;
    forceConsent?: boolean;
  }) => {
    setAuthError(null);
    setGoogleConnecting(true);
    const includeGmail = options?.includeGmail ?? true;
    const forceAccountSelect = options?.forceAccountSelect ?? true;
    const forceConsent = options?.forceConsent ?? false;
    try {
      const res = await connectGoogleAccount({ includeGmail, forceAccountSelect, forceConsent });
      userRef.current = res.user;
      setUser(res.user);
      setGmailConnected(res.hasGmailScope);
      autoOtpAttemptedKeyRef.current = '';
      setSecurityCodeSent(false);
      setSecurityRequiresGmailAuth(false);
      await checkSecurityStatus(res.user);
      if (includeGmail && !res.hasGmailScope) {
        notify(
          'info',
          `Google account ${res.user.email} connected, but Gmail send permission was not granted.`
        );
      } else {
        notify(
          'success',
          includeGmail
            ? `Connected ${res.user.email} with Gmail sending enabled.`
            : `Connected Google account ${res.user.email} (Profile only).`
        );
      }
    } catch (err) {
      const friendly = formatGoogleAuthError(err);
      setAuthError(friendly);
      notify('error', friendly);
    } finally {
      setGoogleConnecting(false);
    }
  };

  const connectGoogleWithRedirect = async (includeGmail = true) => {
    setAuthError(null);
    setGoogleConnecting(true);
    try {
      await startGoogleRedirectSignIn({ includeGmail, forceAccountSelect: true });
    } catch (err) {
      const friendly = formatGoogleAuthError(err);
      setAuthError(friendly);
      notify('error', friendly);
      setGoogleConnecting(false);
    }
  };

  const switchGoogleAccount = async (includeGmail = true) => {
    setAuthError(null);
    setGoogleConnecting(true);
    try {
      const res = await switchGooglePopup(includeGmail);
      userRef.current = res.user;
      setUser(res.user);
      setGmailConnected(res.hasGmailScope);
      autoOtpAttemptedKeyRef.current = '';
      setSecurityCodeSent(false);
      setSecurityRequiresGmailAuth(false);
      await checkSecurityStatus(res.user);
      notify(
        'success',
        `Switched Google account to ${res.user.email}${
          res.hasGmailScope ? ' (Gmail enabled)' : ''
        }.`
      );
    } catch (err) {
      const friendly = formatGoogleAuthError(err);
      setAuthError(friendly);
      notify('error', friendly);
    } finally {
      setGoogleConnecting(false);
    }
  };

  const disconnectGoogle = async () => {
    const prevEmail = userRef.current?.email || '';
    if (prevEmail) {
      setStoredSecurityToken(prevEmail, '');
    }
    userRef.current = null;
    lastAuthUidRef.current = null;
    autoOtpAttemptedKeyRef.current = '';
    setGmailConnected(false);
    setUser(null);
    setAuthError(null);
    setSecurityCodeSent(false);
    setSecurityError(null);
    clearWorkspaceState();
    setDataLoading(false);
    await signOutAdmin();
    await checkSecurityStatus(null);
    notify('info', 'Google account disconnected. Workspace cleared.');
  };

  const signIn = async () => {
    await connectGoogle({ includeGmail: true, forceAccountSelect: true });
  };

  const reconnectGmail = async () => {
    await connectGoogle({ includeGmail: true, forceAccountSelect: !user });
  };

  const logout = async () => {
    await disconnectGoogle();
  };

  return (
    <FreskaContext.Provider
      value={{
        user,
        authLoading,
        authError,
        googleConnecting,
        googleProfileConnected: Boolean(user),
        gmailConnected,
        gmailEmail: user?.email || null,
        smtpStatus,
        emailDeliveryActive,
        activeSection,
        selectedClientId,
        setActiveSection,
        openClientProfile,
        connectGoogle,
        connectGoogleWithRedirect,
        switchGoogleAccount,
        disconnectGoogle,
        signIn,
        reconnectGmail,
        logout,
        clients,
        services,
        subscriptions,
        payments,
        paymentRequests,
        invoices,
        invoiceItems,
        reminderSettings,
        reminderLogs,
        emailLogs,
        emailTemplates,
        gatewayDbSettings,
        gatewayServerStatus,
        webhookEvents,
        systemSettings,
        dataLoading,
        refreshStore,
        refreshGatewayStatus,
        refreshSmtpStatus,
        cloudSyncStatus,
        lastCloudSyncAt,
        syncToCloudNow,
        toasts,
        notify,
        dismissToast,
        securityState,
        securityStatus,
        securityLoading,
        securityCodeSending,
        securityVerifying,
        securityCodeSent,
        securityRequiresGmailAuth,
        securityDeliveryMethod,
        securityMaskedEmail,
        securityError,
        securityCooldownSeconds,
        checkSecurityStatus,
        requestSecurityCode,
        submitSecurityCode,
        lockPlatformNow,
        toggleRequire24hOtp,
      }}
    >
      {children}
    </FreskaContext.Provider>
  );
};

export function useFreska() {
  const ctx = useContext(FreskaContext);
  if (!ctx) throw new Error('useFreska must be used inside FreskaProvider');
  return ctx;
}
