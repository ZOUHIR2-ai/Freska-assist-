import React, { useEffect, useMemo, useState } from 'react';
import { Send, Save, RotateCcw } from 'lucide-react';
import { saveEntity } from '../lib/storeClient.ts';
import { DEFAULT_EMAIL_TEMPLATES, TEMPLATE_VARIABLES } from '../lib/templates.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import { StatusBadge } from '../components/StatusBadge.tsx';
import { ConfirmDialog } from '../components/ConfirmDialog.tsx';

interface EmailCenterPageProps {
  onComposeEmail: () => void;
}

export const EmailCenterPage: React.FC<EmailCenterPageProps> = ({ onComposeEmail }) => {
  const { emailTemplates, emailLogs, notify } = useFreska();

  const [tab, setTab] = useState<'logs' | 'templates'>('logs');
  const [selectedTplId, setSelectedTplId] = useState('');
  const [senderDisplayName, setSenderDisplayName] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [saving, setSaving] = useState(false);
  const [restoreConfirmOpen, setRestoreConfirmOpen] = useState(false);
  const [restoring, setRestoring] = useState(false);

  const sortedTemplates = useMemo(
    () => [...emailTemplates].sort((a, b) => a.label.localeCompare(b.label)),
    [emailTemplates]
  );

  const sortedLogs = useMemo(
    () => [...emailLogs].sort((a, b) => (b.sentAt || '').localeCompare(a.sentAt || '')),
    [emailLogs]
  );

  useEffect(() => {
    if (!selectedTplId && sortedTemplates.length > 0) {
      const first = sortedTemplates[0];
      setSelectedTplId(first.id);
      setSenderDisplayName(first.senderDisplayName);
      setSubject(first.subject);
      setBody(first.body);
    }
  }, [sortedTemplates, selectedTplId]);

  const handleSelectTemplate = (id: string) => {
    setSelectedTplId(id);
    const tpl = sortedTemplates.find((t) => t.id === id);
    if (tpl) {
      setSenderDisplayName(tpl.senderDisplayName);
      setSubject(tpl.subject);
      setBody(tpl.body);
    }
  };

  const handleSaveTemplate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTplId) return;
    setSaving(true);
    try {
      await saveEntity('email_templates', selectedTplId, {
        senderDisplayName: senderDisplayName.trim(),
        subject: subject.trim(),
        body,
      });
      notify('success', 'Email template saved.');
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to save template');
    } finally {
      setSaving(false);
    }
  };

  const handleRestoreDefaultTemplates = async () => {
    setRestoring(true);
    try {
      for (const tpl of DEFAULT_EMAIL_TEMPLATES) {
        await saveEntity('email_templates', tpl.id, { ...tpl }, { silent: true });
      }
      const current = DEFAULT_EMAIL_TEMPLATES.find((t) => t.id === selectedTplId);
      if (current) {
        setSenderDisplayName(current.senderDisplayName);
        setSubject(current.subject);
        setBody(current.body);
      }
      notify('success', 'All email templates updated to inbox-friendly defaults.');
      setRestoreConfirmOpen(false);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to restore defaults');
    } finally {
      setRestoring(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div>
          <h1 className="text-xl font-semibold text-slate-900">Email Center</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Monitor Gmail communication logs and customize automated email templates.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center gap-2 w-full sm:w-auto">
          <div className="grid grid-cols-2 sm:flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg w-full sm:w-auto">
            <button
              type="button"
              onClick={() => setTab('logs')}
              className={`px-3 py-2 sm:py-1.5 text-xs font-medium rounded-md whitespace-nowrap text-center ${
                tab === 'logs' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Email Log ({emailLogs.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('templates')}
              className={`px-3 py-2 sm:py-1.5 text-xs font-medium rounded-md whitespace-nowrap text-center ${
                tab === 'templates' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Templates ({emailTemplates.length})
            </button>
          </div>
          <button
            type="button"
            onClick={onComposeEmail}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Compose Email</span>
          </button>
        </div>
      </div>

      {tab === 'logs' ? (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          {sortedLogs.length === 0 ? (
            <p className="p-10 text-center text-xs text-slate-500">
              No outgoing Gmail messages logged yet.
            </p>
          ) : (
            <>
              <div className="md:hidden divide-y divide-slate-100">
                {sortedLogs.map((log) => (
                  <div key={log.id} className="p-4 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-900 break-words">
                          {log.subject}
                        </p>
                        <p className="text-xs text-slate-600 truncate mt-0.5">{log.recipient}</p>
                      </div>
                      <StatusBadge status={log.status} />
                    </div>
                    <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
                      <span className="font-mono">{log.emailType}</span>
                      <span className="font-mono tabular-nums">
                        {log.sentAt ? log.sentAt.slice(0, 16).replace('T', ' ') : '—'}
                      </span>
                    </div>
                    {(log.gmailMessageId || log.errorMessage) && (
                      <p className="text-[11px] font-mono text-slate-500 break-all bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5">
                        {log.gmailMessageId ? `ID: ${log.gmailMessageId}` : log.errorMessage}
                      </p>
                    )}
                  </div>
                ))}
              </div>

              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase">
                      <th className="py-3 px-4">Recipient</th>
                      <th className="py-3 px-4">Subject</th>
                      <th className="py-3 px-4">Email Type</th>
                      <th className="py-3 px-4">Sent Date</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {sortedLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 text-slate-900 font-medium">{log.recipient}</td>
                        <td className="py-3 px-4 text-slate-800">{log.subject}</td>
                        <td className="py-3 px-4 text-xs text-slate-600 font-mono">
                          {log.emailType}
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-slate-600">
                          {log.sentAt ? log.sentAt.slice(0, 16).replace('T', ' ') : '—'}
                        </td>
                        <td className="py-3 px-4">
                          <StatusBadge status={log.status} />
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-500 font-mono">
                          {log.gmailMessageId
                            ? `ID: ${log.gmailMessageId}`
                            : log.errorMessage || '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
          {/* Mobile horizontal template switcher */}
          <div className="lg:hidden bg-white border border-slate-200 rounded-xl p-2 overflow-x-auto">
            <div className="flex items-center gap-1.5 min-w-max">
              {sortedTemplates.map((tpl) => (
                <button
                  key={tpl.id}
                  type="button"
                  onClick={() => handleSelectTemplate(tpl.id)}
                  className={`px-3 py-2 min-h-[40px] rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                    selectedTplId === tpl.id
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {tpl.label}
                </button>
              ))}
            </div>
          </div>

          {/* Desktop sidebar template selector */}
          <div className="hidden lg:block bg-white border border-slate-200 rounded-xl p-3 space-y-1 h-fit">
            <p className="px-3 py-2 text-xs font-semibold text-slate-500 uppercase">
              Editable Templates
            </p>
            {sortedTemplates.map((tpl) => (
              <button
                key={tpl.id}
                type="button"
                onClick={() => handleSelectTemplate(tpl.id)}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-colors ${
                  selectedTplId === tpl.id
                    ? 'bg-slate-900 text-white font-medium'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                {tpl.label}
              </button>
            ))}
          </div>

          <form
            onSubmit={handleSaveTemplate}
            className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-4"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Sender Display Name
                </label>
                <input
                  type="text"
                  required
                  value={senderDisplayName}
                  onChange={(e) => setSenderDisplayName(e.target.value)}
                  className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Email Subject
                </label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Email Content
              </label>
              <textarea
                rows={11}
                required
                value={body}
                onChange={(e) => setBody(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg"
              />
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
              <p className="text-[11px] font-semibold text-slate-600 mb-1.5">
                Available Dynamic Variables
              </p>
              <div className="flex flex-wrap gap-1.5">
                {TEMPLATE_VARIABLES.map((v) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setBody((prev) => `${prev}${v}`)}
                    className="px-2 py-1 text-[11px] font-mono bg-white border border-slate-200 rounded hover:border-slate-400 text-slate-700"
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col-reverse sm:flex-row sm:items-center justify-between gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setRestoreConfirmOpen(true)}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restore Inbox-Friendly Defaults</span>
              </button>
              <button
                type="submit"
                disabled={saving}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{saving ? 'Saving...' : 'Save Template'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog
        open={restoreConfirmOpen}
        title="Restore Inbox-Friendly Default Templates"
        description={`Reset all ${DEFAULT_EMAIL_TEMPLATES.length} email templates to the updated inbox-friendly wording (including welcome, 2-day follow-up, PDF-only invoice delivery, and service-pause renewal notices)?`}
        confirmLabel="Restore Defaults"
        busy={restoring}
        onConfirm={handleRestoreDefaultTemplates}
        onCancel={() => setRestoreConfirmOpen(false)}
      />
    </div>
  );
};
