import React, { useMemo, useState } from 'react';
import {
  Download,
  Link2,
  CreditCard,
  Copy,
  Mail,
  CheckCircle2,
  XCircle,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';
import { saveEntity } from '../lib/storeClient.ts';
import {
  addDays,
  confirmPaymentAndGenerateInvoice,
  exportPaymentsToCsv,
  formatMoney,
  formatPaymentMethodLabel,
  todayIsoDate,
} from '../lib/billingEngine.ts';
import { checkCheckoutSessionStatus } from '../lib/api.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import { StatusBadge } from '../components/StatusBadge.tsx';
import type { PaymentRequestRecord } from '../types/freska.ts';

interface PaymentsPageProps {
  onOpenPaymentLink: () => void;
  onOpenManualPayment: () => void;
  onVerifyTransfer: (req: PaymentRequestRecord) => void;
  onSendPaymentLinkEmail: (req: PaymentRequestRecord) => void;
}

export const PaymentsPage: React.FC<PaymentsPageProps> = ({
  onOpenPaymentLink,
  onOpenManualPayment,
  onVerifyTransfer,
  onSendPaymentLinkEmail,
}) => {
  const {
    clients,
    subscriptions,
    payments,
    paymentRequests,
    invoices,
    systemSettings,
    emailTemplates,
    openClientProfile,
    notify,
  } = useFreska();

  const [tab, setTab] = useState<'payments' | 'requests'>('payments');
  const [clientFilter, setClientFilter] = useState('all');
  const [methodFilter, setMethodFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [verifyingSessionId, setVerifyingSessionId] = useState<string | null>(null);

  const today = todayIsoDate();
  const currentMonth = today.slice(0, 7);
  const currency = systemSettings.defaultCurrency || 'EUR';

  const summary = useMemo(() => {
    const paid = payments.filter((p) => p.status === 'paid');
    const totalRevenue = paid.reduce((s, p) => s + Number(p.amount || 0), 0);
    const monthlyRevenue = paid
      .filter((p) => p.paymentDate.startsWith(currentMonth))
      .reduce((s, p) => s + Number(p.amount || 0), 0);
    const subscriptionRevenue = paid
      .filter((p) => p.billingType === 'subscription')
      .reduce((s, p) => s + Number(p.amount || 0), 0);
    const oneTimeRevenue = paid
      .filter((p) => p.billingType === 'one_time')
      .reduce((s, p) => s + Number(p.amount || 0), 0);

    const pendingCount =
      paymentRequests.filter((r) => r.status === 'pending').length +
      payments.filter((p) => p.status === 'pending').length;
    const unpaidCount = subscriptions.filter((s) => s.status === 'unpaid').length;
    const overdueCount =
      subscriptions.filter((s) => s.status === 'overdue').length +
      paymentRequests.filter((r) => r.status === 'overdue' || (r.status === 'pending' && r.dueDate < today)).length;
    const upcomingCount = subscriptions.filter(
      (s) => s.status === 'active' && s.nextPaymentDate >= today && s.nextPaymentDate <= addDays(today, 14)
    ).length;

    return {
      totalRevenue,
      monthlyRevenue,
      subscriptionRevenue,
      oneTimeRevenue,
      paidCount: paid.length,
      pendingCount,
      unpaidCount,
      overdueCount,
      upcomingCount,
    };
  }, [payments, paymentRequests, subscriptions, currentMonth, today]);

  const filteredPayments = useMemo(() => {
    return payments
      .filter((p) => {
        if (clientFilter !== 'all' && p.clientId !== clientFilter) return false;
        if (methodFilter !== 'all' && p.paymentMethod !== methodFilter) return false;
        if (typeFilter !== 'all' && p.billingType !== typeFilter) return false;
        if (statusFilter !== 'all' && p.status !== statusFilter) return false;
        if (dateFrom && p.paymentDate < dateFrom) return false;
        if (dateTo && p.paymentDate > dateTo) return false;
        return true;
      })
      .sort((a, b) => b.paymentDate.localeCompare(a.paymentDate));
  }, [payments, clientFilter, methodFilter, typeFilter, statusFilter, dateFrom, dateTo]);

  const filteredRequests = useMemo(() => {
    return paymentRequests
      .filter((r) => {
        if (clientFilter !== 'all' && r.clientId !== clientFilter) return false;
        if (methodFilter !== 'all' && r.paymentMethod !== methodFilter) return false;
        if (typeFilter !== 'all' && r.billingType !== typeFilter) return false;
        return true;
      })
      .sort((a, b) => b.dueDate.localeCompare(a.dueDate));
  }, [paymentRequests, clientFilter, methodFilter, typeFilter]);

  const getClient = (clientId: string) => clients.find((c) => c.id === clientId);

  const handleExportCsv = () => {
    const csv = exportPaymentsToCsv(filteredPayments, clients);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `freskaassist-payments-${today}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    notify('success', `Exported ${filteredPayments.length} payment records.`);
  };

  const handleCancelRequest = async (req: PaymentRequestRecord) => {
    try {
      await saveEntity('payment_requests', req.id, { status: 'cancelled' });
      notify('success', `Payment request ${req.reference} cancelled.`);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to cancel payment request');
    }
  };

  const handleVerifyCardSession = async (req: PaymentRequestRecord) => {
    if (!req.gatewaySessionId) return;
    setVerifyingSessionId(req.id);
    try {
      const session = await checkCheckoutSessionStatus(req.gatewaySessionId);
      if (session.paymentStatus === 'paid') {
        const client = getClient(req.clientId);
        if (!client) throw new Error('Client not found');
        const sub = req.subscriptionId
          ? subscriptions.find((s) => s.id === req.subscriptionId) || null
          : null;
        const res = await confirmPaymentAndGenerateInvoice({
          client,
          amount: req.amount,
          currency: req.currency,
          serviceName: req.serviceName,
          serviceDescription: req.description,
          billingType: req.billingType,
          paymentMethod: 'card',
          paymentDate: todayIsoDate(),
          transactionReference: session.paymentIntent || session.id,
          manuallyVerified: false,
          subscription: sub,
          paymentRequest: req,
          existingInvoices: invoices,
          systemSettings,
          templates: emailTemplates,
          sendConfirmationEmail: true,
        });
        notify('success', `Card payment confirmed & Invoice ${res.invoiceNumber} issued.`);
      } else {
        notify('info', `Checkout session status is currently "${session.paymentStatus}".`);
      }
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to verify card checkout');
    } finally {
      setVerifyingSessionId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div>
          <h1 className="text-xl font-semibold text-slate-900">Payments & Financial Ledger</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Track revenue streams, verify bank transfers, manage payment links, and export records.
          </p>
        </div>
        <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleExportCsv}
            className="min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50 text-slate-700 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            type="button"
            onClick={onOpenManualPayment}
            className="min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50 text-slate-700 whitespace-nowrap"
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Manual Payment</span>
          </button>
          <button
            type="button"
            onClick={onOpenPaymentLink}
            className="col-span-2 sm:col-span-1 min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg whitespace-nowrap"
          >
            <Link2 className="w-3.5 h-3.5" />
            <span>Create Payment Link</span>
          </button>
        </div>
      </div>

      {/* Financial Breakdown KPI Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500">Total Revenue</p>
          <p className="text-lg font-semibold font-mono tabular-nums text-slate-900 mt-1">
            {formatMoney(summary.totalRevenue, currency)}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">
            This Month: <span className="font-mono">{formatMoney(summary.monthlyRevenue, currency)}</span>
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500">Subscription Revenue</p>
          <p className="text-lg font-semibold font-mono tabular-nums text-slate-900 mt-1">
            {formatMoney(summary.subscriptionRevenue, currency)}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">
            One-Time: <span className="font-mono">{formatMoney(summary.oneTimeRevenue, currency)}</span>
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500">Confirmed & Pending</p>
          <p className="text-lg font-semibold font-mono tabular-nums text-slate-900 mt-1">
            {summary.paidCount} <span className="text-xs font-sans font-normal text-slate-500">paid</span> · {summary.pendingCount}{' '}
            <span className="text-xs font-sans font-normal text-slate-500">pending</span>
          </p>
          <p className="text-[11px] text-slate-500 mt-1">
            Unpaid cycles: {summary.unpaidCount}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500">Overdue & Upcoming</p>
          <p className="text-lg font-semibold font-mono tabular-nums text-slate-900 mt-1">
            <span className="text-red-700">{summary.overdueCount}</span>{' '}
            <span className="text-xs font-sans font-normal text-slate-500">overdue</span> · {summary.upcomingCount}{' '}
            <span className="text-xs font-sans font-normal text-slate-500">upcoming</span>
          </p>
          <p className="text-[11px] text-slate-500 mt-1">Next 14 days window</p>
        </div>
      </div>

      {/* Tabs + Filters */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 sm:p-4 space-y-3">
        <div className="w-full sm:w-auto overflow-x-auto">
          <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg min-w-max">
            <button
              type="button"
              onClick={() => setTab('payments')}
              className={`min-h-[38px] sm:min-h-0 px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap ${
                tab === 'payments' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Confirmed Payments ({payments.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('requests')}
              className={`min-h-[38px] sm:min-h-0 px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap ${
                tab === 'requests' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Payment Requests & Links ({paymentRequests.length})
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          <select
            value={clientFilter}
            onChange={(e) => setClientFilter(e.target.value)}
            className="min-h-[44px] sm:min-h-0 px-2.5 py-2 text-xs border border-slate-300 rounded-lg bg-white"
          >
            <option value="all">All Clients</option>
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.businessName}
              </option>
            ))}
          </select>
          <select
            value={methodFilter}
            onChange={(e) => setMethodFilter(e.target.value)}
            className="min-h-[44px] sm:min-h-0 px-2.5 py-2 text-xs border border-slate-300 rounded-lg bg-white"
          >
            <option value="all">All Methods</option>
            <option value="bank_transfer">Bank Transfer</option>
            <option value="manual">Manual Payment</option>
            <option value="card">Credit / Debit Card</option>
          </select>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="min-h-[44px] sm:min-h-0 px-2.5 py-2 text-xs border border-slate-300 rounded-lg bg-white"
          >
            <option value="all">All Billing Types</option>
            <option value="subscription">Subscription</option>
            <option value="one_time">One-Time</option>
          </select>
          {tab === 'payments' && (
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="min-h-[44px] sm:min-h-0 px-2.5 py-2 text-xs border border-slate-300 rounded-lg bg-white"
            >
              <option value="all">All Statuses</option>
              <option value="paid">Paid</option>
              <option value="pending">Pending</option>
              <option value="overdue">Overdue</option>
              <option value="refunded">Refunded</option>
              <option value="cancelled">Cancelled</option>
            </select>
          )}
          <input
            type="date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className="min-h-[44px] sm:min-h-0 px-2.5 py-2 text-xs border border-slate-300 rounded-lg"
            aria-label="From date"
          />
          <input
            type="date"
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            className="min-h-[44px] sm:min-h-0 px-2.5 py-2 text-xs border border-slate-300 rounded-lg"
            aria-label="To date"
          />
        </div>
      </div>

      {/* Table / Mobile Cards Content */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {tab === 'payments' ? (
          filteredPayments.length === 0 ? (
            <p className="p-10 text-center text-xs text-slate-500">
              No payment records match the current filters.
            </p>
          ) : (
            <>
              <div className="md:hidden divide-y divide-slate-100">
                {filteredPayments.map((p) => {
                  const c = getClient(p.clientId);
                  return (
                    <div key={p.id} className="p-4 space-y-2.5">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="text-[11px] font-mono text-slate-500">
                            {p.paymentCode} {p.invoiceNumber ? `· ${p.invoiceNumber}` : ''}
                          </p>
                          <button
                            type="button"
                            onClick={() => openClientProfile(p.clientId)}
                            className="font-semibold text-sm text-slate-900 hover:underline text-left block truncate max-w-full"
                          >
                            {c?.businessName || c?.fullName || 'Client'}
                          </button>
                          <p className="text-xs text-slate-600 truncate">{p.serviceName}</p>
                        </div>
                        <StatusBadge status={p.status} />
                      </div>
                      <div className="flex items-center justify-between text-xs bg-slate-50 border border-slate-100 rounded-lg px-3 py-2">
                        <span className="text-slate-600">
                          {p.paymentDate} · {formatPaymentMethodLabel(p.paymentMethod)}
                        </span>
                        <span className="font-mono font-semibold tabular-nums text-slate-900">
                          {formatMoney(p.amount, p.currency)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase">
                      <th className="py-3 px-4">Payment ID</th>
                      <th className="py-3 px-4">Client</th>
                      <th className="py-3 px-4">Service</th>
                      <th className="py-3 px-4 text-right">Amount</th>
                      <th className="py-3 px-4">Method</th>
                      <th className="py-3 px-4">Payment Date</th>
                      <th className="py-3 px-4">Invoice #</th>
                      <th className="py-3 px-4">Reference</th>
                      <th className="py-3 px-4">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredPayments.map((p) => {
                      const c = getClient(p.clientId);
                      return (
                        <tr key={p.id} className="hover:bg-slate-50">
                          <td className="py-3 px-4 font-mono text-xs text-slate-600">
                            {p.paymentCode}
                          </td>
                          <td className="py-3 px-4">
                            <button
                              type="button"
                              onClick={() => openClientProfile(p.clientId)}
                              className="font-medium text-slate-900 hover:underline text-left"
                            >
                              {c?.businessName || c?.fullName || 'Client'}
                            </button>
                          </td>
                          <td className="py-3 px-4">
                            <div className="text-slate-900">{p.serviceName}</div>
                            <div className="text-[11px] text-slate-500">
                              {p.billingType === 'subscription' ? 'Subscription' : 'One-Time'}
                              {p.manuallyVerified ? ' · Manually Verified' : ''}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-right font-mono text-xs font-semibold tabular-nums">
                            {formatMoney(p.amount, p.currency)}
                          </td>
                          <td className="py-3 px-4 text-xs text-slate-600">
                            {formatPaymentMethodLabel(p.paymentMethod)}
                          </td>
                          <td className="py-3 px-4 font-mono text-xs text-slate-600">
                            {p.paymentDate}
                          </td>
                          <td className="py-3 px-4 font-mono text-xs text-slate-900">
                            {p.invoiceNumber || '—'}
                          </td>
                          <td className="py-3 px-4 font-mono text-xs text-slate-500">
                            {p.transactionReference || '—'}
                          </td>
                          <td className="py-3 px-4">
                            <StatusBadge status={p.status} />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </>
          )
        ) : filteredRequests.length === 0 ? (
          <p className="p-10 text-center text-xs text-slate-500">
            No payment requests generated yet.
          </p>
        ) : (
          <>
            <div className="md:hidden divide-y divide-slate-100">
              {filteredRequests.map((req) => {
                const c = getClient(req.clientId);
                return (
                  <div key={req.id} className="p-4 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-[11px] font-mono text-slate-500">{req.reference}</p>
                        <button
                          type="button"
                          onClick={() => openClientProfile(req.clientId)}
                          className="font-semibold text-sm text-slate-900 hover:underline text-left block truncate max-w-full"
                        >
                          {c?.businessName || c?.fullName || 'Client'}
                        </button>
                        <p className="text-xs text-slate-600 truncate">{req.serviceName}</p>
                      </div>
                      <StatusBadge status={req.status} />
                    </div>

                    <div className="flex items-center justify-between text-xs bg-slate-50 border border-slate-100 rounded-lg px-3 py-2">
                      <span className="text-slate-600 font-mono">
                        Due {req.dueDate} · {formatPaymentMethodLabel(req.paymentMethod)}
                      </span>
                      <span className="font-mono font-semibold tabular-nums text-slate-900">
                        {formatMoney(req.amount, req.currency)}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-1.5">
                      {req.paymentUrl && (
                        <>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(req.paymentUrl || '');
                              notify('success', 'Payment link copied.');
                            }}
                            className="min-h-[40px] inline-flex items-center justify-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg"
                          >
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy</span>
                          </button>
                          <a
                            href={req.paymentUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="min-h-[40px] inline-flex items-center justify-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>Open</span>
                          </a>
                        </>
                      )}
                      {req.status === 'pending' && (
                        <>
                          <button
                            type="button"
                            onClick={() => onSendPaymentLinkEmail(req)}
                            className="min-h-[40px] inline-flex items-center justify-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg"
                          >
                            <Mail className="w-3.5 h-3.5" />
                            <span>Email</span>
                          </button>
                          {(req.paymentMethod === 'bank_transfer' ||
                            (req.paymentMethod === 'card' && !req.gatewaySessionId)) && (
                            <button
                              type="button"
                              onClick={() => onVerifyTransfer(req)}
                              className="flex-1 min-h-[40px] inline-flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-medium bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg hover:bg-emerald-100"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Verify</span>
                            </button>
                          )}
                          {req.paymentMethod === 'card' && req.gatewaySessionId && (
                            <button
                              type="button"
                              disabled={verifyingSessionId === req.id}
                              onClick={() => handleVerifyCardSession(req)}
                              className="flex-1 min-h-[40px] inline-flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-medium bg-slate-100 text-slate-800 border border-slate-200 rounded-lg hover:bg-slate-200"
                            >
                              <RefreshCw
                                className={`w-3.5 h-3.5 ${
                                  verifyingSessionId === req.id ? 'animate-spin' : ''
                                }`}
                              />
                              <span>Sync</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleCancelRequest(req)}
                            title="Cancel Payment Request"
                            aria-label="Cancel Payment Request"
                            className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center text-red-600 bg-white border border-red-200 rounded-lg hover:bg-red-50"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase">
                    <th className="py-3 px-4">Reference</th>
                    <th className="py-3 px-4">Client</th>
                    <th className="py-3 px-4">Service</th>
                    <th className="py-3 px-4 text-right">Amount</th>
                    <th className="py-3 px-4">Method</th>
                    <th className="py-3 px-4">Due Date</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredRequests.map((req) => {
                    const c = getClient(req.clientId);
                    return (
                      <tr key={req.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-mono text-xs text-slate-700">
                          {req.reference}
                        </td>
                        <td className="py-3 px-4">
                          <button
                            type="button"
                            onClick={() => openClientProfile(req.clientId)}
                            className="font-medium text-slate-900 hover:underline text-left"
                          >
                            {c?.businessName || c?.fullName || 'Client'}
                          </button>
                        </td>
                        <td className="py-3 px-4 text-slate-900">{req.serviceName}</td>
                        <td className="py-3 px-4 text-right font-mono text-xs font-semibold tabular-nums">
                          {formatMoney(req.amount, req.currency)}
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-600">
                          {formatPaymentMethodLabel(req.paymentMethod)}
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-slate-600">{req.dueDate}</td>
                        <td className="py-3 px-4">
                          <StatusBadge status={req.status} />
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            {req.paymentUrl && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => {
                                    navigator.clipboard.writeText(req.paymentUrl || '');
                                    notify('success', 'Payment link copied.');
                                  }}
                                  title="Copy Payment Link"
                                  className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                                >
                                  <Copy className="w-3.5 h-3.5" />
                                </button>
                                <a
                                  href={req.paymentUrl}
                                  target="_blank"
                                  rel="noreferrer"
                                  title="Open Hosted Payment Page"
                                  className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                                >
                                  <ExternalLink className="w-3.5 h-3.5" />
                                </a>
                              </>
                            )}
                            {req.status === 'pending' && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => onSendPaymentLinkEmail(req)}
                                  title="Send Payment Link via Gmail"
                                  className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                                >
                                  <Mail className="w-3.5 h-3.5" />
                                </button>
                                {(req.paymentMethod === 'bank_transfer' ||
                                  (req.paymentMethod === 'card' && !req.gatewaySessionId)) && (
                                  <button
                                    type="button"
                                    onClick={() => onVerifyTransfer(req)}
                                    title="Verify Received Payment"
                                    className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium bg-emerald-50 text-emerald-800 border border-emerald-200 rounded hover:bg-emerald-100"
                                  >
                                    <CheckCircle2 className="w-3 h-3" />
                                    <span>Verify</span>
                                  </button>
                                )}
                                {req.paymentMethod === 'card' && req.gatewaySessionId && (
                                  <button
                                    type="button"
                                    disabled={verifyingSessionId === req.id}
                                    onClick={() => handleVerifyCardSession(req)}
                                    title="Check Gateway Checkout Status"
                                    className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium bg-slate-100 text-slate-800 border border-slate-200 rounded hover:bg-slate-200"
                                  >
                                    <RefreshCw
                                      className={`w-3 h-3 ${
                                        verifyingSessionId === req.id ? 'animate-spin' : ''
                                      }`}
                                    />
                                    <span>Sync</span>
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => handleCancelRequest(req)}
                                  title="Cancel Payment Request"
                                  className="p-1.5 text-slate-400 hover:text-red-700 rounded"
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
