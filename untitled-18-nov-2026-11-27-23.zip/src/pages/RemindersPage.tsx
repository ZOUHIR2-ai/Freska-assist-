import React, { useMemo, useState } from 'react';
import { Play, RefreshCw, Send, Save } from 'lucide-react';
import { saveEntity } from '../lib/storeClient.ts';
import {
  addDays,
  evaluateAndDispatchReminders,
  generateId,
  logEmailDispatch,
  todayIsoDate,
} from '../lib/billingEngine.ts';
import { isEmailDeliveryAvailable, sendGmailMessage } from '../lib/api.ts';
import { interpolateTemplate } from '../lib/templates.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import { StatusBadge } from '../components/StatusBadge.tsx';
import { ConfirmDialog } from '../components/ConfirmDialog.tsx';
import type { ReminderLogRecord, SubscriptionRecord } from '../types/freska.ts';

export const RemindersPage: React.FC = () => {
  const {
    clients,
    subscriptions,
    payments,
    paymentRequests,
    reminderSettings,
    reminderLogs,
    emailLogs,
    emailTemplates,
    gatewayDbSettings,
    systemSettings,
    emailDeliveryActive,
    notify,
  } = useFreska();

  const [running, setRunning] = useState(false);
  const [confirmRunOpen, setConfirmRunOpen] = useState(false);
  const [editingClientId, setEditingClientId] = useState<string | null>(null);
  const [formEnabled, setFormEnabled] = useState(true);
  const [formBefore, setFormBefore] = useState('3');
  const [formOnDue, setFormOnDue] = useState(true);
  const [formAfter1, setFormAfter1] = useState('3');
  const [formAfter2, setFormAfter2] = useState('7');
  const [savingSetting, setSavingSetting] = useState(false);

  const [manualSubTarget, setManualSubTarget] = useState<SubscriptionRecord | null>(null);
  const [sendingManual, setSendingManual] = useState(false);

  const today = todayIsoDate();

  // Compute upcoming next scheduled reminder for each active subscription
  const scheduledPreviews = useMemo(() => {
    return subscriptions
      .filter((s) => s.status !== 'cancelled' && s.status !== 'paused')
      .map((sub) => {
        const client = clients.find((c) => c.id === sub.clientId);
        const setting = reminderSettings.find((r) => r.clientId === sub.clientId);
        const enabled = sub.reminderEnabled && (setting ? setting.enabled : true);
        const daysBefore = setting?.daysBeforeDue ?? 3;
        const sendOnDue = setting?.sendOnDueDate ?? true;
        const daysAfter1 = setting?.daysAfterDueFirst ?? 3;
        const daysAfter2 = setting?.daysAfterDueSecond ?? 7;

        const cyclePaid = Boolean(sub.lastPaymentDate && sub.lastPaymentDate >= sub.nextPaymentDate);

        let nextDate = '—';
        let nextStage = 'None';
        if (enabled && !cyclePaid) {
          const candidates: Array<{ date: string; label: string }> = [];
          if (daysBefore > 0) {
            candidates.push({
              date: addDays(sub.nextPaymentDate, -daysBefore),
              label: `${daysBefore}d before due`,
            });
          }
          if (sendOnDue) {
            candidates.push({ date: sub.nextPaymentDate, label: 'On due date' });
          }
          if (daysAfter1 > 0) {
            candidates.push({
              date: addDays(sub.nextPaymentDate, daysAfter1),
              label: `${daysAfter1}d overdue`,
            });
          }
          if (daysAfter2 > 0) {
            candidates.push({
              date: addDays(sub.nextPaymentDate, daysAfter2),
              label: `${daysAfter2}d overdue`,
            });
          }
          const upcoming = candidates.find((c) => c.date >= today);
          if (upcoming) {
            nextDate = upcoming.date;
            nextStage = upcoming.label;
          } else {
            nextDate = today;
            nextStage = 'Overdue follow-up';
          }
        } else if (cyclePaid) {
          nextStage = 'Cycle already paid';
        } else {
          nextStage = 'Disabled';
        }

        return {
          sub,
          client,
          enabled,
          nextDate,
          nextStage,
        };
      });
  }, [subscriptions, clients, reminderSettings, today]);

  const sortedLogs = useMemo(
    () =>
      [...reminderLogs].sort((a, b) =>
        (b.sentAt || b.scheduledFor || '').localeCompare(a.sentAt || a.scheduledFor || '')
      ),
    [reminderLogs]
  );

  const openEditClientSettings = (clientId: string) => {
    const existing = reminderSettings.find((r) => r.clientId === clientId);
    setEditingClientId(clientId);
    setFormEnabled(existing ? existing.enabled : true);
    setFormBefore(String(existing?.daysBeforeDue ?? 3));
    setFormOnDue(existing ? existing.sendOnDueDate : true);
    setFormAfter1(String(existing?.daysAfterDueFirst ?? 3));
    setFormAfter2(String(existing?.daysAfterDueSecond ?? 7));
  };

  const handleSaveClientSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingClientId) return;
    setSavingSetting(true);
    try {
      const id = `remset_${editingClientId}`;
      await saveEntity(
        'reminder_settings',
        id,
        {
          id,
          clientId: editingClientId,
          enabled: formEnabled,
          daysBeforeDue: Math.max(0, Number(formBefore) || 0),
          sendOnDueDate: formOnDue,
          daysAfterDueFirst: Math.max(0, Number(formAfter1) || 0),
          daysAfterDueSecond: Math.max(0, Number(formAfter2) || 0),
          customOffsets: [],
        },
        { isNew: true }
      );
      notify('success', 'Client reminder schedule updated.');
      setEditingClientId(null);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to save reminder settings');
    } finally {
      setSavingSetting(false);
    }
  };

  const handleRunReminderEngine = async () => {
    setRunning(true);
    setConfirmRunOpen(false);
    try {
      const res = await evaluateAndDispatchReminders({
        clients,
        subscriptions,
        payments,
        paymentRequests,
        reminderSettings,
        reminderLogs,
        emailLogs,
        templates: emailTemplates,
        gatewaySettings: gatewayDbSettings,
        systemSettings,
      });
      notify(
        res.failed > 0 ? 'error' : 'success',
        `Reminder check complete: ${res.sent} sent, ${res.failed} failed, ${res.skipped} skipped.`
      );
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Reminder evaluation failed');
    } finally {
      setRunning(false);
    }
  };

  const handleManualReminderSend = async () => {
    if (!manualSubTarget) return;
    const client = clients.find((c) => c.id === manualSubTarget.clientId);
    if (!client) return;

    setSendingManual(true);
    try {
      const tpl =
        manualSubTarget.nextPaymentDate < today
          ? emailTemplates.find((t) => t.templateKey === 'overdue_reminder')
          : manualSubTarget.nextPaymentDate === today
          ? emailTemplates.find((t) => t.templateKey === 'payment_due_today')
          : emailTemplates.find((t) => t.templateKey === 'upcoming_reminder');

      const openReq = paymentRequests.find(
        (r) =>
          r.clientId === client.id &&
          r.subscriptionId === manualSubTarget.id &&
          (r.status === 'pending' || r.status === 'overdue')
      );

      const ctx = {
        client_name: client.fullName,
        business_name: client.businessName,
        service_name: manualSubTarget.name,
        amount: manualSubTarget.monthlyPrice.toFixed(2),
        currency: manualSubTarget.currency,
        payment_link: openReq?.paymentUrl || 'Please reply for payment instructions.',
        due_date: manualSubTarget.nextPaymentDate,
        next_payment_date: manualSubTarget.nextPaymentDate,
      };

      const subject = interpolateTemplate(
        tpl?.subject || 'Payment Reminder: {{service_name}}',
        ctx
      );
      const bodyText = interpolateTemplate(
        tpl?.body || 'Hello {{client_name}}, reminder for {{service_name}}.',
        ctx
      );

      const sent = await sendGmailMessage({
        to: client.email,
        subject,
        bodyText,
        senderDisplayName: tpl?.senderDisplayName || 'FreskaAssist Billing',
      });

      const emailLogId = await logEmailDispatch({
        clientId: client.id,
        recipient: client.email,
        subject,
        emailType: 'manual_reminder',
        status: 'sent',
        gmailMessageId: sent.messageId,
      });

      const logId = generateId('rem');
      await saveEntity(
        'reminder_logs',
        logId,
        {
          id: logId,
          clientId: client.id,
          subscriptionId: manualSubTarget.id,
          billingCycleDate: manualSubTarget.nextPaymentDate,
          stage: 'manual',
          emailLogId,
          status: 'sent',
          scheduledFor: today,
          sentAt: new Date().toISOString(),
        },
        { isNew: true }
      );

      notify('success', `Manual reminder sent to ${client.email}.`);
      setManualSubTarget(null);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to send manual reminder');
    } finally {
      setSendingManual(false);
    }
  };

  const handleRetryFailed = async (log: ReminderLogRecord) => {
    if (!isEmailDeliveryAvailable()) {
      notify('error', 'Enable SMTP Relay or authorize Gmail first before retrying failed reminders.');
      return;
    }
    const sub = subscriptions.find((s) => s.id === log.subscriptionId);
    const client = clients.find((c) => c.id === log.clientId);
    if (!sub || !client) return;

    try {
      const tpl = emailTemplates.find((t) => t.templateKey === 'overdue_reminder');
      const subject = interpolateTemplate(tpl?.subject || 'Payment Reminder: {{service_name}}', {
        client_name: client.fullName,
        business_name: client.businessName,
        service_name: sub.name,
        amount: sub.monthlyPrice.toFixed(2),
        currency: sub.currency,
        due_date: sub.nextPaymentDate,
      });
      const bodyText = interpolateTemplate(
        tpl?.body || 'Hello {{client_name}}, your payment is pending.',
        {
          client_name: client.fullName,
          business_name: client.businessName,
          service_name: sub.name,
          amount: sub.monthlyPrice.toFixed(2),
          currency: sub.currency,
          due_date: sub.nextPaymentDate,
        }
      );
      const sent = await sendGmailMessage({
        to: client.email,
        subject,
        bodyText,
        senderDisplayName: tpl?.senderDisplayName || 'FreskaAssist Billing',
      });
      const emailLogId = await logEmailDispatch({
        clientId: client.id,
        recipient: client.email,
        subject,
        emailType: 'reminder_retry',
        status: 'sent',
        gmailMessageId: sent.messageId,
      });
      await saveEntity('reminder_logs', log.id, {
        status: 'sent',
        emailLogId,
        sentAt: new Date().toISOString(),
      });
      notify('success', `Retried reminder sent to ${client.email}.`);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Retry failed');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div>
          <h1 className="text-xl font-semibold text-slate-900">Automated Reminder Engine</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Automatic 2-day onboarding payment links, 1-month subscription renewal &amp; service-pause
            warnings, and duplicate prevention.
          </p>
        </div>

        <button
          type="button"
          disabled={running}
          onClick={() => setConfirmRunOpen(true)}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
        >
          <Play className="w-3.5 h-3.5" />
          <span>{running ? 'Evaluating...' : 'Run Daily Check Now'}</span>
        </button>
      </div>

      {/* Per-Client Independent Settings Editor */}
      {editingClientId && (
        <form
          onSubmit={handleSaveClientSettings}
          className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-4"
        >
          <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <h2 className="text-sm font-semibold text-slate-900 truncate">
              Reminder Rules ·{' '}
              {clients.find((c) => c.id === editingClientId)?.businessName || 'Client'}
            </h2>
            <button
              type="button"
              onClick={() => setEditingClientId(null)}
              className="px-2.5 py-1.5 text-xs text-slate-500 hover:text-slate-900 shrink-0"
            >
              Close
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 items-end">
            <label className="flex items-center gap-2 text-sm text-slate-800 min-h-[44px] sm:min-h-0 sm:pb-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formEnabled}
                onChange={(e) => setFormEnabled(e.target.checked)}
                className="rounded border-slate-300"
              />
              <span>Enabled</span>
            </label>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Days Before Due
              </label>
              <input
                type="number"
                min="0"
                max="90"
                value={formBefore}
                onChange={(e) => setFormBefore(e.target.value)}
                className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg tabular-nums"
              />
            </div>
            <label className="flex items-center gap-2 text-sm text-slate-800 min-h-[44px] sm:min-h-0 sm:pb-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formOnDue}
                onChange={(e) => setFormOnDue(e.target.checked)}
                className="rounded border-slate-300"
              />
              <span>On Due Date</span>
            </label>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                1st Overdue (+Days)
              </label>
              <input
                type="number"
                min="0"
                max="90"
                value={formAfter1}
                onChange={(e) => setFormAfter1(e.target.value)}
                className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                2nd Overdue (+Days)
              </label>
              <input
                type="number"
                min="0"
                max="180"
                value={formAfter2}
                onChange={(e) => setFormAfter2(e.target.value)}
                className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg tabular-nums"
              />
            </div>
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={savingSetting}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-white bg-slate-900 rounded-lg"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{savingSetting ? 'Saving...' : 'Save Schedule'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Scheduled Reminders per Active Subscription */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <h2 className="text-sm font-semibold text-slate-900">
            Subscription Reminder Schedules
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            One-time purchases, paid cycles, paused subscriptions, and cancelled plans never trigger
            automated reminders.
          </p>
        </div>
        {scheduledPreviews.length === 0 ? (
          <p className="p-8 text-center text-xs text-slate-500">
            No active subscriptions to schedule.
          </p>
        ) : (
          <>
            <div className="md:hidden divide-y divide-slate-100">
              {scheduledPreviews.map(({ sub, client, enabled, nextDate, nextStage }) => (
                <div key={sub.id} className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900 truncate">
                        {client?.businessName || 'Client'}
                      </p>
                      <p className="text-xs text-slate-600 truncate mt-0.5">{sub.name}</p>
                    </div>
                    <StatusBadge status={enabled ? 'active' : 'paused'} />
                  </div>
                  <div className="grid grid-cols-2 gap-2 p-2.5 bg-slate-50 rounded-lg text-xs">
                    <div>
                      <p className="text-[10px] uppercase text-slate-500 font-semibold">Due Date</p>
                      <p className="font-mono tabular-nums text-slate-800 mt-0.5">
                        {sub.nextPaymentDate}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase text-slate-500 font-semibold">
                        Next Reminder
                      </p>
                      <p className="text-slate-800 mt-0.5 truncate">
                        <span className="font-mono tabular-nums">{nextDate}</span> · {nextStage}
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => client && openEditClientSettings(client.id)}
                      className="min-h-[40px] px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                    >
                      Configure
                    </button>
                    <button
                      type="button"
                      disabled={!emailDeliveryActive}
                      onClick={() => setManualSubTarget(sub)}
                      className="min-h-[40px] inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-40"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Send Manual</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase">
                    <th className="py-3 px-4">Client</th>
                    <th className="py-3 px-4">Subscription</th>
                    <th className="py-3 px-4">Due Date</th>
                    <th className="py-3 px-4">Next Scheduled Reminder</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {scheduledPreviews.map(({ sub, client, enabled, nextDate, nextStage }) => (
                    <tr key={sub.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-medium text-slate-900">
                        {client?.businessName || 'Client'}
                      </td>
                      <td className="py-3 px-4 text-slate-800">{sub.name}</td>
                      <td className="py-3 px-4 font-mono text-xs text-slate-600">
                        {sub.nextPaymentDate}
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-700">
                        <span className="font-mono">{nextDate}</span> · {nextStage}
                      </td>
                      <td className="py-3 px-4">
                        <StatusBadge status={enabled ? 'active' : 'paused'} />
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => client && openEditClientSettings(client.id)}
                            className="px-2.5 py-1 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded hover:bg-slate-50"
                          >
                            Configure
                          </button>
                          <button
                            type="button"
                            disabled={!emailDeliveryActive}
                            onClick={() => setManualSubTarget(sub)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-white bg-slate-900 rounded hover:bg-slate-800 disabled:opacity-40"
                          >
                            <Send className="w-3 h-3" />
                            <span>Send Manual</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      {/* Reminder History Log */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-4 sm:px-5 py-4 border-b border-slate-200">
          <h2 className="text-sm font-semibold text-slate-900">Reminder Dispatch History</h2>
        </div>
        {sortedLogs.length === 0 ? (
          <p className="p-8 text-center text-xs text-slate-500">No reminders dispatched yet.</p>
        ) : (
          <>
            <div className="md:hidden divide-y divide-slate-100">
              {sortedLogs.map((log) => {
                const c = clients.find((item) => item.id === log.clientId);
                return (
                  <div key={log.id} className="p-4 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-900 truncate">
                          {c?.businessName || log.clientId}
                        </p>
                        <p className="text-xs font-mono text-slate-600 mt-0.5">{log.stage}</p>
                      </div>
                      <StatusBadge status={log.status} />
                    </div>
                    <div className="flex items-center justify-between gap-2 text-[11px] text-slate-500 font-mono tabular-nums">
                      <span>Cycle: {log.billingCycleDate}</span>
                      <span>{(log.sentAt || log.scheduledFor || '').slice(0, 10)}</span>
                    </div>
                    {log.status === 'failed' ? (
                      <button
                        type="button"
                        onClick={() => handleRetryFailed(log)}
                        className="w-full min-h-[40px] inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium bg-amber-50 text-amber-900 border border-amber-200 rounded-lg hover:bg-amber-100"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>Retry Send</span>
                      </button>
                    ) : (
                      <p className="text-[11px] text-slate-500 break-words">
                        {log.errorMessage || 'Delivered'}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase">
                    <th className="py-3 px-4">Client</th>
                    <th className="py-3 px-4">Billing Cycle</th>
                    <th className="py-3 px-4">Stage</th>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Details / Retry</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {sortedLogs.map((log) => {
                    const c = clients.find((item) => item.id === log.clientId);
                    return (
                      <tr key={log.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-medium text-slate-900">
                          {c?.businessName || log.clientId}
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-slate-600">
                          {log.billingCycleDate}
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-700 font-mono">{log.stage}</td>
                        <td className="py-3 px-4 font-mono text-xs text-slate-600">
                          {(log.sentAt || log.scheduledFor || '').slice(0, 10)}
                        </td>
                        <td className="py-3 px-4">
                          <StatusBadge status={log.status} />
                        </td>
                        <td className="py-3 px-4 text-right text-xs">
                          {log.status === 'failed' ? (
                            <button
                              type="button"
                              onClick={() => handleRetryFailed(log)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-amber-50 text-amber-900 border border-amber-200 rounded hover:bg-amber-100"
                            >
                              <RefreshCw className="w-3 h-3" />
                              <span>Retry</span>
                            </button>
                          ) : (
                            <span className="text-slate-500">{log.errorMessage || 'Delivered'}</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      <ConfirmDialog
        open={confirmRunOpen}
        variant="gmail"
        title="Run Automated Reminder Check"
        description="Evaluate all eligible active/overdue subscriptions and send due payment reminders via your connected Gmail account?"
        confirmLabel="Run Reminder Check"
        busy={running}
        onConfirm={handleRunReminderEngine}
        onCancel={() => setConfirmRunOpen(false)}
      />

      <ConfirmDialog
        open={Boolean(manualSubTarget)}
        variant="gmail"
        title="Send Manual Payment Reminder"
        description={`Send a payment reminder email via Gmail for "${manualSubTarget?.name}"?`}
        confirmLabel="Send Reminder"
        busy={sendingManual}
        onConfirm={handleManualReminderSend}
        onCancel={() => setManualSubTarget(null)}
      />
    </div>
  );
};
