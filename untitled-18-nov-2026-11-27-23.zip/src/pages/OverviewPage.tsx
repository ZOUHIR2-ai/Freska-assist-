import React, { useMemo } from 'react';
import { ArrowUpRight, AlertCircle, CalendarClock, Mail } from 'lucide-react';
import { useFreska } from '../context/FreskaContext.tsx';
import { addDays, formatMoney, todayIsoDate } from '../lib/billingEngine.ts';
import { StatusBadge } from '../components/StatusBadge.tsx';
import type { NavSection } from '../types/freska.ts';

interface OverviewPageProps {
  onNavigate: (section: NavSection) => void;
  onOpenPaymentLink: () => void;
  onOpenManualPayment: () => void;
}

export const OverviewPage: React.FC<OverviewPageProps> = ({
  onNavigate,
  onOpenPaymentLink,
  onOpenManualPayment,
}) => {
  const {
    clients,
    subscriptions,
    payments,
    paymentRequests,
    invoices,
    emailLogs,
    systemSettings,
    openClientProfile,
  } = useFreska();

  const today = todayIsoDate();
  const currentMonth = today.slice(0, 7);
  const next14Days = addDays(today, 14);
  const currency = systemSettings.defaultCurrency || 'EUR';

  const stats = useMemo(() => {
    const nonArchivedClients = clients.filter((c) => c.status !== 'archived');
    const activeClients = clients.filter((c) => c.status === 'active');
    const activeSubs = subscriptions.filter((s) => s.status === 'active');

    const paidPayments = payments.filter((p) => p.status === 'paid');
    const totalRevenue = paidPayments.reduce((sum, p) => sum + Number(p.amount || 0), 0);
    const monthlyRevenue = paidPayments
      .filter((p) => p.paymentDate.startsWith(currentMonth))
      .reduce((sum, p) => sum + Number(p.amount || 0), 0);

    const pendingReqs = paymentRequests.filter((r) => r.status === 'pending');
    const pendingPaymentsCount =
      pendingReqs.length + payments.filter((p) => p.status === 'pending').length;
    const pendingAmount =
      pendingReqs.reduce((s, r) => s + Number(r.amount || 0), 0) +
      payments
        .filter((p) => p.status === 'pending')
        .reduce((s, p) => s + Number(p.amount || 0), 0);

    const overdueSubs = subscriptions.filter((s) => s.status === 'overdue');
    const overdueReqs = paymentRequests.filter(
      (r) => r.status === 'overdue' || (r.status === 'pending' && r.dueDate < today)
    );
    const overdueCount = overdueSubs.length + overdueReqs.length;

    const upcomingSubs = subscriptions.filter(
      (s) =>
        (s.status === 'active' || s.status === 'pending') &&
        s.nextPaymentDate >= today &&
        s.nextPaymentDate <= next14Days
    );

    const oneTimeCount = paidPayments.filter((p) => p.billingType === 'one_time').length;
    const oneTimeAmount = paidPayments
      .filter((p) => p.billingType === 'one_time')
      .reduce((s, p) => s + Number(p.amount || 0), 0);

    return {
      totalClients: nonArchivedClients.length,
      activeClients: activeClients.length,
      activeSubscriptions: activeSubs.length,
      totalRevenue,
      monthlyRevenue,
      pendingPaymentsCount,
      pendingAmount,
      overdueCount,
      upcomingCount: upcomingSubs.length,
      oneTimeCount,
      oneTimeAmount,
      upcomingSubs: upcomingSubs.sort((a, b) => a.nextPaymentDate.localeCompare(b.nextPaymentDate)),
      overdueSubs,
    };
  }, [clients, subscriptions, payments, paymentRequests, currentMonth, today, next14Days]);

  // Build 6-month revenue series strictly from confirmed paid payments
  const monthlySeries = useMemo(() => {
    const months: Array<{ key: string; label: string; total: number }> = [];
    const base = new Date();
    for (let i = 5; i >= 0; i -= 1) {
      const d = new Date(Date.UTC(base.getUTCFullYear(), base.getUTCMonth() - i, 1));
      const key = d.toISOString().slice(0, 7);
      const label = d.toLocaleDateString('en-US', { month: 'short', timeZone: 'UTC' });
      const total = payments
        .filter((p) => p.status === 'paid' && p.paymentDate.startsWith(key))
        .reduce((sum, p) => sum + Number(p.amount || 0), 0);
      months.push({ key, label, total });
    }
    const maxVal = Math.max(...months.map((m) => m.total), 1);
    return { months, maxVal };
  }, [payments]);

  const recentPayments = useMemo(
    () => [...payments].sort((a, b) => b.paymentDate.localeCompare(a.paymentDate)).slice(0, 5),
    [payments]
  );

  const recentInvoices = useMemo(
    () => [...invoices].sort((a, b) => b.invoiceDate.localeCompare(a.invoiceDate)).slice(0, 5),
    [invoices]
  );

  const recentEmails = useMemo(
    () =>
      [...emailLogs]
        .sort((a, b) => (b.sentAt || '').localeCompare(a.sentAt || ''))
        .slice(0, 5),
    [emailLogs]
  );

  const getClientName = (clientId: string) => {
    const c = clients.find((item) => item.id === clientId);
    return c ? c.businessName || c.fullName : 'Unknown Client';
  };

  return (
    <div className="space-y-6">
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div>
          <h1 className="text-xl font-semibold text-slate-900">Financial & Operations Overview</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Live metrics calculated from verified client, subscription, payment, and invoice records.
          </p>
        </div>
        <div className="grid grid-cols-2 sm:flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={onOpenManualPayment}
            className="min-h-[44px] sm:min-h-0 px-3 sm:px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 whitespace-nowrap shrink-0 text-center"
          >
            Register Payment
          </button>
          <button
            type="button"
            onClick={onOpenPaymentLink}
            className="min-h-[44px] sm:min-h-0 px-3 sm:px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg whitespace-nowrap shrink-0 text-center"
          >
            Create Payment Link
          </button>
        </div>
      </div>

      {/* 9-Metric KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500">Total Revenue</p>
          <p className="text-2xl font-semibold text-slate-900 mt-1.5 tabular-nums font-mono">
            {formatMoney(stats.totalRevenue, currency)}
          </p>
          <p className="text-xs text-slate-500 mt-2">
            Monthly Revenue: <span className="font-mono tabular-nums text-slate-800">{formatMoney(stats.monthlyRevenue, currency)}</span>
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500">Clients & Subscriptions</p>
          <p className="text-2xl font-semibold text-slate-900 mt-1.5 tabular-nums font-mono">
            {stats.activeClients} <span className="text-sm font-sans font-normal text-slate-500">active / {stats.totalClients} total</span>
          </p>
          <p className="text-xs text-slate-500 mt-2">
            Active Subscriptions: <span className="font-mono tabular-nums text-slate-800">{stats.activeSubscriptions}</span>
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500">Receivables & One-Time</p>
          <div className="flex items-baseline gap-4 mt-1.5">
            <div>
              <span className="text-2xl font-semibold text-slate-900 tabular-nums font-mono">
                {stats.pendingPaymentsCount}
              </span>
              <span className="text-xs text-slate-500 ml-1">pending</span>
            </div>
            <div>
              <span className="text-2xl font-semibold text-red-700 tabular-nums font-mono">
                {stats.overdueCount}
              </span>
              <span className="text-xs text-slate-500 ml-1">overdue</span>
            </div>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Upcoming (14d): <span className="font-mono tabular-nums text-slate-800">{stats.upcomingCount}</span> · One-Time:{' '}
            <span className="font-mono tabular-nums text-slate-800">{stats.oneTimeCount} ({formatMoney(stats.oneTimeAmount, currency)})</span>
          </p>
        </div>
      </div>

      {/* Monthly Revenue Chart + Overdue Clients */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-4 sm:p-6">
          <div className="flex items-center justify-between gap-2 mb-6">
            <div>
              <h2 className="text-sm font-semibold text-slate-900">Monthly Revenue</h2>
              <p className="text-xs text-slate-500">Confirmed payments over the last 6 months</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('payments')}
              className="inline-flex items-center gap-1 text-xs font-medium text-slate-700 hover:text-slate-900 shrink-0 min-h-[36px]"
            >
              <span>Financial Ledger</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-48 flex items-end gap-2 sm:gap-4 pt-4 border-b border-slate-100 pb-2">
            {monthlySeries.months.map((m) => {
              const heightPct = m.total > 0 ? Math.max((m.total / monthlySeries.maxVal) * 100, 8) : 4;
              return (
                <div key={m.key} className="flex-1 min-w-0 flex flex-col items-center gap-2 h-full justify-end">
                  <span className="text-[10px] sm:text-[11px] font-mono tabular-nums text-slate-600 truncate max-w-full">
                    {m.total > 0 ? formatMoney(m.total, currency) : '—'}
                  </span>
                  <div className="w-full max-w-[48px] bg-slate-100 rounded-t-md h-32 flex items-end overflow-hidden">
                    <div
                      className={`w-full rounded-t-md transition-all ${
                        m.total > 0 ? 'bg-slate-900' : 'bg-slate-200'
                      }`}
                      style={{ height: `${heightPct}%` }}
                    />
                  </div>
                  <span className="text-xs text-slate-500 font-medium">{m.label}</span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600" />
              <h2 className="text-sm font-semibold text-slate-900">Overdue Balances</h2>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('reminders')}
              className="text-xs font-medium text-slate-600 hover:text-slate-900"
            >
              Reminders
            </button>
          </div>

          {stats.overdueSubs.length === 0 ? (
            <div className="flex-1 flex items-center justify-center text-center py-8 text-xs text-slate-500">
              No clients currently have overdue subscription balances.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {stats.overdueSubs.slice(0, 5).map((sub) => (
                <button
                  key={sub.id}
                  type="button"
                  onClick={() => openClientProfile(sub.clientId)}
                  className="w-full py-3 flex items-center justify-between text-left hover:bg-slate-50 rounded px-2 -mx-2 transition-colors"
                >
                  <div className="min-w-0 pr-3">
                    <p className="text-sm font-medium text-slate-900 truncate">
                      {getClientName(sub.clientId)}
                    </p>
                    <p className="text-xs text-slate-500 truncate">
                      {sub.name} · Due {sub.nextPaymentDate}
                    </p>
                  </div>
                  <span className="text-xs font-mono font-semibold text-red-700 tabular-nums shrink-0">
                    {formatMoney(sub.monthlyPrice, sub.currency)}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Bottom 2x2 Operational Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Payments */}
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-900">Recent Payments</h2>
            <button
              type="button"
              onClick={() => onNavigate('payments')}
              className="text-xs font-medium text-slate-600 hover:text-slate-900"
            >
              View All
            </button>
          </div>
          {recentPayments.length === 0 ? (
            <p className="p-6 text-xs text-slate-500 text-center">No payments recorded yet.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentPayments.map((p) => (
                <div
                  key={p.id}
                  className="px-4 sm:px-5 py-3 flex items-center justify-between gap-3 hover:bg-slate-50"
                >
                  <div className="min-w-0 flex-1">
                    <button
                      type="button"
                      onClick={() => openClientProfile(p.clientId)}
                      className="text-sm font-medium text-slate-900 hover:underline truncate block"
                    >
                      {getClientName(p.clientId)}
                    </button>
                    <p className="text-xs text-slate-500 truncate">
                      {p.serviceName} · {p.paymentDate}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-xs font-mono font-medium text-slate-900 tabular-nums">
                      {formatMoney(p.amount, p.currency)}
                    </span>
                    <StatusBadge status={p.status} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Invoices */}
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-900">Recent Invoices</h2>
            <button
              type="button"
              onClick={() => onNavigate('invoices')}
              className="text-xs font-medium text-slate-600 hover:text-slate-900"
            >
              View All
            </button>
          </div>
          {recentInvoices.length === 0 ? (
            <p className="p-6 text-xs text-slate-500 text-center">
              Invoices appear automatically once payments are confirmed.
            </p>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentInvoices.map((inv) => (
                <div
                  key={inv.id}
                  className="px-5 py-3 flex items-center justify-between gap-3 hover:bg-slate-50"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-900 font-mono truncate">
                      {inv.invoiceNumber}
                    </p>
                    <p className="text-xs text-slate-500 truncate">
                      {inv.businessName || inv.clientName} · {inv.invoiceDate}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-xs font-mono font-medium text-slate-900 tabular-nums">
                      {formatMoney(inv.amount, inv.currency)}
                    </span>
                    <StatusBadge status={inv.status} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Upcoming Payment Dates */}
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CalendarClock className="w-4 h-4 text-slate-500" />
              <h2 className="text-sm font-semibold text-slate-900">Upcoming Payment Dates (14 Days)</h2>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('subscriptions')}
              className="text-xs font-medium text-slate-600 hover:text-slate-900"
            >
              Subscriptions
            </button>
          </div>
          {stats.upcomingSubs.length === 0 ? (
            <p className="p-6 text-xs text-slate-500 text-center">
              No subscription renewals scheduled in the next 14 days.
            </p>
          ) : (
            <div className="divide-y divide-slate-100">
              {stats.upcomingSubs.slice(0, 5).map((sub) => (
                <div
                  key={sub.id}
                  className="px-5 py-3 flex items-center justify-between gap-3 hover:bg-slate-50"
                >
                  <div className="min-w-0">
                    <button
                      type="button"
                      onClick={() => openClientProfile(sub.clientId)}
                      className="text-sm font-medium text-slate-900 hover:underline truncate block"
                    >
                      {getClientName(sub.clientId)}
                    </button>
                    <p className="text-xs text-slate-500 truncate">{sub.name}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs font-mono font-medium text-slate-900 tabular-nums">
                      {formatMoney(sub.monthlyPrice, sub.currency)}
                    </p>
                    <p className="text-[11px] font-mono text-slate-500">{sub.nextPaymentDate}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Email Activity */}
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-slate-500" />
              <h2 className="text-sm font-semibold text-slate-900">Recent Email Activity</h2>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('email_center')}
              className="text-xs font-medium text-slate-600 hover:text-slate-900"
            >
              Email Center
            </button>
          </div>
          {recentEmails.length === 0 ? (
            <p className="p-6 text-xs text-slate-500 text-center">No Gmail emails dispatched yet.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentEmails.map((em) => (
                <div
                  key={em.id}
                  className="px-4 sm:px-5 py-3 flex items-center justify-between gap-3 hover:bg-slate-50"
                >
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-slate-900 truncate">{em.subject}</p>
                    <p className="text-xs text-slate-500 truncate">
                      To: {em.recipient} · {em.sentAt ? em.sentAt.slice(0, 10) : 'Pending'}
                    </p>
                  </div>
                  <StatusBadge status={em.status} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
