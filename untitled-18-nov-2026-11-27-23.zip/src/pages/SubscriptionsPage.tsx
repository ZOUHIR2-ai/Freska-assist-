import React, { useMemo, useState } from 'react';
import { Plus, Pause, Play, XCircle, Edit2, Link2, Trash2 } from 'lucide-react';
import { saveEntity, deleteEntity } from '../lib/storeClient.ts';
import {
  formatMoney,
  formatPaymentMethodLabel,
  generateId,
} from '../lib/billingEngine.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import { StatusBadge } from '../components/StatusBadge.tsx';
import { ConfirmDialog } from '../components/ConfirmDialog.tsx';
import type { BillingType, ServiceRecord, SubscriptionRecord } from '../types/freska.ts';

interface SubscriptionsPageProps {
  onAddSubscription: () => void;
  onEditSubscription: (sub: SubscriptionRecord) => void;
  onGeneratePaymentLink: (clientId: string, subscriptionId: string) => void;
}

export const SubscriptionsPage: React.FC<SubscriptionsPageProps> = ({
  onAddSubscription,
  onEditSubscription,
  onGeneratePaymentLink,
}) => {
  const { subscriptions, services, clients, systemSettings, openClientProfile, notify } =
    useFreska();

  const [tab, setTab] = useState<'subscriptions' | 'services'>('subscriptions');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [cancelTarget, setCancelTarget] = useState<SubscriptionRecord | null>(null);
  const [busyCancel, setBusyCancel] = useState(false);

  // Service catalog form state
  const [svcName, setSvcName] = useState('');
  const [svcDesc, setSvcDesc] = useState('');
  const [svcType, setSvcType] = useState<BillingType>('subscription');
  const [svcPrice, setSvcPrice] = useState('');
  const [svcCurrency, setSvcCurrency] = useState(systemSettings.defaultCurrency || 'EUR');
  const [savingSvc, setSavingSvc] = useState(false);

  const filteredSubs = useMemo(() => {
    return subscriptions.filter((s) => {
      if (statusFilter !== 'all' && s.status !== statusFilter) return false;
      return true;
    });
  }, [subscriptions, statusFilter]);

  const getClient = (clientId: string) => clients.find((c) => c.id === clientId);

  const handleTogglePause = async (sub: SubscriptionRecord) => {
    const nextStatus = sub.status === 'paused' ? 'active' : 'paused';
    try {
      await saveEntity('subscriptions', sub.id, { status: nextStatus });
      notify(
        'success',
        `Subscription "${sub.name}" ${nextStatus === 'paused' ? 'paused' : 'resumed'}.`
      );
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to update subscription');
    }
  };

  const handleCancelSubscription = async () => {
    if (!cancelTarget) return;
    setBusyCancel(true);
    try {
      await saveEntity('subscriptions', cancelTarget.id, {
        status: 'cancelled',
        reminderEnabled: false,
        autoRenew: false,
      });
      notify(
        'success',
        `Subscription "${cancelTarget.name}" cancelled. All historical payments and invoices remain preserved.`
      );
      setCancelTarget(null);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to cancel subscription');
    } finally {
      setBusyCancel(false);
    }
  };

  const handleCreateService = async (e: React.FormEvent) => {
    e.preventDefault();
    const priceNum = Number(svcPrice);
    if (!svcName.trim() || Number.isNaN(priceNum) || priceNum < 0) {
      notify('error', 'Enter a valid service name and price.');
      return;
    }
    setSavingSvc(true);
    try {
      const id = generateId('svc');
      await saveEntity(
        'services',
        id,
        {
          id,
          name: svcName.trim(),
          description: svcDesc.trim(),
          billingType: svcType,
          defaultPrice: priceNum,
          currency: svcCurrency,
          active: true,
        },
        { isNew: true }
      );
      setSvcName('');
      setSvcDesc('');
      setSvcPrice('');
      notify('success', `Service "${svcName.trim()}" added to catalog.`);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to create service');
    } finally {
      setSavingSvc(false);
    }
  };

  const handleDeleteService = async (svc: ServiceRecord) => {
    try {
      await deleteEntity('services', svc.id);
      notify('success', `Service "${svc.name}" removed.`);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to delete service');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div>
          <h1 className="text-xl font-semibold text-slate-900">Subscriptions & Services</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Manage recurring billing cycles, pause/resume plans, and maintain your service catalog.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row sm:items-center gap-2 w-full sm:w-auto">
          <div className="grid grid-cols-2 sm:flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg">
            <button
              type="button"
              onClick={() => setTab('subscriptions')}
              className={`min-h-[38px] sm:min-h-0 px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap ${
                tab === 'subscriptions' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Subscriptions ({subscriptions.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('services')}
              className={`min-h-[38px] sm:min-h-0 px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap ${
                tab === 'services' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Service Catalog ({services.length})
            </button>
          </div>
          {tab === 'subscriptions' && (
            <button
              type="button"
              onClick={onAddSubscription}
              className="w-full sm:w-auto min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Subscription</span>
            </button>
          )}
        </div>
      </div>

      {tab === 'subscriptions' ? (
        <>
          <div className="w-full sm:w-fit overflow-x-auto bg-white border border-slate-200 rounded-xl p-1">
            <div className="flex items-center gap-1 min-w-max">
              {(['all', 'active', 'pending', 'unpaid', 'overdue', 'paused', 'cancelled'] as const).map(
                (st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setStatusFilter(st)}
                    className={`min-h-[38px] sm:min-h-0 px-3 py-1.5 text-xs font-medium rounded-lg capitalize whitespace-nowrap ${
                      statusFilter === st
                        ? 'bg-slate-900 text-white'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {st}
                  </button>
                )
              )}
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            {filteredSubs.length === 0 ? (
              <div className="p-8 sm:p-12 text-center space-y-2">
                <p className="text-sm font-medium text-slate-900">No subscriptions found</p>
                <p className="text-xs text-slate-500">
                  Create a recurring subscription to automate next payment tracking and reminders.
                </p>
              </div>
            ) : (
              <>
                <div className="md:hidden divide-y divide-slate-100">
                  {filteredSubs.map((sub) => {
                    const c = getClient(sub.clientId);
                    return (
                      <div key={sub.id} className="p-4 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <button
                              type="button"
                              onClick={() => openClientProfile(sub.clientId)}
                              className="font-semibold text-sm text-slate-900 hover:underline text-left block truncate max-w-full"
                            >
                              {c?.businessName || c?.fullName || 'Client'}
                            </button>
                            <p className="text-xs text-slate-600 truncate">
                              {sub.name} · <span className="capitalize">{sub.billingFrequency}</span>
                            </p>
                          </div>
                          <StatusBadge status={sub.status} />
                        </div>

                        <div className="grid grid-cols-3 gap-2 bg-slate-50 border border-slate-100 rounded-lg p-2.5 text-xs">
                          <div>
                            <p className="text-[11px] text-slate-500">Price</p>
                            <p className="font-mono font-semibold tabular-nums text-slate-900 mt-0.5">
                              {formatMoney(sub.monthlyPrice, sub.currency)}
                            </p>
                          </div>
                          <div>
                            <p className="text-[11px] text-slate-500">Next Due</p>
                            <p className="font-mono text-slate-900 mt-0.5">
                              {sub.status === 'cancelled' ? 'Cancelled' : sub.nextPaymentDate}
                            </p>
                          </div>
                          <div>
                            <p className="text-[11px] text-slate-500">Method</p>
                            <p className="text-slate-700 truncate mt-0.5">
                              {formatPaymentMethodLabel(sub.paymentMethod)}
                            </p>
                          </div>
                        </div>

                        {sub.status !== 'cancelled' && (
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => onGeneratePaymentLink(sub.clientId, sub.id)}
                              className="flex-1 min-h-[40px] inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
                            >
                              <Link2 className="w-3.5 h-3.5" />
                              <span>Pay Link</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleTogglePause(sub)}
                              title={sub.status === 'paused' ? 'Resume Subscription' : 'Pause Subscription'}
                              aria-label={sub.status === 'paused' ? 'Resume Subscription' : 'Pause Subscription'}
                              className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg"
                            >
                              {sub.status === 'paused' ? (
                                <Play className="w-3.5 h-3.5" />
                              ) : (
                                <Pause className="w-3.5 h-3.5" />
                              )}
                            </button>
                            <button
                              type="button"
                              onClick={() => onEditSubscription(sub)}
                              title="Edit Subscription"
                              aria-label="Edit Subscription"
                              className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setCancelTarget(sub)}
                              title="Cancel Subscription"
                              aria-label="Cancel Subscription"
                              className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center text-red-600 bg-white border border-red-200 hover:bg-red-50 rounded-lg"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                <div className="hidden md:block overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase">
                        <th className="py-3 px-4">Client</th>
                        <th className="py-3 px-4">Service</th>
                        <th className="py-3 px-4 text-right">Monthly Price</th>
                        <th className="py-3 px-4">Start Date</th>
                        <th className="py-3 px-4">Last Payment</th>
                        <th className="py-3 px-4">Next Payment</th>
                        <th className="py-3 px-4">Method</th>
                        <th className="py-3 px-4">Status</th>
                        <th className="py-3 px-4">Reminders</th>
                        <th className="py-3 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredSubs.map((sub) => {
                        const c = getClient(sub.clientId);
                        return (
                          <tr key={sub.id} className="hover:bg-slate-50">
                            <td className="py-3 px-4">
                              <button
                                type="button"
                                onClick={() => openClientProfile(sub.clientId)}
                                className="font-medium text-slate-900 hover:underline text-left"
                              >
                                {c?.businessName || c?.fullName || 'Client'}
                              </button>
                            </td>
                            <td className="py-3 px-4">
                              <div className="font-medium text-slate-900">{sub.name}</div>
                              <div className="text-[11px] text-slate-500 capitalize">
                                {sub.billingFrequency}
                              </div>
                            </td>
                            <td className="py-3 px-4 text-right font-mono text-xs font-semibold tabular-nums">
                              {formatMoney(sub.monthlyPrice, sub.currency)}
                            </td>
                            <td className="py-3 px-4 font-mono text-xs text-slate-600">
                              {sub.startDate}
                            </td>
                            <td className="py-3 px-4 font-mono text-xs text-slate-600">
                              {sub.lastPaymentDate || '—'}
                            </td>
                            <td className="py-3 px-4 font-mono text-xs text-slate-900 font-medium">
                              {sub.status === 'cancelled' ? 'Cancelled' : sub.nextPaymentDate}
                            </td>
                            <td className="py-3 px-4 text-xs text-slate-600">
                              {formatPaymentMethodLabel(sub.paymentMethod)}
                            </td>
                            <td className="py-3 px-4">
                              <StatusBadge status={sub.status} />
                            </td>
                            <td className="py-3 px-4 text-xs text-slate-600">
                              {sub.reminderEnabled ? 'Enabled' : 'Disabled'}
                            </td>
                            <td className="py-3 px-4 text-right whitespace-nowrap">
                              <div className="inline-flex items-center gap-1">
                                {sub.status !== 'cancelled' && (
                                  <>
                                    <button
                                      type="button"
                                      onClick={() => onGeneratePaymentLink(sub.clientId, sub.id)}
                                      title="Generate Payment Link for Cycle"
                                      className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                                    >
                                      <Link2 className="w-3.5 h-3.5" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleTogglePause(sub)}
                                      title={
                                        sub.status === 'paused'
                                          ? 'Resume Subscription'
                                          : 'Pause Subscription'
                                      }
                                      className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                                    >
                                      {sub.status === 'paused' ? (
                                        <Play className="w-3.5 h-3.5" />
                                      ) : (
                                        <Pause className="w-3.5 h-3.5" />
                                      )}
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => onEditSubscription(sub)}
                                      title="Edit Subscription"
                                      className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                                    >
                                      <Edit2 className="w-3.5 h-3.5" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => setCancelTarget(sub)}
                                      title="Cancel Subscription"
                                      className="p-1.5 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded"
                                    >
                                      <XCircle className="w-3.5 h-3.5" />
                                    </button>
                                  </>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        </>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <form
            onSubmit={handleCreateService}
            className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-4 h-fit"
          >
            <h2 className="text-sm font-semibold text-slate-900">Add Service to Catalog</h2>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Service Name *
              </label>
              <input
                type="text"
                required
                value={svcName}
                onChange={(e) => setSvcName(e.target.value)}
                placeholder="Growth Retainer Plan"
                className="w-full min-h-[44px] sm:min-h-0 px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Billing Type
                </label>
                <select
                  value={svcType}
                  onChange={(e) => setSvcType(e.target.value as BillingType)}
                  className="w-full min-h-[44px] sm:min-h-0 px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="subscription">Subscription</option>
                  <option value="one_time">One-Time</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Default Price *
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  value={svcPrice}
                  onChange={(e) => setSvcPrice(e.target.value)}
                  className="w-full min-h-[44px] sm:min-h-0 px-3 py-2 text-sm border border-slate-300 rounded-lg tabular-nums"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Currency</label>
              <select
                value={svcCurrency}
                onChange={(e) => setSvcCurrency(e.target.value)}
                className="w-full min-h-[44px] sm:min-h-0 px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                <option value="EUR">EUR</option>
                <option value="USD">USD</option>
                <option value="GBP">GBP</option>
                <option value="CAD">CAD</option>
                <option value="MAD">MAD</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Description</label>
              <textarea
                rows={2}
                value={svcDesc}
                onChange={(e) => setSvcDesc(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <button
              type="submit"
              disabled={savingSvc}
              className="w-full min-h-[44px] sm:min-h-0 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
            >
              {savingSvc ? 'Adding...' : 'Add Service'}
            </button>
          </form>

          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl overflow-hidden">
            {services.length === 0 ? (
              <p className="p-8 text-center text-xs text-slate-500">
                No catalog services defined yet. Add reusable services on the left.
              </p>
            ) : (
              <>
                <div className="md:hidden divide-y divide-slate-100">
                  {services.map((svc) => (
                    <div key={svc.id} className="p-4 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-900 truncate">{svc.name}</p>
                        {svc.description && (
                          <p className="text-xs text-slate-500 line-clamp-2">{svc.description}</p>
                        )}
                        <p className="text-xs font-mono text-slate-600 mt-1 tabular-nums">
                          {svc.billingType === 'subscription' ? 'Subscription' : 'One-Time'} ·{' '}
                          {formatMoney(svc.defaultPrice, svc.currency)}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDeleteService(svc)}
                        aria-label="Delete Service"
                        className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center text-red-600 border border-red-200 rounded-lg hover:bg-red-50 shrink-0"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="hidden md:block overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase">
                        <th className="py-3 px-4">Service</th>
                        <th className="py-3 px-4">Billing Type</th>
                        <th className="py-3 px-4 text-right">Default Price</th>
                        <th className="py-3 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {services.map((svc) => (
                        <tr key={svc.id} className="hover:bg-slate-50">
                          <td className="py-3 px-4">
                            <div className="font-medium text-slate-900">{svc.name}</div>
                            {svc.description && (
                              <div className="text-xs text-slate-500">{svc.description}</div>
                            )}
                          </td>
                          <td className="py-3 px-4 text-xs text-slate-600">
                            {svc.billingType === 'subscription' ? 'Subscription' : 'One-Time'}
                          </td>
                          <td className="py-3 px-4 text-right font-mono text-xs font-semibold tabular-nums">
                            {formatMoney(svc.defaultPrice, svc.currency)}
                          </td>
                          <td className="py-3 px-4 text-right">
                            <button
                              type="button"
                              onClick={() => handleDeleteService(svc)}
                              className="p-1.5 text-slate-400 hover:text-red-700 rounded"
                              title="Delete Service"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      <ConfirmDialog
        open={Boolean(cancelTarget)}
        variant="danger"
        title="Cancel Subscription"
        description={`Cancel "${cancelTarget?.name}"? Automated reminders for this subscription will stop immediately, while all historical payments and invoices remain intact.`}
        confirmLabel="Confirm Cancellation"
        busy={busyCancel}
        onConfirm={handleCancelSubscription}
        onCancel={() => setCancelTarget(null)}
      />
    </div>
  );
};
