import React, { useEffect, useState } from 'react';
import {
  CreditCard,
  Landmark,
  Copy,
  Check,
  CheckCircle2,
  ShieldCheck,
  AlertCircle,
  Lock,
} from 'lucide-react';
import { formatMoney } from '../lib/billingEngine.ts';
import { StatusBadge } from '../components/StatusBadge.tsx';

interface BankSnapshot {
  requestId: string;
  reference: string;
  clientId?: string;
  subscriptionId?: string;
  billingType?: 'subscription' | 'one_time';
  clientName: string;
  businessName: string;
  serviceName: string;
  description: string;
  amount: number;
  currency: string;
  dueDate: string;
  status: string;
  bankAccountName: string;
  bankName: string;
  bankIban: string;
  bankBic: string;
  bankInstructions: string;
  companyName: string;
  paidAt?: string;
  paidMethod?: 'bank_transfer' | 'card' | 'manual';
  transactionReference?: string;
  testMode?: boolean;
  clientReportedTransfer?: boolean;
  clientReportedAt?: string;
  clientTransferNote?: string;
  cardGateway?: {
    liveEnabled: boolean;
    testModeAvailable: boolean;
  };
}

function formatCardNumberInput(raw: string): string {
  const digits = raw.replace(/\D/g, '').slice(0, 16);
  return digits.replace(/(.{4})/g, '$1 ').trim();
}

function formatExpiryInput(raw: string): string {
  const digits = raw.replace(/\D/g, '').slice(0, 4);
  if (digits.length <= 2) return digits;
  return `${digits.slice(0, 2)}/${digits.slice(2)}`;
}

export const PublicBankRequestPage: React.FC<{
  requestId: string;
  signature: string;
}> = ({ requestId, signature }) => {
  const [data, setData] = useState<BankSnapshot | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeMethod, setActiveMethod] = useState<'card' | 'bank'>('card');
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Test Card Checkout form state
  const [cardholderName, setCardholderName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  const [checkoutBusy, setCheckoutBusy] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);

  // Bank transfer report state
  const [transferNote, setTransferNote] = useState('');
  const [reportingTransfer, setReportingTransfer] = useState(false);

  useEffect(() => {
    fetch(
      `/api/public/bank-request/${encodeURIComponent(requestId)}?sig=${encodeURIComponent(
        signature
      )}`
    )
      .then(async (res) => {
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || 'Unable to load payment details.');
        const snap = json as BankSnapshot;
        setData(snap);
        setCardholderName(snap.clientName || snap.businessName || '');
        if (snap.bankIban && !snap.cardGateway?.liveEnabled) {
          setActiveMethod('card');
        }
      })
      .catch((err) => {
        setError(err instanceof Error ? err.message : 'Unable to load payment details.');
      })
      .finally(() => setLoading(false));
  }, [requestId, signature]);

  const handleCopy = (fieldKey: string, value: string) => {
    if (!value) return;
    navigator.clipboard.writeText(value);
    setCopiedField(fieldKey);
    setTimeout(() => setCopiedField(null), 1800);
  };

  const handleFillTestCard = () => {
    if (!cardholderName.trim() && data) {
      setCardholderName(data.clientName || data.businessName || 'Test Client');
    }
    setCardNumber('4242 4242 4242 4242');
    setCardExpiry('12/28');
    setCardCvc('424');
    setCheckoutError(null);
  };

  const handleTestCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!data) return;
    const digits = cardNumber.replace(/\D/g, '');
    if (!cardholderName.trim() || digits.length < 12 || cardExpiry.length < 4 || cardCvc.length < 3) {
      setCheckoutError('Enter card details or click "Fill Test Card (4242)" to complete test checkout.');
      return;
    }

    setCheckoutBusy(true);
    setCheckoutError(null);
    try {
      const res = await fetch(
        `/api/public/bank-request/${encodeURIComponent(requestId)}/test-checkout?sig=${encodeURIComponent(
          signature
        )}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            cardholderName: cardholderName.trim(),
            cardLast4: digits.slice(-4),
          }),
        }
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Test checkout failed.');
      if (json.snapshot) {
        setData((prev) => ({ ...(json.snapshot as BankSnapshot), cardGateway: prev?.cardGateway }));
      }
    } catch (err) {
      setCheckoutError(err instanceof Error ? err.message : 'Test checkout failed.');
    } finally {
      setCheckoutBusy(false);
    }
  };

  const handleLiveCheckout = async () => {
    setCheckoutBusy(true);
    setCheckoutError(null);
    try {
      const res = await fetch(
        `/api/public/bank-request/${encodeURIComponent(requestId)}/live-checkout?sig=${encodeURIComponent(
          signature
        )}`,
        { method: 'POST' }
      );
      const json = await res.json();
      if (!res.ok || !json.checkoutUrl) {
        throw new Error(json.error || 'Unable to launch card checkout.');
      }
      window.location.href = json.checkoutUrl;
    } catch (err) {
      setCheckoutError(err instanceof Error ? err.message : 'Unable to launch card checkout.');
      setCheckoutBusy(false);
    }
  };

  const handleReportTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    setReportingTransfer(true);
    try {
      const res = await fetch(
        `/api/public/bank-request/${encodeURIComponent(requestId)}/report-transfer?sig=${encodeURIComponent(
          signature
        )}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ note: transferNote }),
        }
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed to record transfer confirmation.');
      if (json.snapshot) {
        setData((prev) => ({ ...(json.snapshot as BankSnapshot), cardGateway: prev?.cardGateway }));
      }
    } catch (err) {
      setCheckoutError(err instanceof Error ? err.message : 'Failed to record transfer confirmation.');
    } finally {
      setReportingTransfer(false);
    }
  };

  const isPaid = data?.status === 'paid';
  const liveCardEnabled = Boolean(data?.cardGateway?.liveEnabled);

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-2.5 sm:p-6">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        {/* Header */}
        <div className="px-4 sm:px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-white">
          <div className="flex items-center gap-3 min-w-0">
            <div className="bg-black rounded-lg px-2.5 py-1.5 inline-flex items-center shrink-0">
              <img
                src="/assets/aistudio/IMG-20261117-WA0014_9dd05831.jpg"
                alt={data?.companyName || 'FreskaAssist'}
                className="h-6 w-auto object-contain"
              />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-slate-900 truncate">
                {data?.companyName || 'FreskaAssist'}
              </p>
              <p className="text-xs text-slate-500 truncate">
                Client Payment Portal · Bank Transfer &amp; Card
              </p>
            </div>
          </div>
          {data && <StatusBadge status={data.status} />}
        </div>

        <div className="p-4 sm:p-6">
          {loading && <p className="text-sm text-slate-600">Loading payment details...</p>}
          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {data && (
            <div className="space-y-6">
              {/* Amount & Invoice Summary */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <p className="text-xs text-slate-500">
                    {data.billingType === 'subscription' ? 'Monthly Subscription' : 'One-Time Payment'}
                  </p>
                  <p className="text-2xl font-semibold font-mono tabular-nums text-slate-900 mt-0.5">
                    {formatMoney(data.amount, data.currency)}
                  </p>
                </div>
                <div className="text-left sm:text-right text-xs space-y-1">
                  <p className="text-slate-500">
                    Due Date: <span className="font-mono font-medium text-slate-900">{data.dueDate}</span>
                  </p>
                  <p className="text-slate-500">
                    Reference: <span className="font-mono font-semibold text-slate-900 break-all">{data.reference}</span>
                  </p>
                </div>
              </div>

              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs border-b border-slate-100 pb-4">
                <div>
                  <dt className="text-slate-500">Client / Business</dt>
                  <dd className="font-medium text-slate-900 mt-0.5">
                    {data.businessName || data.clientName}
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">Service</dt>
                  <dd className="font-medium text-slate-900 mt-0.5">{data.serviceName}</dd>
                  {data.description && (
                    <p className="text-[11px] text-slate-500 mt-0.5">{data.description}</p>
                  )}
                </div>
              </dl>

              {isPaid ? (
                /* Confirmed Receipt View */
                <div className="p-5 bg-emerald-50 border border-emerald-200 rounded-xl space-y-3">
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                    <div>
                      <h2 className="text-sm font-semibold text-emerald-950">
                        Payment Confirmed{data.testMode ? ' (Test Checkout Mode)' : ''}
                      </h2>
                      <p className="text-xs text-emerald-800 mt-0.5">
                        Thank you. This payment has been recorded and your official invoice is being
                        prepared.
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-emerald-200/70 text-xs">
                    <div>
                      <p className="text-emerald-700">Payment Method</p>
                      <p className="font-medium text-emerald-950 mt-0.5">
                        {data.paidMethod === 'card'
                          ? data.testMode
                            ? 'Card (Test Checkout)'
                            : 'Credit / Debit Card'
                          : 'Bank Transfer'}
                      </p>
                    </div>
                    <div>
                      <p className="text-emerald-700">Transaction Reference</p>
                      <p className="font-mono font-medium text-emerald-950 mt-0.5">
                        {data.transactionReference || data.reference}
                      </p>
                    </div>
                    <div>
                      <p className="text-emerald-700">Confirmed At</p>
                      <p className="font-mono font-medium text-emerald-950 mt-0.5">
                        {data.paidAt ? data.paidAt.slice(0, 16).replace('T', ' ') : 'Recorded'}
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                /* Payment Method Selector + Forms */
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-1.5 sm:gap-2 p-1 bg-slate-100 rounded-lg">
                    <button
                      type="button"
                      onClick={() => {
                        setActiveMethod('card');
                        setCheckoutError(null);
                      }}
                      className={`flex items-center justify-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-2.5 min-h-[44px] text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                        activeMethod === 'card'
                          ? 'bg-white text-slate-900 shadow-sm'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <CreditCard className="w-4 h-4 shrink-0" />
                      <span>{liveCardEnabled ? 'Pay by Card' : 'Test Card'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setActiveMethod('bank');
                        setCheckoutError(null);
                      }}
                      className={`flex items-center justify-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-2.5 min-h-[44px] text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                        activeMethod === 'bank'
                          ? 'bg-white text-slate-900 shadow-sm'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <Landmark className="w-4 h-4 shrink-0" />
                      <span>Bank Transfer</span>
                    </button>
                  </div>

                  {checkoutError && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-800 flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>{checkoutError}</span>
                    </div>
                  )}

                  {activeMethod === 'card' ? (
                    liveCardEnabled ? (
                      <div className="p-4 sm:p-5 bg-slate-50 border border-slate-200 rounded-xl space-y-4">
                        <div className="flex items-start gap-2.5 text-xs text-slate-700">
                          <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                          <span>
                            You will be redirected to our encrypted card processor to complete your{' '}
                            <strong className="font-mono">
                              {formatMoney(data.amount, data.currency)}
                            </strong>{' '}
                            payment securely.
                          </span>
                        </div>
                        <button
                          type="button"
                          disabled={checkoutBusy}
                          onClick={handleLiveCheckout}
                          className="w-full py-3 sm:py-2.5 min-h-[44px] px-4 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
                        >
                          {checkoutBusy
                            ? 'Opening Checkout...'
                            : `Pay ${formatMoney(data.amount, data.currency)} by Card`}
                        </button>
                      </div>
                    ) : (
                      <form
                        onSubmit={handleTestCheckout}
                        className="p-4 sm:p-5 bg-slate-50 border border-slate-200 rounded-xl space-y-4"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200">
                          <div className="flex items-start gap-2 text-xs text-amber-900">
                            <Lock className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                            <span>
                              <strong>Test Checkout Mode</strong> — Live payment gateway is not yet
                              linked. Test card simulation records confirmation immediately without
                              charging real funds.
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={handleFillTestCard}
                            className="px-3 py-1.5 min-h-[36px] text-[11px] font-medium bg-white border border-slate-300 rounded-md hover:bg-slate-100 text-slate-800 whitespace-nowrap"
                          >
                            Fill Test Card (4242)
                          </button>
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-slate-700 mb-1">
                            Cardholder Name
                          </label>
                          <input
                            type="text"
                            required
                            value={cardholderName}
                            onChange={(e) => setCardholderName(e.target.value)}
                            placeholder="Full name on card"
                            className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm bg-white border border-slate-300 rounded-lg"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-slate-700 mb-1">
                            Card Number
                          </label>
                          <input
                            type="text"
                            inputMode="numeric"
                            required
                            value={cardNumber}
                            onChange={(e) => setCardNumber(formatCardNumberInput(e.target.value))}
                            placeholder="4242 4242 4242 4242"
                            className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm font-mono bg-white border border-slate-300 rounded-lg"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-medium text-slate-700 mb-1">
                              Expiry (MM/YY)
                            </label>
                            <input
                              type="text"
                              inputMode="numeric"
                              required
                              value={cardExpiry}
                              onChange={(e) => setCardExpiry(formatExpiryInput(e.target.value))}
                              placeholder="12/28"
                              className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm font-mono bg-white border border-slate-300 rounded-lg"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-slate-700 mb-1">
                              CVC
                            </label>
                            <input
                              type="text"
                              inputMode="numeric"
                              required
                              maxLength={4}
                              value={cardCvc}
                              onChange={(e) =>
                                setCardCvc(e.target.value.replace(/\D/g, '').slice(0, 4))
                              }
                              placeholder="424"
                              className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm font-mono bg-white border border-slate-300 rounded-lg"
                            />
                          </div>
                        </div>

                        <button
                          type="submit"
                          disabled={checkoutBusy}
                          className="w-full py-3 sm:py-2.5 min-h-[44px] px-4 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
                        >
                          {checkoutBusy
                            ? 'Processing Test Checkout...'
                            : `Complete Test Payment (${formatMoney(data.amount, data.currency)})`}
                        </button>
                      </form>
                    )
                  ) : (
                    /* Bank Transfer (Virement) Tab */
                    <div className="space-y-4">
                      {!data.bankIban && (
                        <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-start gap-2">
                          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-700" />
                          <span>
                            Bank IBAN details are not configured yet. You may use the{' '}
                            <button
                              type="button"
                              onClick={() => setActiveMethod('card')}
                              className="underline font-semibold"
                            >
                              Card Checkout
                            </button>{' '}
                            tab or contact {data.companyName} for transfer details.
                          </span>
                        </div>
                      )}

                      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl divide-y divide-slate-200/70 text-xs">
                        {[
                          { key: 'holder', label: 'Beneficiary', val: data.bankAccountName || '—', mono: false },
                          { key: 'bank', label: 'Bank Name', val: data.bankName || '—', mono: false },
                          { key: 'iban', label: 'IBAN / Account', val: data.bankIban || '—', mono: true },
                          { key: 'bic', label: 'BIC / SWIFT', val: data.bankBic || '—', mono: true },
                          { key: 'ref', label: 'Payment Reference', val: data.reference, mono: true },
                        ].map((row) => (
                          <div
                            key={row.key}
                            className="py-2.5 first:pt-0 last:pb-0 flex items-start sm:items-center justify-between gap-3"
                          >
                            <span className="text-slate-500 shrink-0 pt-0.5 sm:pt-0">
                              {row.label}
                            </span>
                            <div className="flex items-center justify-end gap-2 min-w-0 flex-1">
                              <span
                                className={`text-slate-900 font-medium break-all text-right ${
                                  row.mono ? 'font-mono' : ''
                                }`}
                              >
                                {row.val}
                              </span>
                              {row.val && row.val !== '—' && (
                                <button
                                  type="button"
                                  onClick={() => handleCopy(row.key, row.val)}
                                  className="p-2 min-h-[36px] min-w-[36px] inline-flex items-center justify-center text-slate-500 hover:text-slate-900 rounded hover:bg-slate-200/60 shrink-0"
                                  title={`Copy ${row.label}`}
                                >
                                  {copiedField === row.key ? (
                                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                                  ) : (
                                    <Copy className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>

                      {data.bankInstructions && (
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {data.bankInstructions}
                        </p>
                      )}

                      {data.clientReportedTransfer ? (
                        <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-900 flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                          <div>
                            <p className="font-medium">Transfer Notification Recorded</p>
                            <p className="text-blue-800 mt-0.5">
                              Reported on{' '}
                              {data.clientReportedAt
                                ? data.clientReportedAt.slice(0, 16).replace('T', ' ')
                                : 'today'}
                              . Your invoice will be issued once funds are verified.
                            </p>
                          </div>
                        </div>
                      ) : (
                        <form
                          onSubmit={handleReportTransfer}
                          className="p-4 border border-slate-200 rounded-xl space-y-3 bg-white"
                        >
                          <p className="text-xs font-medium text-slate-800">
                            Already sent your bank transfer? Let us know so we can verify faster:
                          </p>
                          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                            <input
                              type="text"
                              value={transferNote}
                              onChange={(e) => setTransferNote(e.target.value)}
                              placeholder="Optional bank transfer reference or note..."
                              className="w-full sm:flex-1 min-w-0 px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs border border-slate-300 rounded-lg"
                            />
                            <button
                              type="submit"
                              disabled={reportingTransfer}
                              className="w-full sm:w-auto px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50 whitespace-nowrap"
                            >
                              {reportingTransfer ? 'Recording...' : 'I Have Sent This Transfer'}
                            </button>
                          </div>
                        </form>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
