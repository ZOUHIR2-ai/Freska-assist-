import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  Edit2,
  Link2,
  CreditCard,
  Mail,
  FileText,
  Bell,
  Download,
  Eye,
  Repeat,
} from 'lucide-react';
import { useFreska } from '../context/FreskaContext.tsx';
import {
  assignClientBillingPlan,
  computeClientFinancials,
  formatMoney,
  formatPaymentMethodLabel,
} from '../lib/billingEngine.ts';
import { fetchInvoicePdfBlob } from '../lib/api.ts';
import { StatusBadge } from '../components/StatusBadge.tsx';
import { ConfirmDialog } from '../components/ConfirmDialog.tsx';
import type { ClientRecord, InvoiceRecord } from '../types/freska.ts';

interface ClientProfilePageProps {
  clientId: string;
  onBack: () => void;
  onEditClient: (client: ClientRecord) => void;
  onCreatePaymentLink: (clientId: string, subscriptionId?: string) => void;
  onRegisterManualPayment: (clientId: string, subscriptionId?: string) => void;
  onSendEmail: (client: ClientRecord, invoice?: InvoiceRecord) => void;
  onPreviewInvoice: (invoice: InvoiceRecord) => void;
  onManageReminders: () => void;
}

export const ClientProfilePage: React.FC<ClientProfilePageProps> = ({
  clientId,
  onBack,
  onEditClient,
  onCreatePaymentLink,
  onRegisterManualPayment,
  onSendEmail,
  onPreviewInvoice,
  onManageReminders,
}) => {
  const {
    clients,
    subscriptions,
    payments,
    paymentRequests,
    invoices,
    emailLogs,
    reminderSettings,
    gatewayDbSettings,
    gatewayServerStatus,
    systemSettings,
    notify,
  } = useFreska();

  const [activeTab, setActiveTab] = useState<'payments' | 'invoices' | 'emails'>('payments');
  const [switchPlanTarget, setSwitchPlanTarget] = useState<'subscription' | 'one_time' | null>(null);
  const [assigningPlan, setAssigningPlan] = useState(false);

  const client = clients.find((c) => c.id === clientId);
  const cardPaymentsActive = Boolean(
    gatewayServerStatus?.enabled && gatewayServerStatus?.connectionVerified
  );

  const clientPayments = useMemo(
    () =>
      payments
        .filter((p) => p.clientId === clientId)
        .sort((a, b) => b.paymentDate.localeCompare(a.paymentDate)),
    [payments, clientId]
  );

  const clientInvoices = useMemo(
    () =>
      invoices
        .filter((i) => i.clientId === clientId)
        .sort((a, b) => b.invoiceDate.localeCompare(a.invoiceDate)),
    [invoices, clientId]
  );

  const clientEmails = useMemo(
    () =>
      emailLogs
        .filter((e) => e.clientId === clientId || (client && e.recipient === client.email))
        .sort((a, b) => (b.sentAt || '').localeCompare(a.sentAt || '')),
    [emailLogs, clientId, client]
  );

  if (!client) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-8 text-center space-y-3">
        <p className="text-sm font-medium text-slate-900">Client record not found.</p>
        <button
          type="button"
          onClick={onBack}
          className="px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg"
        >
          Back to Clients
        </button>
      </div>
    );
  }

  const financials = computeClientFinancials(
    client.id,
    subscriptions,
    payments,
    paymentRequests
  );
  const remSetting = reminderSettings.find((r) => r.clientId === client.id);
  const reminderEnabled = remSetting ? remSetting.enabled : true;

  const executePlanAssignment = async (planType: 'subscription' | 'one_time') => {
    setAssigningPlan(true);
    try {
      const assigned = await assignClientBillingPlan({
        client,
        planType,
        currency: 'EUR',
        paymentMethod: client.preferredPaymentMethod || 'bank_transfer',
        existingSubscriptions: subscriptions,
        existingPaymentRequests: paymentRequests,
        gatewaySettings: gatewayDbSettings,
        systemSettings,
        cardPaymentsActive,
      });
      notify(
        'success',
        `${client.businessName} set to ${
          assigned.mode === 'subscription'
            ? `Subscription (${assigned.amount} ${assigned.currency}/mo)`
            : `One-Time Payment (${assigned.amount} ${assigned.currency})`
        }.`
      );
      setSwitchPlanTarget(null);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to update client billing plan');
    } finally {
      setAssigningPlan(false);
    }
  };

  const handlePlanButtonClick = (targetMode: 'subscription' | 'one_time') => {
    if (financials.billingMode === targetMode) return;
    if (financials.billingMode && financials.billingMode !== targetMode) {
      setSwitchPlanTarget(targetMode);
      return;
    }
    executePlanAssignment(targetMode);
  };

  const handleDownloadInvoice = async (inv: InvoiceRecord) => {
    try {
      const linkedPayment = payments.find((p) => p.id === inv.paymentId);
      const blob = await fetchInvoicePdfBlob({
        invoiceNumber: inv.invoiceNumber,
        invoiceDate: inv.invoiceDate,
        paymentDate: inv.paymentDate,
        status: inv.status,
        clientName: inv.clientName,
        businessName: inv.businessName || inv.clientName,
        clientEmail: inv.clientEmail,
        serviceName: inv.serviceName,
        serviceDescription: inv.serviceDescription || '',
        paymentType: inv.paymentType,
        paymentMethod: inv.paymentMethod,
        paymentReference: inv.paymentReference || '',
        manuallyVerified: linkedPayment?.manuallyVerified ?? false,
        amount: inv.amount,
        currency: inv.currency,
        companyName: systemSettings.businessName || 'FreskaAssist',
        companyAddress: systemSettings.companyAddress || '',
        companyEmail: systemSettings.adminEmail || '',
        taxId: systemSettings.taxId || '',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `FreskaAssist-${inv.invoiceNumber}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to download PDF');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Action Bar */}
      <div className="flex flex-col gap-4">
        <div className="flex items-start gap-3">
          <button
            type="button"
            onClick={onBack}
            className="min-h-[44px] min-w-[44px] sm:min-h-0 sm:min-w-0 p-2 bg-white border border-slate-200 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-50 flex items-center justify-center shrink-0"
            aria-label="Back to clients"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl font-semibold text-slate-900 break-words">
                {client.businessName || client.fullName}
              </h1>
              <StatusBadge status={client.status} />
            </div>
            <p className="text-xs text-slate-500 mt-0.5 font-mono break-all">
              {client.clientCode} · {client.fullName} · {client.email}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => onEditClient(client)}
            className="min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50 text-slate-700 whitespace-nowrap"
          >
            <Edit2 className="w-3.5 h-3.5" />
            <span>Edit Client</span>
          </button>
          <button
            type="button"
            onClick={() => onCreatePaymentLink(client.id, financials.activeSub?.id)}
            className="min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50 text-slate-700 whitespace-nowrap"
          >
            <Link2 className="w-3.5 h-3.5" />
            <span>Payment Link</span>
          </button>
          <button
            type="button"
            onClick={() => onRegisterManualPayment(client.id, financials.activeSub?.id)}
            className="col-span-2 sm:col-span-1 min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium bg-slate-900 text-white rounded-lg hover:bg-slate-800 whitespace-nowrap"
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Register Manual Payment</span>
          </button>
          <button
            type="button"
            onClick={() => onSendEmail(client)}
            className="min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50 text-slate-700 whitespace-nowrap"
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Send Email</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('invoices')}
            className="min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50 text-slate-700 whitespace-nowrap"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>View Invoices</span>
          </button>
          <button
            type="button"
            onClick={onManageReminders}
            className="col-span-2 sm:col-span-1 min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50 text-slate-700 whitespace-nowrap"
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Manage Reminders</span>
          </button>
        </div>
      </div>

      {/* Individual Financial Profile & Client Metadata */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <h2 className="text-sm font-semibold text-slate-900 border-b border-slate-100 pb-2.5">
            Client Details
          </h2>
          <dl className="space-y-2.5 text-xs">
            <div className="flex justify-between gap-4">
              <dt className="text-slate-500">Client ID</dt>
              <dd className="font-mono text-slate-900">{client.clientCode}</dd>
            </div>
            <div className="flex justify-between gap-4">
              <dt className="text-slate-500">Full Name</dt>
              <dd className="font-medium text-slate-900 text-right">{client.fullName}</dd>
            </div>
            <div className="flex justify-between gap-4">
              <dt className="text-slate-500">Business Name</dt>
              <dd className="font-medium text-slate-900 text-right">{client.businessName}</dd>
            </div>
            <div className="flex justify-between gap-4">
              <dt className="text-slate-500">Email</dt>
              <dd className="text-slate-900 text-right truncate">{client.email}</dd>
            </div>
            <div className="flex justify-between gap-4">
              <dt className="text-slate-500">Phone</dt>
              <dd className="text-slate-900 text-right">{client.phone || '—'}</dd>
            </div>
            <div className="flex justify-between gap-4">
              <dt className="text-slate-500">Business Type</dt>
              <dd className="text-slate-900 text-right">{client.businessType || '—'}</dd>
            </div>
            <div className="flex justify-between gap-4">
              <dt className="text-slate-500">Services Purchased</dt>
              <dd className="text-slate-900 text-right">
                {client.servicesPurchased && client.servicesPurchased.length > 0
                  ? client.servicesPurchased.join(', ')
                  : '—'}
              </dd>
            </div>
          </dl>
          {client.notes && (
            <div className="pt-3 border-t border-slate-100">
              <p className="text-[11px] font-medium text-slate-500 mb-1">Internal Notes</p>
              <p className="text-xs text-slate-700 whitespace-pre-wrap">{client.notes}</p>
            </div>
          )}
        </div>

        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-sm font-semibold text-slate-900">Financial Profile & Billing Package</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Reminders: <strong className="text-slate-900">{reminderEnabled ? 'Enabled' : 'Disabled'}</strong>
              </p>
            </div>

            {/* 1-Click Per-Client Package Assignment (Subscription 599€ OR One-Time 1,199€) */}
            <div className="grid grid-cols-2 sm:flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg w-full sm:w-auto">
              <button
                type="button"
                disabled={assigningPlan}
                onClick={() => handlePlanButtonClick('subscription')}
                className={`min-h-[40px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  financials.billingMode === 'subscription'
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'text-slate-700 hover:bg-white'
                }`}
              >
                <Repeat className="w-3.5 h-3.5 shrink-0" />
                <span>Subscription · 599€</span>
              </button>
              <button
                type="button"
                disabled={assigningPlan}
                onClick={() => handlePlanButtonClick('one_time')}
                className={`min-h-[40px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  financials.billingMode === 'one_time'
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'text-slate-700 hover:bg-white'
                }`}
              >
                <CreditCard className="w-3.5 h-3.5 shrink-0" />
                <span>One-Time · 1,199€</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <p className="text-xs text-slate-500">Total Paid</p>
              <p className="text-lg font-semibold font-mono tabular-nums text-slate-900 mt-1">
                {formatMoney(financials.totalPaid, financials.currency)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Outstanding Balance</p>
              <p
                className={`text-lg font-semibold font-mono tabular-nums mt-1 ${
                  financials.outstandingBalance > 0 ? 'text-red-700' : 'text-slate-900'
                }`}
              >
                {formatMoney(financials.outstandingBalance, financials.currency)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">
                {financials.billingMode === 'one_time' ? 'One-Time Price' : 'Monthly Price'}
              </p>
              <p className="text-lg font-semibold font-mono tabular-nums text-slate-900 mt-1">
                {financials.activeSub
                  ? formatMoney(financials.monthlyRate, financials.currency)
                  : financials.billingMode === 'one_time'
                  ? formatMoney(financials.oneTimeAmount, financials.currency)
                  : '—'}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Payment Method</p>
              <p className="text-sm font-medium text-slate-900 mt-1.5">
                {formatPaymentMethodLabel(financials.paymentMethod)}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-100 text-xs">
            <div>
              <p className="text-slate-500">Billing Plan</p>
              <div className="mt-1 flex items-center gap-2">
                {financials.billingMode === 'subscription' && financials.activeSub ? (
                  <>
                    <span className="font-medium text-slate-900">
                      {financials.activeSub.name}
                    </span>
                    <StatusBadge status={financials.activeSub.status} />
                  </>
                ) : financials.billingMode === 'one_time' ? (
                  <>
                    <span className="font-medium text-slate-900">One-Time Payment</span>
                    <StatusBadge
                      status={
                        financials.openOneTimeRequest
                          ? financials.openOneTimeRequest.status
                          : financials.latestOneTimePayment
                          ? 'paid'
                          : 'pending'
                      }
                    />
                  </>
                ) : (
                  <span className="font-medium text-slate-500">No billing plan assigned</span>
                )}
              </div>
            </div>
            <div>
              <p className="text-slate-500">Last Payment Date</p>
              <p className="font-mono text-slate-900 mt-1">
                {financials.lastPaymentDate || 'No payment yet'}
              </p>
            </div>
            <div>
              <p className="text-slate-500">
                {financials.billingMode === 'one_time' ? 'Payment Due Date' : 'Next Payment Date'}
              </p>
              <p className="font-mono text-slate-900 mt-1">
                {financials.nextPaymentDate || 'N/A'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabbed History Tables */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-4 sm:px-6 py-3 border-b border-slate-200 flex items-center gap-2 bg-slate-50 overflow-x-auto">
          {(
            [
              { id: 'payments', label: `Payment History (${clientPayments.length})` },
              { id: 'invoices', label: `Invoice History (${clientInvoices.length})` },
              { id: 'emails', label: `Email History (${clientEmails.length})` },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setActiveTab(t.id)}
              className={`min-h-[38px] sm:min-h-0 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                activeTab === t.id
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {activeTab === 'payments' && (
          <div>
            {clientPayments.length === 0 ? (
              <p className="p-8 text-center text-xs text-slate-500">
                No payment transactions recorded for this client yet.
              </p>
            ) : (
              <>
                <div className="md:hidden divide-y divide-slate-100">
                  {clientPayments.map((p) => (
                    <div key={p.id} className="p-4 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="text-xs font-mono text-slate-500">
                            {p.paymentCode} {p.invoiceNumber ? `· ${p.invoiceNumber}` : ''}
                          </p>
                          <p className="text-sm font-medium text-slate-900 truncate">{p.serviceName}</p>
                        </div>
                        <StatusBadge status={p.status} />
                      </div>
                      <div className="flex items-center justify-between text-xs pt-1">
                        <span className="text-slate-500 font-mono">
                          {p.paymentDate} · {formatPaymentMethodLabel(p.paymentMethod)}
                        </span>
                        <span className="font-mono font-semibold tabular-nums text-slate-900">
                          {formatMoney(p.amount, p.currency)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="hidden md:block overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase">
                        <th className="py-3 px-4">Payment ID</th>
                        <th className="py-3 px-4">Invoice #</th>
                        <th className="py-3 px-4">Service</th>
                        <th className="py-3 px-4 text-right">Amount</th>
                        <th className="py-3 px-4">Method</th>
                        <th className="py-3 px-4">Payment Date</th>
                        <th className="py-3 px-4">Reference</th>
                        <th className="py-3 px-4">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {clientPayments.map((p) => (
                        <tr key={p.id} className="hover:bg-slate-50">
                          <td className="py-3 px-4 font-mono text-xs text-slate-600">{p.paymentCode}</td>
                          <td className="py-3 px-4 font-mono text-xs text-slate-900">
                            {p.invoiceNumber || '—'}
                          </td>
                          <td className="py-3 px-4 text-slate-900">
                            <div>{p.serviceName}</div>
                            <div className="text-[11px] text-slate-500">
                              {p.billingType === 'subscription' ? 'Subscription' : 'One-Time'}
                              {p.manuallyVerified ? ' · Manually Verified' : ''}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-right font-mono text-xs font-semibold tabular-nums">
                            {formatMoney(p.amount, p.currency)}
                          </td>
                          <td className="py-3 px-4 text-xs text-slate-600">
                            {formatPaymentMethodLabel(p.paymentMethod)}
                          </td>
                          <td className="py-3 px-4 font-mono text-xs text-slate-600">{p.paymentDate}</td>
                          <td className="py-3 px-4 font-mono text-xs text-slate-600">
                            {p.transactionReference || '—'}
                          </td>
                          <td className="py-3 px-4">
                            <StatusBadge status={p.status} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        )}

        {activeTab === 'invoices' && (
          <div>
            {clientInvoices.length === 0 ? (
              <p className="p-8 text-center text-xs text-slate-500">
                No invoices generated for this client yet.
              </p>
            ) : (
              <>
                <div className="md:hidden divide-y divide-slate-100">
                  {clientInvoices.map((inv) => (
                    <div key={inv.id} className="p-4 space-y-2.5">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="text-xs font-mono font-semibold text-slate-900">
                            {inv.invoiceNumber}
                          </p>
                          <p className="text-sm text-slate-800 truncate">{inv.serviceName}</p>
                        </div>
                        <StatusBadge status={inv.status} />
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-mono text-slate-500">{inv.invoiceDate}</span>
                        <span className="font-mono font-semibold tabular-nums text-slate-900">
                          {formatMoney(inv.amount, inv.currency)}
                        </span>
                      </div>
                      <div className="grid grid-cols-3 gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => onPreviewInvoice(inv)}
                          className="min-h-[40px] inline-flex items-center justify-center gap-1 px-2 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Preview</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDownloadInvoice(inv)}
                          className="min-h-[40px] inline-flex items-center justify-center gap-1 px-2 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>PDF</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onSendEmail(client, inv)}
                          className="min-h-[40px] inline-flex items-center justify-center gap-1 px-2 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
                        >
                          <Mail className="w-3.5 h-3.5" />
                          <span>Email</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="hidden md:block overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase">
                        <th className="py-3 px-4">Invoice Number</th>
                        <th className="py-3 px-4">Service</th>
                        <th className="py-3 px-4">Invoice Date</th>
                        <th className="py-3 px-4 text-right">Amount</th>
                        <th className="py-3 px-4">Status</th>
                        <th className="py-3 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {clientInvoices.map((inv) => (
                        <tr key={inv.id} className="hover:bg-slate-50">
                          <td className="py-3 px-4 font-mono text-xs font-medium text-slate-900">
                            {inv.invoiceNumber}
                          </td>
                          <td className="py-3 px-4 text-slate-900">{inv.serviceName}</td>
                          <td className="py-3 px-4 font-mono text-xs text-slate-600">
                            {inv.invoiceDate}
                          </td>
                          <td className="py-3 px-4 text-right font-mono text-xs font-semibold tabular-nums">
                            {formatMoney(inv.amount, inv.currency)}
                          </td>
                          <td className="py-3 px-4">
                            <StatusBadge status={inv.status} />
                          </td>
                          <td className="py-3 px-4 text-right whitespace-nowrap">
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => onPreviewInvoice(inv)}
                                className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                                title="Preview PDF"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDownloadInvoice(inv)}
                                className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                                title="Download PDF"
                              >
                                <Download className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => onSendEmail(client, inv)}
                                className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                                title="Send via Gmail"
                              >
                                <Mail className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        )}

        {activeTab === 'emails' && (
          <div>
            {clientEmails.length === 0 ? (
              <p className="p-8 text-center text-xs text-slate-500">
                No email history recorded for this client.
              </p>
            ) : (
              <>
                <div className="md:hidden divide-y divide-slate-100">
                  {clientEmails.map((em) => (
                    <div key={em.id} className="p-4 space-y-1.5">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-sm font-medium text-slate-900 break-words min-w-0">
                          {em.subject}
                        </p>
                        <StatusBadge status={em.status} />
                      </div>
                      <p className="text-xs text-slate-500 truncate">
                        {em.emailType} · {em.recipient}
                      </p>
                      <p className="text-[11px] font-mono text-slate-400">
                        {em.sentAt ? em.sentAt.slice(0, 16).replace('T', ' ') : '—'}
                      </p>
                    </div>
                  ))}
                </div>
                <div className="hidden md:block overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase">
                        <th className="py-3 px-4">Subject</th>
                        <th className="py-3 px-4">Type</th>
                        <th className="py-3 px-4">Recipient</th>
                        <th className="py-3 px-4">Sent Date</th>
                        <th className="py-3 px-4">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {clientEmails.map((em) => (
                        <tr key={em.id} className="hover:bg-slate-50">
                          <td className="py-3 px-4 font-medium text-slate-900">{em.subject}</td>
                          <td className="py-3 px-4 text-xs text-slate-600">{em.emailType}</td>
                          <td className="py-3 px-4 text-xs text-slate-600">{em.recipient}</td>
                          <td className="py-3 px-4 font-mono text-xs text-slate-600">
                            {em.sentAt ? em.sentAt.slice(0, 16).replace('T', ' ') : '—'}
                          </td>
                          <td className="py-3 px-4">
                            <StatusBadge status={em.status} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        )}
      </div>

      <ConfirmDialog
        open={Boolean(switchPlanTarget)}
        title={
          switchPlanTarget === 'subscription'
            ? 'Switch Client to Subscription (599€/mo)?'
            : 'Switch Client to One-Time Payment (1,199€)?'
        }
        description={
          switchPlanTarget === 'subscription'
            ? `Switch ${client.businessName} to the 599€ / month recurring Subscription Plan? Any unpaid one-time payment requests will be cancelled, while past paid invoices remain preserved.`
            : `Switch ${client.businessName} to the 1,199€ One-Time Payment Plan? Active recurring subscriptions and automated monthly reminders for this client will be cancelled, while past records remain preserved.`
        }
        confirmLabel={
          switchPlanTarget === 'subscription'
            ? 'Switch to 599€ Subscription'
            : 'Switch to 1,199€ One-Time'
        }
        busy={assigningPlan}
        onConfirm={() => switchPlanTarget && executePlanAssignment(switchPlanTarget)}
        onCancel={() => setSwitchPlanTarget(null)}
      />
    </div>
  );
};
