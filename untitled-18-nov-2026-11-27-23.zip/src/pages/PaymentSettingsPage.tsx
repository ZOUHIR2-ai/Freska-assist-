import React, { useEffect, useState } from 'react';
import { ShieldCheck, AlertCircle, Save, CheckCircle2, Power, Trash2 } from 'lucide-react';
import { saveEntity } from '../lib/storeClient.ts';
import {
  saveGatewayConfig,
  testGatewayConnection,
  toggleGatewayEnabled,
  clearGatewayConfig,
} from '../lib/api.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import { StatusBadge } from '../components/StatusBadge.tsx';

export const PaymentSettingsPage: React.FC = () => {
  const {
    gatewayDbSettings,
    gatewayServerStatus,
    webhookEvents,
    refreshGatewayStatus,
    notify,
  } = useFreska();

  // Credit / Debit Card credentials — EMPTY by default
  const [provider, setProvider] = useState<'stripe'>('stripe');
  const [environment, setEnvironment] = useState<'test' | 'live'>('test');
  const [publicKey, setPublicKey] = useState('');
  const [secretKey, setSecretKey] = useState('');
  const [webhookSecret, setWebhookSecret] = useState('');
  const [savingGw, setSavingGw] = useState(false);
  const [testingGw, setTestingGw] = useState(false);
  const [togglingGw, setTogglingGw] = useState(false);

  // Bank transfer settings
  const [bankAccountName, setBankAccountName] = useState('');
  const [bankName, setBankName] = useState('');
  const [bankIban, setBankIban] = useState('');
  const [bankBic, setBankBic] = useState('');
  const [bankInstructions, setBankInstructions] = useState('');
  const [savingBank, setSavingBank] = useState(false);

  useEffect(() => {
    setBankAccountName(gatewayDbSettings.bankAccountName || '');
    setBankName(gatewayDbSettings.bankName || '');
    setBankIban(gatewayDbSettings.bankIban || '');
    setBankBic(gatewayDbSettings.bankBic || '');
    setBankInstructions(gatewayDbSettings.bankInstructions || '');
  }, [gatewayDbSettings]);

  useEffect(() => {
    if (gatewayServerStatus) {
      setProvider(gatewayServerStatus.provider);
      setEnvironment(gatewayServerStatus.environment);
    }
  }, [gatewayServerStatus]);

  const handleSaveGateway = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingGw(true);
    try {
      const status = await saveGatewayConfig({
        provider,
        environment,
        publicKey: publicKey.trim(),
        secretKey: secretKey.trim(),
        webhookSecret: webhookSecret.trim(),
      });
      await saveEntity('payment_gateway_settings', 'default', {
        ...gatewayDbSettings,
        id: 'default',
        provider: status.provider,
        environment: status.environment,
        cardEnabled: status.enabled,
        credentialsConfigured: status.hasSecretKey && status.hasPublicKey,
        connectionVerified: status.connectionVerified,
      });
      setSecretKey('');
      setWebhookSecret('');
      await refreshGatewayStatus();
      notify('success', 'Payment gateway configuration saved securely on server.');
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to save gateway configuration');
    } finally {
      setSavingGw(false);
    }
  };

  const handleTestConnection = async () => {
    setTestingGw(true);
    try {
      const res = await testGatewayConnection();
      await saveEntity('payment_gateway_settings', 'default', {
        ...gatewayDbSettings,
        id: 'default',
        connectionVerified: res.verified,
        credentialsConfigured: true,
      });
      await refreshGatewayStatus();
      notify('success', `Gateway connection verified (Account: ${res.accountId}).`);
    } catch (err) {
      await refreshGatewayStatus();
      notify('error', err instanceof Error ? err.message : 'Gateway connection test failed');
    } finally {
      setTestingGw(false);
    }
  };

  const handleToggleCard = async (enabled: boolean) => {
    setTogglingGw(true);
    try {
      const status = await toggleGatewayEnabled(enabled);
      await saveEntity('payment_gateway_settings', 'default', {
        ...gatewayDbSettings,
        id: 'default',
        cardEnabled: status.enabled,
      });
      await refreshGatewayStatus();
      notify('success', enabled ? 'Card payments enabled.' : 'Card payments disabled.');
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Unable to change card payment status');
    } finally {
      setTogglingGw(false);
    }
  };

  const handleClearGateway = async () => {
    try {
      await clearGatewayConfig();
      await saveEntity('payment_gateway_settings', 'default', {
        ...gatewayDbSettings,
        id: 'default',
        cardEnabled: false,
        credentialsConfigured: false,
        connectionVerified: false,
      });
      setPublicKey('');
      setSecretKey('');
      setWebhookSecret('');
      await refreshGatewayStatus();
      notify('success', 'Gateway credentials cleared and card payments disabled.');
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to clear credentials');
    }
  };

  const handleSaveBankSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingBank(true);
    try {
      await saveEntity('payment_gateway_settings', 'default', {
        ...gatewayDbSettings,
        id: 'default',
        provider: gatewayServerStatus?.provider || 'stripe',
        environment: gatewayServerStatus?.environment || 'test',
        cardEnabled: gatewayServerStatus?.enabled ?? false,
        credentialsConfigured: Boolean(
          gatewayServerStatus?.hasPublicKey && gatewayServerStatus?.hasSecretKey
        ),
        connectionVerified: gatewayServerStatus?.connectionVerified ?? false,
        bankAccountName: bankAccountName.trim(),
        bankName: bankName.trim(),
        bankIban: bankIban.trim(),
        bankBic: bankBic.trim(),
        bankInstructions: bankInstructions.trim(),
      });
      notify('success', 'Bank transfer instructions saved.');
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to save bank details');
    } finally {
      setSavingBank(false);
    }
  };

  const isConfigured = Boolean(
    gatewayServerStatus?.hasPublicKey && gatewayServerStatus?.hasSecretKey
  );
  const isVerified = Boolean(gatewayServerStatus?.connectionVerified);
  const isEnabled = Boolean(gatewayServerStatus?.enabled);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-slate-900">Payment Settings</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Configure server-side payment gateway credentials for Credit/Debit Cards and bank account
          details for Bank Transfer (Virement).
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Card Gateway Configuration */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-5">
          <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-4">
            <div className="min-w-0">
              <h2 className="text-sm font-semibold text-slate-900">
                Credit / Debit Card Payment Gateway
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Secret keys are encrypted on the backend and never exposed to the browser.
              </p>
            </div>
            <StatusBadge status={isEnabled ? 'active' : 'paused'} />
          </div>

          <div
            className={`p-3.5 rounded-lg border text-xs flex items-start gap-2.5 ${
              isEnabled
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            {isEnabled ? (
              <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-emerald-700" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-slate-500" />
            )}
            <div className="space-y-1 min-w-0">
              <p className="font-medium">
                {isEnabled
                  ? `Card payments ENABLED (${gatewayServerStatus?.environment.toUpperCase()} mode)`
                  : 'Card payments DISABLED until valid credentials are entered and verified.'}
              </p>
              <p className="font-mono text-[11px] text-slate-600 break-words">
                Public Key:{' '}
                {gatewayServerStatus?.hasPublicKey ? gatewayServerStatus.publicKeyMasked : 'Not set'}{' '}
                · Secret Key:{' '}
                {gatewayServerStatus?.hasSecretKey
                  ? `Configured (••••${gatewayServerStatus.secretKeyLast4})`
                  : 'Not set'}{' '}
                · Webhook Secret: {gatewayServerStatus?.hasWebhookSecret ? 'Configured' : 'Not set'}
              </p>
            </div>
          </div>

          <form onSubmit={handleSaveGateway} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Payment Gateway Provider
                </label>
                <select
                  value={provider}
                  onChange={(e) => setProvider(e.target.value as 'stripe')}
                  className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="stripe">Stripe</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  API Environment
                </label>
                <select
                  value={environment}
                  onChange={(e) => setEnvironment(e.target.value as 'test' | 'live')}
                  className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="test">Test / Sandbox</option>
                  <option value="live">Live / Production</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Public API Key
              </label>
              <input
                type="text"
                value={publicKey}
                onChange={(e) => setPublicKey(e.target.value)}
                placeholder={
                  gatewayServerStatus?.hasPublicKey
                    ? gatewayServerStatus.publicKeyMasked
                    : 'Enter your publishable key'
                }
                autoComplete="off"
                className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm font-mono border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Secret API Key
              </label>
              <input
                type="password"
                value={secretKey}
                onChange={(e) => setSecretKey(e.target.value)}
                placeholder={
                  gatewayServerStatus?.hasSecretKey
                    ? `Saved (••••${gatewayServerStatus.secretKeyLast4}) — enter new key to replace`
                    : 'Enter your secret key'
                }
                autoComplete="new-password"
                className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm font-mono border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Webhook Secret
              </label>
              <input
                type="password"
                value={webhookSecret}
                onChange={(e) => setWebhookSecret(e.target.value)}
                placeholder={
                  gatewayServerStatus?.hasWebhookSecret
                    ? 'Saved — enter new signing secret to replace'
                    : 'Enter webhook signing secret'
                }
                autoComplete="new-password"
                className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm font-mono border border-slate-300 rounded-lg"
              />
              <p className="text-[11px] text-slate-500 mt-1.5 font-mono break-all">
                Webhook Endpoint: {window.location.origin}/api/webhooks/payment
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-2">
              <button
                type="submit"
                disabled={savingGw}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{savingGw ? 'Saving...' : 'Save Configuration'}</span>
              </button>
              <button
                type="button"
                disabled={testingGw || !gatewayServerStatus?.hasSecretKey}
                onClick={handleTestConnection}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg disabled:opacity-50"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{testingGw ? 'Testing...' : 'Test Connection'}</span>
              </button>
              {isEnabled ? (
                <button
                  type="button"
                  disabled={togglingGw}
                  onClick={() => handleToggleCard(false)}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-red-700 bg-red-50 border border-red-200 hover:bg-red-100 rounded-lg"
                >
                  <Power className="w-3.5 h-3.5" />
                  <span>Disable Card Payments</span>
                </button>
              ) : (
                <button
                  type="button"
                  disabled={togglingGw || !isConfigured || !isVerified}
                  onClick={() => handleToggleCard(true)}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-emerald-800 bg-emerald-50 border border-emerald-200 hover:bg-emerald-100 rounded-lg disabled:opacity-40"
                >
                  <Power className="w-3.5 h-3.5" />
                  <span>Enable Card Payments</span>
                </button>
              )}
              {isConfigured && (
                <button
                  type="button"
                  onClick={handleClearGateway}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-slate-600 border border-slate-200 sm:border-transparent hover:text-red-700 rounded-lg"
                  title="Clear Stored Credentials"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="sm:hidden">Clear Stored Credentials</span>
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Bank Transfer — Virement Configuration */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-5">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-sm font-semibold text-slate-900">
              Bank Transfer — Virement Account Details
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Displayed on Bank Transfer payment instruction pages and client payment requests.
            </p>
          </div>

          <form onSubmit={handleSaveBankSettings} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Account Holder Name
                </label>
                <input
                  type="text"
                  value={bankAccountName}
                  onChange={(e) => setBankAccountName(e.target.value)}
                  placeholder="Account beneficiary name"
                  className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Bank Name</label>
                <input
                  type="text"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  placeholder="Bank institution name"
                  className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  IBAN / Account Number
                </label>
                <input
                  type="text"
                  value={bankIban}
                  onChange={(e) => setBankIban(e.target.value)}
                  placeholder="IBAN or domestic account #"
                  className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm font-mono border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  BIC / SWIFT Code
                </label>
                <input
                  type="text"
                  value={bankBic}
                  onChange={(e) => setBankBic(e.target.value)}
                  placeholder="BIC / SWIFT"
                  className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm font-mono border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Transfer Instructions for Clients
              </label>
              <textarea
                rows={4}
                value={bankInstructions}
                onChange={(e) => setBankInstructions(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={savingBank}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{savingBank ? 'Saving...' : 'Save Bank Details'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Webhook Events Log */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-4 sm:px-5 py-4 border-b border-slate-200">
          <h2 className="text-sm font-semibold text-slate-900">Verified Webhook Events</h2>
        </div>
        {webhookEvents.length === 0 ? (
          <p className="p-8 text-center text-xs text-slate-500">
            No verified payment webhook events received yet.
          </p>
        ) : (
          <>
            <div className="md:hidden divide-y divide-slate-100">
              {webhookEvents.map((ev) => (
                <div key={ev.id} className="p-4 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-xs font-mono font-semibold text-slate-900 break-all">
                        {ev.eventType}
                      </p>
                      <p className="text-[11px] uppercase text-slate-500 font-medium mt-0.5">
                        {ev.provider}
                      </p>
                    </div>
                    <StatusBadge status={ev.status} />
                  </div>
                  <p className="text-xs text-slate-700 break-words">{ev.summary}</p>
                  <p className="text-[11px] font-mono text-slate-500 break-all">
                    {ev.externalEventId}
                  </p>
                </div>
              ))}
            </div>

            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase">
                    <th className="py-3 px-4">Provider</th>
                    <th className="py-3 px-4">Event Type</th>
                    <th className="py-3 px-4">External Event ID</th>
                    <th className="py-3 px-4">Summary</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {webhookEvents.map((ev) => (
                    <tr key={ev.id}>
                      <td className="py-3 px-4 text-xs uppercase font-medium text-slate-700">
                        {ev.provider}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs text-slate-900">{ev.eventType}</td>
                      <td className="py-3 px-4 font-mono text-xs text-slate-500">
                        {ev.externalEventId}
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-700">{ev.summary}</td>
                      <td className="py-3 px-4">
                        <StatusBadge status={ev.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
