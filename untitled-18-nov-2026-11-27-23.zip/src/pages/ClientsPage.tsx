import React, { useMemo, useState } from 'react';
import { Search, Plus, Edit2, Archive, Trash2, Eye, Link2 } from 'lucide-react';
import { saveEntity, deleteEntity } from '../lib/storeClient.ts';
import { computeClientFinancials, formatMoney } from '../lib/billingEngine.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import { StatusBadge } from '../components/StatusBadge.tsx';
import { ConfirmDialog } from '../components/ConfirmDialog.tsx';
import type { ClientRecord, ClientStatus } from '../types/freska.ts';

interface ClientsPageProps {
  onAddClient: () => void;
  onEditClient: (client: ClientRecord) => void;
  onCreatePaymentLink?: (clientId: string, subscriptionId?: string) => void;
}

export const ClientsPage: React.FC<ClientsPageProps> = ({
  onAddClient,
  onEditClient,
  onCreatePaymentLink,
}) => {
  const {
    user,
    dataLoading,
    googleConnecting,
    connectGoogle,
    clients,
    subscriptions,
    payments,
    paymentRequests,
    openClientProfile,
    notify,
  } = useFreska();

  const handleAddClientClick = () => {
    if (!user) {
      notify('info', 'Connect your Google Account first so clients stay saved to your account.');
      void connectGoogle({ includeGmail: true, forceAccountSelect: true });
      return;
    }
    onAddClient();
  };

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | ClientStatus>('all');
  const [deleteTarget, setDeleteTarget] = useState<ClientRecord | null>(null);
  const [deleting, setDeleting] = useState(false);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return clients.filter((c) => {
      if (statusFilter !== 'all' && c.status !== statusFilter) return false;
      if (!q) return true;
      return (
        c.fullName.toLowerCase().includes(q) ||
        c.businessName.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        c.clientCode.toLowerCase().includes(q) ||
        (c.businessType || '').toLowerCase().includes(q)
      );
    });
  }, [clients, search, statusFilter]);

  const handleArchive = async (client: ClientRecord) => {
    try {
      const nextStatus: ClientStatus = client.status === 'archived' ? 'active' : 'archived';
      await saveEntity('clients', client.id, { status: nextStatus });
      notify(
        'success',
        nextStatus === 'archived'
          ? `${client.businessName} archived.`
          : `${client.businessName} restored to active.`
      );
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to update client status');
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await deleteEntity('clients', deleteTarget.id);
      notify('success', `Client ${deleteTarget.businessName} deleted.`);
      setDeleteTarget(null);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to delete client');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div>
          <h1 className="text-xl font-semibold text-slate-900">Client Directory</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Manage individual clients, inspect financial profiles, and track billing status.
          </p>
        </div>
        <button
          type="button"
          onClick={handleAddClientClick}
          className="w-full sm:w-auto min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg whitespace-nowrap shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Client</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-xl p-3.5 sm:p-4">
        <div className="relative w-full sm:flex-1 sm:max-w-md min-w-0">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by client ID, name, business, or email..."
            className="w-full min-h-[44px] sm:min-h-0 pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
          />
        </div>

        <div className="w-full sm:w-auto overflow-x-auto">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg min-w-max">
            {(['all', 'active', 'inactive', 'archived'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setStatusFilter(tab)}
                className={`min-h-[38px] sm:min-h-0 px-3 py-1.5 text-xs font-medium rounded-md capitalize transition-colors whitespace-nowrap ${
                  statusFilter === tab
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Clients List / Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-8 sm:p-12 text-center space-y-3">
            {!user ? (
              <>
                <p className="text-sm font-medium text-slate-900">
                  Google Account disconnected — no clients shown
                </p>
                <p className="text-xs text-slate-500">
                  Connect your Google Account to load your saved clients or add new ones.
                </p>
                <button
                  type="button"
                  disabled={googleConnecting}
                  onClick={() => connectGoogle({ includeGmail: true, forceAccountSelect: true })}
                  className="mt-2 min-h-[44px] sm:min-h-0 inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
                >
                  <Link2 className="w-3.5 h-3.5" />
                  <span>{googleConnecting ? 'Connecting...' : 'Connect Google Account'}</span>
                </button>
              </>
            ) : dataLoading && clients.length === 0 ? (
              <div className="flex flex-col items-center gap-2.5 py-2">
                <div className="w-5 h-5 border-2 border-slate-300 border-t-slate-900 rounded-full animate-spin" />
                <p className="text-sm font-medium text-slate-900">
                  Loading saved clients from your Google Account...
                </p>
                <p className="text-xs text-slate-500">
                  Syncing your client directory and billing history for {user.email}.
                </p>
              </div>
            ) : (
              <>
                <p className="text-sm font-medium text-slate-900">
                  {clients.length === 0 ? 'No clients added yet' : 'No matching clients found'}
                </p>
                <p className="text-xs text-slate-500">
                  {clients.length === 0
                    ? 'Add your first client to start managing subscriptions, payment links, and invoices.'
                    : 'Try adjusting your search query or status filter.'}
                </p>
                {clients.length === 0 && (
                  <button
                    type="button"
                    onClick={onAddClient}
                    className="mt-2 min-h-[44px] sm:min-h-0 inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add First Client</span>
                  </button>
                )}
              </>
            )}
          </div>
        ) : (
          <>
            {/* Mobile Card View */}
            <div className="md:hidden divide-y divide-slate-100">
              {filtered.map((client) => {
                const fin = computeClientFinancials(
                  client.id,
                  subscriptions,
                  payments,
                  paymentRequests
                );
                return (
                  <div key={client.id} className="p-4 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <span className="text-[11px] font-mono text-slate-500">
                          {client.clientCode}
                        </span>
                        <button
                          type="button"
                          onClick={() => openClientProfile(client.id)}
                          className="font-semibold text-sm text-slate-900 hover:underline text-left block truncate max-w-full"
                        >
                          {client.businessName}
                        </button>
                        <p className="text-xs text-slate-500 truncate">
                          {client.fullName} · {client.email}
                        </p>
                      </div>
                      <StatusBadge status={client.status} />
                    </div>

                    <div className="grid grid-cols-3 gap-2 bg-slate-50 border border-slate-100 rounded-lg p-2.5 text-xs">
                      <div className="min-w-0">
                        <p className="text-[11px] text-slate-500">Plan</p>
                        <p className="font-medium text-slate-900 truncate mt-0.5">
                          {fin.billingMode === 'subscription' && fin.activeSub
                            ? `${formatMoney(fin.activeSub.monthlyPrice, fin.activeSub.currency)}/mo`
                            : fin.billingMode === 'one_time'
                            ? `${formatMoney(fin.oneTimeAmount, fin.currency)}`
                            : 'Unassigned'}
                        </p>
                      </div>
                      <div>
                        <p className="text-[11px] text-slate-500">Total Paid</p>
                        <p className="font-mono font-semibold tabular-nums text-slate-900 mt-0.5">
                          {formatMoney(fin.totalPaid, fin.currency)}
                        </p>
                      </div>
                      <div>
                        <p className="text-[11px] text-slate-500">Outstanding</p>
                        <p
                          className={`font-mono font-semibold tabular-nums mt-0.5 ${
                            fin.outstandingBalance > 0 ? 'text-red-700' : 'text-slate-500'
                          }`}
                        >
                          {formatMoney(fin.outstandingBalance, fin.currency)}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                      <button
                        type="button"
                        onClick={() => openClientProfile(client.id)}
                        className="flex-1 min-h-[40px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Profile</span>
                      </button>
                      {onCreatePaymentLink && client.status !== 'archived' && (
                        <button
                          type="button"
                          onClick={() => onCreatePaymentLink(client.id, fin.activeSub?.id)}
                          className="flex-1 min-h-[40px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
                        >
                          <Link2 className="w-3.5 h-3.5" />
                          <span>Pay Link</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onEditClient(client)}
                        title="Edit Client"
                        aria-label="Edit Client"
                        className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleArchive(client)}
                        title={client.status === 'archived' ? 'Restore Client' : 'Archive Client'}
                        aria-label={client.status === 'archived' ? 'Restore Client' : 'Archive Client'}
                        className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg"
                      >
                        <Archive className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeleteTarget(client)}
                        title="Delete Client"
                        aria-label="Delete Client"
                        className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center text-red-600 bg-white border border-red-200 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Desktop Table View */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    <th className="py-3 px-4">Client ID</th>
                    <th className="py-3 px-4">Client & Business</th>
                    <th className="py-3 px-4">Billing Plan</th>
                    <th className="py-3 px-4">Contact</th>
                    <th className="py-3 px-4 text-right">Total Paid</th>
                    <th className="py-3 px-4 text-right">Outstanding</th>
                    <th className="py-3 px-4">Next Payment</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filtered.map((client) => {
                    const fin = computeClientFinancials(
                      client.id,
                      subscriptions,
                      payments,
                      paymentRequests
                    );
                    return (
                      <tr key={client.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4 font-mono text-xs text-slate-600 whitespace-nowrap">
                          {client.clientCode}
                        </td>
                        <td className="py-3 px-4">
                          <button
                            type="button"
                            onClick={() => openClientProfile(client.id)}
                            className="font-medium text-slate-900 hover:underline text-left block"
                          >
                            {client.businessName}
                          </button>
                          <p className="text-xs text-slate-500">
                            {client.fullName}
                            {client.businessType ? ` · ${client.businessType}` : ''}
                          </p>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          {fin.billingMode === 'subscription' && fin.activeSub ? (
                            <div>
                              <div className="text-xs font-medium text-slate-900">Subscription</div>
                              <div className="text-[11px] font-mono tabular-nums text-slate-600">
                                {formatMoney(fin.activeSub.monthlyPrice, fin.activeSub.currency)}/mo
                              </div>
                            </div>
                          ) : fin.billingMode === 'one_time' ? (
                            <div>
                              <div className="text-xs font-medium text-slate-900">One-Time Payment</div>
                              <div className="text-[11px] font-mono tabular-nums text-slate-600">
                                {formatMoney(fin.oneTimeAmount, fin.currency)}
                                {fin.latestOneTimePayment && !fin.openOneTimeRequest ? ' · Paid' : ' · Pending'}
                              </div>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => onEditClient(client)}
                              className="text-xs text-slate-400 hover:text-slate-700 underline"
                            >
                              Assign plan
                            </button>
                          )}
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-600">
                          <div>{client.email}</div>
                          {client.phone && <div className="text-slate-400">{client.phone}</div>}
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-xs font-medium text-slate-900 tabular-nums whitespace-nowrap">
                          {formatMoney(fin.totalPaid, fin.currency)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-xs font-medium tabular-nums whitespace-nowrap">
                          <span
                            className={
                              fin.outstandingBalance > 0 ? 'text-red-700 font-semibold' : 'text-slate-500'
                            }
                          >
                            {formatMoney(fin.outstandingBalance, fin.currency)}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-slate-600 whitespace-nowrap">
                          {fin.nextPaymentDate || '—'}
                        </td>
                        <td className="py-3 px-4">
                          <StatusBadge status={client.status} />
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            {onCreatePaymentLink && client.status !== 'archived' && (
                              <button
                                type="button"
                                onClick={() =>
                                  onCreatePaymentLink(client.id, fin.activeSub?.id)
                                }
                                title="Send Payment Request & Create Payment Link"
                                className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                              >
                                <Link2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => openClientProfile(client.id)}
                              title="View Client Profile"
                              className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => onEditClient(client)}
                              title="Edit Client"
                              className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleArchive(client)}
                              title={client.status === 'archived' ? 'Restore Client' : 'Archive Client'}
                              className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                            >
                              <Archive className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteTarget(client)}
                              title="Delete Client"
                              className="p-1.5 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        variant="danger"
        title="Delete Client Record"
        description={`Are you sure you want to permanently delete "${deleteTarget?.businessName}"? Consider archiving if you want to preserve historical context.`}
        confirmLabel="Delete Client"
        busy={deleting}
        onConfirm={handleDeleteConfirm}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};
