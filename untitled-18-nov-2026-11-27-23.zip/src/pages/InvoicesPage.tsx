import React, { useMemo, useState } from 'react';
import { Search, Eye, Download, Mail } from 'lucide-react';
import { saveEntity } from '../lib/storeClient.ts';
import { formatMoney, formatPaymentMethodLabel } from '../lib/billingEngine.ts';
import { fetchInvoicePdfBlob } from '../lib/api.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import { StatusBadge } from '../components/StatusBadge.tsx';
import type { ClientRecord, InvoiceRecord, InvoiceStatus } from '../types/freska.ts';

interface InvoicesPageProps {
  onPreviewInvoice: (invoice: InvoiceRecord) => void;
  onSendInvoiceEmail: (client: ClientRecord | null, invoice: InvoiceRecord) => void;
}

export const InvoicesPage: React.FC<InvoicesPageProps> = ({
  onPreviewInvoice,
  onSendInvoiceEmail,
}) => {
  const { invoices, clients, payments, systemSettings, openClientProfile, notify } =
    useFreska();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | InvoiceStatus>('all');
  const [clientFilter, setClientFilter] = useState('all');

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return invoices
      .filter((inv) => {
        if (statusFilter !== 'all' && inv.status !== statusFilter) return false;
        if (clientFilter !== 'all' && inv.clientId !== clientFilter) return false;
        if (!q) return true;
        return (
          inv.invoiceNumber.toLowerCase().includes(q) ||
          inv.clientName.toLowerCase().includes(q) ||
          (inv.businessName || '').toLowerCase().includes(q) ||
          inv.serviceName.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => b.invoiceDate.localeCompare(a.invoiceDate));
  }, [invoices, search, statusFilter, clientFilter]);

  const handleDownload = async (inv: InvoiceRecord) => {
    try {
      const linkedPayment = payments.find((p) => p.id === inv.paymentId);
      const blob = await fetchInvoicePdfBlob({
        invoiceNumber: inv.invoiceNumber,
        invoiceDate: inv.invoiceDate,
        paymentDate: inv.paymentDate,
        status: inv.status,
        clientName: inv.clientName,
        businessName: inv.businessName || inv.clientName,
        clientEmail: inv.clientEmail,
        serviceName: inv.serviceName,
        serviceDescription: inv.serviceDescription || '',
        paymentType: inv.paymentType,
        paymentMethod: inv.paymentMethod,
        paymentReference: inv.paymentReference || '',
        manuallyVerified: linkedPayment?.manuallyVerified ?? false,
        amount: inv.amount,
        currency: inv.currency,
        companyName: systemSettings.businessName || 'FreskaAssist',
        companyAddress: systemSettings.companyAddress || '',
        companyEmail: systemSettings.adminEmail || '',
        taxId: systemSettings.taxId || '',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `FreskaAssist-${inv.invoiceNumber}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'PDF download failed');
    }
  };

  const handleStatusChange = async (inv: InvoiceRecord, nextStatus: InvoiceStatus) => {
    try {
      await saveEntity('invoices', inv.id, { status: nextStatus });
      notify('success', `Invoice ${inv.invoiceNumber} marked as ${nextStatus}.`);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to update invoice status');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-slate-900">Invoices</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Automatically generated PDF invoices linked to confirmed payments. Preview, download, or
          deliver via Gmail.
        </p>
      </div>

      {/* Filters */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 sm:p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="flex flex-col sm:flex-row sm:items-center gap-2.5 sm:gap-3 flex-1 min-w-0">
          <div className="relative w-full sm:flex-1 sm:max-w-sm min-w-0">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search invoice #, client, or service..."
              className="w-full min-h-[44px] sm:min-h-0 pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>

          <select
            value={clientFilter}
            onChange={(e) => setClientFilter(e.target.value)}
            className="w-full sm:w-auto min-h-[44px] sm:min-h-0 px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
          >
            <option value="all">All Clients</option>
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.businessName}
              </option>
            ))}
          </select>
        </div>

        <div className="w-full lg:w-auto overflow-x-auto">
          <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg min-w-max">
            {(['all', 'paid', 'pending', 'cancelled', 'refunded'] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`min-h-[38px] sm:min-h-0 px-3 py-1.5 text-xs font-medium rounded-md capitalize whitespace-nowrap ${
                  statusFilter === st ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Mobile Cards / Desktop Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-8 sm:p-12 text-center space-y-2">
            <p className="text-sm font-medium text-slate-900">No invoices found</p>
            <p className="text-xs text-slate-500">
              Paid invoices are automatically issued immediately after payment confirmation.
            </p>
          </div>
        ) : (
          <>
            <div className="md:hidden divide-y divide-slate-100">
              {filtered.map((inv) => {
                const client = clients.find((c) => c.id === inv.clientId) || null;
                return (
                  <div key={inv.id} className="p-4 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-xs font-mono font-semibold text-slate-900">
                          {inv.invoiceNumber}
                        </p>
                        <button
                          type="button"
                          onClick={() => openClientProfile(inv.clientId)}
                          className="font-semibold text-sm text-slate-900 hover:underline text-left block truncate max-w-full"
                        >
                          {inv.businessName || inv.clientName}
                        </button>
                        <p className="text-xs text-slate-500 truncate">{inv.serviceName}</p>
                      </div>
                      <div className="flex flex-col items-end gap-1 shrink-0">
                        <StatusBadge status={inv.status} />
                        {inv.status === 'paid' && (
                          <select
                            aria-label={`Change status for ${inv.invoiceNumber}`}
                            value={inv.status}
                            onChange={(e) =>
                              handleStatusChange(inv, e.target.value as InvoiceStatus)
                            }
                            className="text-[11px] border border-slate-200 rounded px-1.5 py-1 bg-white text-slate-600"
                          >
                            <option value="paid">Paid</option>
                            <option value="refunded">Refunded</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs bg-slate-50 border border-slate-100 rounded-lg px-3 py-2">
                      <span className="font-mono text-slate-600">
                        {inv.invoiceDate} · {inv.sentViaGmail ? 'Emailed' : 'Not sent'}
                      </span>
                      <span className="font-mono font-semibold tabular-nums text-slate-900">
                        {formatMoney(inv.amount, inv.currency)}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => onPreviewInvoice(inv)}
                        className="min-h-[40px] inline-flex items-center justify-center gap-1 px-2 py-1.5 text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Preview</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDownload(inv)}
                        className="min-h-[40px] inline-flex items-center justify-center gap-1 px-2 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>PDF</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onSendInvoiceEmail(client, inv)}
                        className="min-h-[40px] inline-flex items-center justify-center gap-1 px-2 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
                      >
                        <Mail className="w-3.5 h-3.5" />
                        <span>Email</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase">
                    <th className="py-3 px-4">Invoice #</th>
                    <th className="py-3 px-4">Client</th>
                    <th className="py-3 px-4">Service</th>
                    <th className="py-3 px-4">Method</th>
                    <th className="py-3 px-4 text-right">Amount</th>
                    <th className="py-3 px-4">Invoice Date</th>
                    <th className="py-3 px-4">Gmail Delivery</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filtered.map((inv) => {
                    const client = clients.find((c) => c.id === inv.clientId) || null;
                    return (
                      <tr key={inv.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-mono text-xs font-semibold text-slate-900">
                          {inv.invoiceNumber}
                        </td>
                        <td className="py-3 px-4">
                          <button
                            type="button"
                            onClick={() => openClientProfile(inv.clientId)}
                            className="font-medium text-slate-900 hover:underline text-left"
                          >
                            {inv.businessName || inv.clientName}
                          </button>
                          <div className="text-xs text-slate-500">{inv.clientEmail}</div>
                        </td>
                        <td className="py-3 px-4 text-slate-900">
                          <div>{inv.serviceName}</div>
                          <div className="text-[11px] text-slate-500">
                            {inv.paymentType === 'subscription' ? 'Subscription' : 'One-Time'}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-600">
                          {formatPaymentMethodLabel(inv.paymentMethod)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-xs font-semibold tabular-nums">
                          {formatMoney(inv.amount, inv.currency)}
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-slate-600">
                          {inv.invoiceDate}
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-600">
                          {inv.sentViaGmail ? `Sent ${inv.sentAt?.slice(0, 10) || ''}` : 'Not sent'}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <StatusBadge status={inv.status} />
                            {inv.status === 'paid' && (
                              <select
                                aria-label={`Change status for ${inv.invoiceNumber}`}
                                value={inv.status}
                                onChange={(e) =>
                                  handleStatusChange(inv, e.target.value as InvoiceStatus)
                                }
                                className="text-[11px] border border-slate-200 rounded px-1 py-0.5 bg-white text-slate-600"
                              >
                                <option value="paid">Paid</option>
                                <option value="refunded">Refunded</option>
                                <option value="cancelled">Cancelled</option>
                              </select>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => onPreviewInvoice(inv)}
                              title="Preview PDF"
                              className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDownload(inv)}
                              title="Download PDF"
                              className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => onSendInvoiceEmail(client, inv)}
                              title="Send Invoice via Gmail"
                              className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                            >
                              <Mail className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
