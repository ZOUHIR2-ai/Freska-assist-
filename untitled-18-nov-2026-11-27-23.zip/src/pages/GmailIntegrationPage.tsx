import React, { useEffect, useState } from 'react';
import {
  Mail,
  CheckCircle2,
  AlertCircle,
  Send,
  LogOut,
  RefreshCw,
  ArrowLeftRight,
  ExternalLink,
  UserCheck,
  Server,
  ShieldCheck,
  Trash2,
} from 'lucide-react';
import {
  clearSmtpConfig,
  saveSmtpConfig,
  sendGmailMessage,
  SmtpPreset,
  testSmtpConnection,
  toggleSmtpEnabled,
} from '../lib/api.ts';
import { logEmailDispatch } from '../lib/billingEngine.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import { ConfirmDialog } from '../components/ConfirmDialog.tsx';

const SMTP_PRESETS: Array<{
  id: SmtpPreset;
  label: string;
  host: string;
  port: number;
  secure: boolean;
  hint: string;
}> = [
  {
    id: 'brevo',
    label: 'Brevo (Free 300/day)',
    host: 'smtp-relay.brevo.com',
    port: 587,
    secure: false,
    hint: 'Use your Brevo SMTP login email as Username and your Brevo SMTP Key as Password.',
  },
  {
    id: 'resend',
    label: 'Resend',
    host: 'smtp.resend.com',
    port: 465,
    secure: true,
    hint: 'Use "resend" as Username, your Resend API Key (re_...) as Password, and your verified domain email as From Email.',
  },
  {
    id: 'sendgrid',
    label: 'SendGrid',
    host: 'smtp.sendgrid.net',
    port: 587,
    secure: false,
    hint: 'Use "apikey" as Username and your SendGrid API Key as Password.',
  },
  {
    id: 'gmail_smtp',
    label: 'Gmail App Password',
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    hint: 'Use your Gmail address as Username and a 16-character Google App Password (requires 2-Step Verification).',
  },
  {
    id: 'custom',
    label: 'Custom Domain SMTP',
    host: '',
    port: 587,
    secure: false,
    hint: 'Enter your hosting / Zoho / Google Workspace / cPanel SMTP credentials.',
  },
];

export const GmailIntegrationPage: React.FC = () => {
  const {
    user,
    authError,
    googleConnecting,
    gmailConnected,
    gmailEmail,
    smtpStatus,
    emailDeliveryActive,
    refreshSmtpStatus,
    connectGoogle,
    connectGoogleWithRedirect,
    switchGoogleAccount,
    disconnectGoogle,
    notify,
  } = useFreska();

  const [testRecipient, setTestRecipient] = useState(gmailEmail || '');
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [sendingTest, setSendingTest] = useState(false);

  // SMTP Form State
  const [preset, setPreset] = useState<SmtpPreset>('custom');
  const [host, setHost] = useState('');
  const [port, setPort] = useState('587');
  const [secure, setSecure] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [fromName, setFromName] = useState('FreskaAssist');
  const [fromEmail, setFromEmail] = useState('');
  const [replyTo, setReplyTo] = useState('');
  const [publicPortalUrl, setPublicPortalUrl] = useState('');
  const [savingSmtp, setSavingSmtp] = useState(false);
  const [testingSmtp, setTestingSmtp] = useState(false);
  const [togglingSmtp, setTogglingSmtp] = useState(false);

  useEffect(() => {
    if (gmailEmail && !testRecipient) {
      setTestRecipient(gmailEmail);
    }
  }, [gmailEmail, testRecipient]);

  useEffect(() => {
    if (!smtpStatus) return;
    setPreset(smtpStatus.preset || 'custom');
    setHost(smtpStatus.host || '');
    setPort(String(smtpStatus.port || 587));
    setSecure(Boolean(smtpStatus.secure));
    setUsername(smtpStatus.username || '');
    setFromName(smtpStatus.fromName || 'FreskaAssist');
    setFromEmail(smtpStatus.fromEmail || '');
    setReplyTo(smtpStatus.replyTo || '');
    setPublicPortalUrl(smtpStatus.publicPortalUrl || '');
    if (smtpStatus.fromEmail && !testRecipient) {
      setTestRecipient(smtpStatus.fromEmail);
    }
  }, [smtpStatus, testRecipient]);

  const isEmbeddedFrame = typeof window !== 'undefined' && window.self !== window.top;
  const smtpEnabled = Boolean(smtpStatus?.enabled && smtpStatus?.connectionVerified);
  const activeSenderEmail = smtpEnabled
    ? smtpStatus?.fromEmail || ''
    : gmailEmail || '';

  const applyPreset = (nextPreset: SmtpPreset) => {
    setPreset(nextPreset);
    const meta = SMTP_PRESETS.find((p) => p.id === nextPreset);
    if (meta && meta.host) {
      setHost(meta.host);
      setPort(String(meta.port));
      setSecure(meta.secure);
      if (nextPreset === 'resend') setUsername('resend');
      if (nextPreset === 'sendgrid') setUsername('apikey');
    }
  };

  const handleSaveSmtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSmtp(true);
    try {
      await saveSmtpConfig({
        preset,
        host: host.trim(),
        port: Number(port) || 587,
        secure,
        username: username.trim(),
        password: password.trim() || undefined,
        fromName: fromName.trim() || 'FreskaAssist',
        fromEmail: fromEmail.trim(),
        replyTo: replyTo.trim(),
        publicPortalUrl: publicPortalUrl.trim(),
      });
      setPassword('');
      await refreshSmtpStatus();
      notify('success', 'SMTP configuration saved securely. Click "Test SMTP" to verify.');
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to save SMTP config');
    } finally {
      setSavingSmtp(false);
    }
  };

  const handleVerifySmtp = async () => {
    setTestingSmtp(true);
    try {
      const res = await testSmtpConnection();
      await refreshSmtpStatus();
      if (res.verified) {
        notify('success', 'SMTP connection verified. You can now enable SMTP Primary Delivery.');
      }
    } catch (err) {
      await refreshSmtpStatus();
      notify('error', err instanceof Error ? err.message : 'SMTP verification failed');
    } finally {
      setTestingSmtp(false);
    }
  };

  const handleToggleSmtp = async () => {
    setTogglingSmtp(true);
    try {
      const next = !smtpEnabled;
      await toggleSmtpEnabled(next);
      await refreshSmtpStatus();
      notify(
        'success',
        next
          ? 'Verified SMTP Relay is now the active email sender for all client emails.'
          : 'SMTP Relay paused. Reverted to Gmail API OAuth when connected.'
      );
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Could not toggle SMTP delivery');
    } finally {
      setTogglingSmtp(false);
    }
  };

  const handleClearSmtp = async () => {
    setSavingSmtp(true);
    try {
      await clearSmtpConfig();
      setPassword('');
      await refreshSmtpStatus();
      notify('info', 'SMTP configuration cleared.');
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to clear SMTP config');
    } finally {
      setSavingSmtp(false);
    }
  };

  const handleSendTest = async () => {
    setSendingTest(true);
    try {
      const subject = 'Checking in from FreskaAssist';
      const bodyText = `Hello,\n\nThis is a quick test message confirming that FreskaAssist email delivery is active from ${activeSenderEmail || 'your configured sender'}.\n\nBest regards,\n${smtpEnabled ? fromName || 'FreskaAssist' : user?.displayName || 'FreskaAssist'}`;

      const res = await sendGmailMessage({
        to: testRecipient.trim(),
        subject,
        bodyText,
        senderDisplayName: smtpEnabled ? fromName || 'FreskaAssist' : user?.displayName || 'FreskaAssist',
      });

      await logEmailDispatch({
        recipient: testRecipient.trim(),
        subject,
        emailType: 'connection_test',
        status: 'sent',
        gmailMessageId: res.messageId,
      });

      notify(
        'success',
        `Test email sent via ${res.transport === 'smtp' ? 'Verified SMTP' : 'Gmail API'} (ID: ${res.messageId}).`
      );
      setConfirmOpen(false);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Test email failed';
      await logEmailDispatch({
        recipient: testRecipient.trim(),
        subject: 'Checking in from FreskaAssist',
        emailType: 'connection_test',
        status: 'failed',
        errorMessage: msg,
      });
      notify('error', msg);
      setConfirmOpen(false);
    } finally {
      setSendingTest(false);
    }
  };

  const currentPresetMeta = SMTP_PRESETS.find((p) => p.id === preset);

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-xl font-semibold text-slate-900">
          Email Delivery &amp; Google Integration
        </h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Configure a Verified Domain SMTP Relay (recommended for Inbox delivery) or connect your
          Google Account to send payment links, PDF invoices, and automated reminders.
        </p>
      </div>

      {/* Why Gmail.com Consumer Accounts Hit Spam Banner */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 space-y-1.5 text-xs text-amber-950">
        <div className="flex items-start gap-2.5">
          <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
          <div className="space-y-1 leading-relaxed">
            <p className="font-semibold">How to stop client emails from going to Spam</p>
            <p>
              Emails sent via the Gmail API from a free <code>@gmail.com</code> address containing
              billing links (especially <code>*.run.app</code> sandbox URLs) are strictly filtered
              into Spam by Yahoo and Gmail. For reliable <strong>Primary Inbox</strong> delivery,
              connect a verified sender domain via <strong>Brevo</strong>, <strong>Resend</strong>,
              or your own <strong>Custom SMTP</strong> below.
            </p>
          </div>
        </div>
      </div>

      {/* Verified Domain / Custom SMTP Relay Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
          <div className="flex items-start gap-3 min-w-0">
            <div
              className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${
                smtpEnabled
                  ? 'bg-emerald-50 text-emerald-700'
                  : smtpStatus?.connectionVerified
                  ? 'bg-blue-50 text-blue-700'
                  : 'bg-slate-100 text-slate-600'
              }`}
            >
              <Server className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm font-semibold text-slate-900">
                Verified SMTP Relay (Brevo / Resend / Custom Domain)
              </h2>
              <p className="text-xs text-slate-500 mt-0.5 break-words">
                {smtpEnabled
                  ? `Active primary sender: ${smtpStatus?.fromEmail} (${smtpStatus?.host})`
                  : smtpStatus?.connectionVerified
                  ? `Verified (${smtpStatus?.host}) — click Enable SMTP below to activate.`
                  : 'Encrypted server-side with AES-256-GCM. Overrides Gmail API when enabled.'}
              </p>
            </div>
          </div>

          <button
            type="button"
            disabled={togglingSmtp || (!smtpEnabled && !smtpStatus?.connectionVerified)}
            onClick={handleToggleSmtp}
            className={`w-full sm:w-auto px-3.5 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium rounded-lg border transition text-center shrink-0 ${
              smtpEnabled
                ? 'bg-emerald-700 text-white border-emerald-700 hover:bg-emerald-800'
                : 'bg-slate-900 text-white border-slate-900 hover:bg-slate-800 disabled:opacity-40'
            }`}
          >
            {togglingSmtp
              ? 'Updating...'
              : smtpEnabled
              ? 'SMTP Active (Click to Pause)'
              : 'Enable SMTP Delivery'}
          </button>
        </div>

        {/* Provider Quick Presets */}
        <div className="flex flex-wrap gap-2">
          {SMTP_PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => applyPreset(p.id)}
              className={`px-3 py-2 sm:py-1.5 min-h-[40px] sm:min-h-0 text-xs font-medium rounded-lg border transition ${
                preset === p.id
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {currentPresetMeta && (
          <p className="text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
            {currentPresetMeta.hint}
          </p>
        )}

        <form onSubmit={handleSaveSmtp} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">SMTP Host</label>
              <input
                type="text"
                value={host}
                onChange={(e) => setHost(e.target.value)}
                placeholder="smtp-relay.brevo.com"
                className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Port</label>
                <input
                  type="number"
                  value={port}
                  onChange={(e) => setPort(e.target.value)}
                  placeholder="587"
                  className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">SSL / TLS</label>
                <select
                  value={secure ? 'ssl' : 'starttls'}
                  onChange={(e) => setSecure(e.target.value === 'ssl')}
                  className="w-full px-2.5 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg bg-white"
                >
                  <option value="starttls">STARTTLS (587)</option>
                  <option value="ssl">SSL (465)</option>
                </select>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">SMTP Username</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="resend / SMTP login"
                className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                SMTP Password / API Key{' '}
                {smtpStatus?.hasPassword && (
                  <span className="text-slate-400 font-normal">
                    (saved ending in {smtpStatus.passwordLast4})
                  </span>
                )}
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={smtpStatus?.hasPassword ? 'Leave blank to keep existing' : 'Enter SMTP key or password'}
                className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">From Name</label>
              <input
                type="text"
                value={fromName}
                onChange={(e) => setFromName(e.target.value)}
                placeholder="FreskaAssist"
                className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Verified From Email
              </label>
              <input
                type="email"
                value={fromEmail}
                onChange={(e) => setFromEmail(e.target.value)}
                placeholder="billing@yourdomain.com"
                className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Reply-To Email (Optional)
              </label>
              <input
                type="email"
                value={replyTo}
                onChange={(e) => setReplyTo(e.target.value)}
                placeholder="zwizoo175@gmail.com"
                className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Custom Payment Portal Base URL (Optional — replaces <code>*.run.app</code> links)
            </label>
            <input
              type="url"
              value={publicPortalUrl}
              onChange={(e) => setPublicPortalUrl(e.target.value)}
              placeholder="https://billing.yourdomain.com"
              className="w-full px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2.5 pt-1">
            <button
              type="submit"
              disabled={savingSmtp}
              className="w-full sm:w-auto px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
            >
              {savingSmtp ? 'Saving...' : 'Save SMTP Config'}
            </button>
            <button
              type="button"
              disabled={testingSmtp || !smtpStatus?.host || !smtpStatus?.fromEmail}
              onClick={handleVerifySmtp}
              className="w-full sm:w-auto px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg disabled:opacity-40"
            >
              {testingSmtp ? 'Verifying...' : 'Test SMTP Connection'}
            </button>
            {smtpStatus?.host && (
              <button
                type="button"
                disabled={savingSmtp}
                onClick={handleClearSmtp}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-red-700 bg-white border border-red-200 hover:bg-red-50 rounded-lg disabled:opacity-40"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear SMTP</span>
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Diagnostic / Troubleshooting Banner */}
      {authError && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 space-y-2 text-xs text-red-900">
          <div className="flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
            <div className="space-y-1.5">
              <p className="font-semibold">Google Connection Issue</p>
              <p className="leading-relaxed">{authError}</p>
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="button"
                  disabled={googleConnecting}
                  onClick={() => connectGoogle({ includeGmail: false, forceAccountSelect: true })}
                  className="px-3 py-1.5 font-medium bg-white border border-red-300 text-red-900 rounded-lg hover:bg-red-100"
                >
                  Try Basic Google Profile Only
                </button>
                {isEmbeddedFrame ? (
                  <a
                    href={window.location.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 font-medium bg-red-900 text-white rounded-lg hover:bg-red-800"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Open App in New Tab</span>
                  </a>
                ) : (
                  <button
                    type="button"
                    disabled={googleConnecting}
                    onClick={() => connectGoogleWithRedirect(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 font-medium bg-red-900 text-white rounded-lg hover:bg-red-800 disabled:opacity-60"
                  >
                    <span>Use Full-Page Redirect</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Connection Status & Account Switcher Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-start gap-3.5 min-w-0">
            {user?.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'Google Account'}
                referrerPolicy="no-referrer"
                className="w-11 h-11 rounded-full object-cover border border-slate-200 shrink-0"
              />
            ) : (
              <div
                className={`w-11 h-11 rounded-lg flex items-center justify-center shrink-0 ${
                  gmailConnected
                    ? 'bg-emerald-50 text-emerald-700'
                    : user
                    ? 'bg-blue-50 text-blue-700'
                    : 'bg-amber-50 text-amber-700'
                }`}
              >
                {gmailConnected ? (
                  <CheckCircle2 className="w-5 h-5" />
                ) : user ? (
                  <UserCheck className="w-5 h-5" />
                ) : (
                  <AlertCircle className="w-5 h-5" />
                )}
              </div>
            )}

            <div className="min-w-0 flex-1">
              <h2 className="text-sm font-semibold text-slate-900">
                {gmailConnected
                  ? 'Google Account Linked & Gmail OAuth Active'
                  : user
                  ? 'Google Account Linked (Gmail Send Inactive)'
                  : 'No Google Account Linked'}
              </h2>
              <p className="text-xs text-slate-600 mt-1 break-all">
                Active Google Account:{' '}
                <span className="font-mono font-medium text-slate-900">
                  {user?.email || 'Not connected'}
                </span>
              </p>
              {user?.displayName && (
                <p className="text-xs text-slate-500 mt-0.5">Account Name: {user.displayName}</p>
              )}
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                {smtpEnabled
                  ? 'Verified SMTP Relay is currently active and handling outbound emails. Google remains linked for Cloud Firestore sync.'
                  : gmailConnected
                  ? 'Authorized with gmail.send permission. OAuth access tokens stay strictly in browser memory.'
                  : user
                  ? 'Your Google profile is linked, but the current session does not hold a Gmail sending token yet. Click "Authorize Gmail Send" or switch accounts below.'
                  : 'Connect your Google Account below for Cloud Firestore sync and optional Gmail OAuth sending.'}
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center gap-2.5">
          {!user ? (
            <>
              <button
                type="button"
                disabled={googleConnecting}
                onClick={() => connectGoogle({ includeGmail: true, forceAccountSelect: true })}
                className="gsi-material-button w-full sm:w-auto justify-center"
              >
                <div className="gsi-material-button-state" />
                <div className="gsi-material-button-content-wrapper">
                  <div className="gsi-material-button-icon">
                    <svg
                      version="1.1"
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 48 48"
                      style={{ display: 'block' }}
                    >
                      <path
                        fill="#EA4335"
                        d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                      />
                      <path
                        fill="#4285F4"
                        d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                      />
                      <path
                        fill="#34A853"
                        d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                      />
                      <path fill="none" d="M0 0h48v48H0z" />
                    </svg>
                  </div>
                  <span className="gsi-material-button-contents">
                    {googleConnecting ? 'Connecting...' : 'Connect Google Account & Gmail'}
                  </span>
                </div>
              </button>

              <button
                type="button"
                disabled={googleConnecting}
                onClick={() => connectGoogle({ includeGmail: false, forceAccountSelect: true })}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 min-h-[44px] sm:min-h-0 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg disabled:opacity-50"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Connect Basic Profile Only</span>
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                disabled={googleConnecting}
                onClick={() => connectGoogle({ includeGmail: true, forceAccountSelect: false })}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${googleConnecting ? 'animate-spin' : ''}`} />
                <span>{gmailConnected ? 'Refresh Gmail Token' : 'Authorize Gmail Send'}</span>
              </button>

              <button
                type="button"
                disabled={googleConnecting}
                onClick={() => switchGoogleAccount(true)}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg disabled:opacity-50"
              >
                <ArrowLeftRight className="w-3.5 h-3.5" />
                <span>Change Google Account</span>
              </button>

              <button
                type="button"
                disabled={googleConnecting}
                onClick={disconnectGoogle}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg disabled:opacity-50"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Disconnect</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Send Test Email */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-slate-600" />
            <h2 className="text-sm font-semibold text-slate-900">Send Test Email</h2>
          </div>
          {emailDeliveryActive && (
            <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded break-all">
              Active Route: {smtpEnabled ? `SMTP (${smtpStatus?.fromEmail})` : `Gmail API (${gmailEmail})`}
            </span>
          )}
        </div>
        <p className="text-xs text-slate-500">
          Verify live delivery by sending a real test message through your active transport (Verified
          SMTP Relay when enabled, otherwise Gmail OAuth API).
        </p>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <input
            type="email"
            value={testRecipient}
            onChange={(e) => setTestRecipient(e.target.value)}
            placeholder="recipient@example.com"
            className="w-full sm:flex-1 min-w-0 px-3 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-sm border border-slate-300 rounded-lg"
          />
          <button
            type="button"
            disabled={!emailDeliveryActive || !testRecipient.trim()}
            onClick={() => setConfirmOpen(true)}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 min-h-[44px] sm:min-h-0 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-40 shrink-0"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send Test Email</span>
          </button>
        </div>
      </div>

      <ConfirmDialog
        open={confirmOpen}
        variant="gmail"
        title="Confirm Test Email Dispatch"
        description={`Send a test email from ${activeSenderEmail} to ${testRecipient} via ${
          smtpEnabled ? 'Verified SMTP Relay' : 'Gmail API'
        }?`}
        confirmLabel="Send Test Email"
        busy={sendingTest}
        onConfirm={handleSendTest}
        onCancel={() => setConfirmOpen(false)}
      />
    </div>
  );
};
