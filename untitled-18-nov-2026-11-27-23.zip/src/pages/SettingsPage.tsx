import React, { useEffect, useState } from 'react';
import {
  Save,
  RefreshCw,
  KeyRound,
  Building2,
  Activity,
  ShieldCheck,
  Lock,
  CheckCircle2,
  Clock,
} from 'lucide-react';
import { saveEntity } from '../lib/storeClient.ts';
import { fetchServerLogs, updateServerCronTimezone } from '../lib/api.ts';
import { useFreska } from '../context/FreskaContext.tsx';
import { ApiKeysPanel } from '../components/ApiKeysPanel.tsx';

type SettingsTab = 'api_keys' | 'security' | 'workspace' | 'logs';

function formatRemainingTime(seconds: number): string {
  if (!seconds || seconds <= 0) return 'Expired';
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  return `${hrs}h ${mins}m remaining`;
}

export const SettingsPage: React.FC = () => {
  const {
    user,
    systemSettings,
    notify,
    securityStatus,
    lockPlatformNow,
    toggleRequire24hOtp,
  } = useFreska();

  const [activeTab, setActiveTab] = useState<SettingsTab>('api_keys');

  const [businessName, setBusinessName] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [timezone, setTimezone] = useState('UTC');
  const [defaultCurrency, setDefaultCurrency] = useState('EUR');
  const [invoicePrefix, setInvoicePrefix] = useState('FA');
  const [companyAddress, setCompanyAddress] = useState('');
  const [taxId, setTaxId] = useState('');
  const [saving, setSaving] = useState(false);
  const [togglingSecurity, setTogglingSecurity] = useState(false);

  const [serverLogs, setServerLogs] = useState<
    Array<{ id: string; source: string; message: string; details?: string; timestamp: string }>
  >([]);
  const [cronMeta, setCronMeta] = useState<{
    timezone: string;
    schedule: string;
    lastRunAt: string | null;
  } | null>(null);

  useEffect(() => {
    setBusinessName(systemSettings.businessName || 'FreskaAssist');
    setAdminEmail(systemSettings.adminEmail || '');
    setTimezone(systemSettings.timezone || 'UTC');
    setDefaultCurrency(systemSettings.defaultCurrency || 'EUR');
    setInvoicePrefix(systemSettings.invoicePrefix || 'FA');
    setCompanyAddress(systemSettings.companyAddress || '');
    setTaxId(systemSettings.taxId || '');
  }, [systemSettings]);

  const loadLogs = async () => {
    try {
      const data = await fetchServerLogs();
      setServerLogs(data.logs);
      setCronMeta(data.cron);
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    loadLogs();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await saveEntity('system_settings', 'default', {
        id: 'default',
        businessName: businessName.trim() || 'FreskaAssist',
        adminEmail: adminEmail.trim(),
        timezone: timezone.trim() || 'UTC',
        defaultCurrency,
        invoicePrefix: invoicePrefix.trim() || 'FA',
        companyAddress: companyAddress.trim(),
        taxId: taxId.trim(),
      });
      await updateServerCronTimezone(timezone.trim() || 'UTC');
      await loadLogs();
      notify('success', 'System settings updated.');
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to save system settings');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleOtp = async (next: boolean) => {
    setTogglingSecurity(true);
    try {
      await toggleRequire24hOtp(next);
    } finally {
      setTogglingSecurity(false);
    }
  };

  const otpEnabled = securityStatus?.require24hOtp ?? true;

  return (
    <div className="space-y-5 sm:space-y-6 max-w-5xl">
      <div>
        <h1 className="text-lg sm:text-xl font-semibold text-slate-900">
          Settings, Security &amp; API Keys
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
          Manage 24-hour Gmail verification code protection, API keys for external websites,
          business identity, and backend logs.
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-3 overflow-x-auto no-scrollbar">
        <button
          type="button"
          onClick={() => setActiveTab('api_keys')}
          className={`min-h-[44px] sm:min-h-0 shrink-0 inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
            activeTab === 'api_keys'
              ? 'bg-slate-900 text-white border-slate-900'
              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <KeyRound className="w-3.5 h-3.5" />
          <span>Integration API Keys</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('security')}
          className={`min-h-[44px] sm:min-h-0 shrink-0 inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
            activeTab === 'security'
              ? 'bg-slate-900 text-white border-slate-900'
              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>24h Security Code</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('workspace')}
          className={`min-h-[44px] sm:min-h-0 shrink-0 inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
            activeTab === 'workspace'
              ? 'bg-slate-900 text-white border-slate-900'
              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Workspace &amp; Currency</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('logs')}
          className={`min-h-[44px] sm:min-h-0 shrink-0 inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
            activeTab === 'logs'
              ? 'bg-slate-900 text-white border-slate-900'
              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Scheduler &amp; Logs</span>
        </button>
      </div>

      {activeTab === 'api_keys' && <ApiKeysPanel />}

      {activeTab === 'security' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-slate-900" />
                  <h2 className="text-sm font-semibold text-slate-900">
                    24-Hour Gmail Verification Code Protection
                  </h2>
                </div>
                <p className="text-xs text-slate-500 max-w-2xl leading-relaxed">
                  Automatically sends a one-time 6-digit security code to your linked Google Account
                  Gmail whenever 24 hours pass since your last verified login.
                </p>
              </div>
              <button
                type="button"
                disabled={togglingSecurity}
                onClick={() => handleToggleOtp(!otpEnabled)}
                className={`min-h-[44px] sm:min-h-0 px-4 py-2 text-xs font-medium rounded-lg border whitespace-nowrap shrink-0 transition-colors disabled:opacity-50 ${
                  otpEnabled
                    ? 'bg-emerald-50 text-emerald-900 border-emerald-200 hover:bg-emerald-100'
                    : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                }`}
              >
                {otpEnabled ? 'Protection Active (24h)' : 'Protection Paused — Enable'}
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3.5 space-y-1">
                <p className="text-[11px] font-medium uppercase tracking-wider text-slate-500">
                  Protected Gmail
                </p>
                <p className="text-xs font-mono font-semibold text-slate-900 break-all">
                  {user?.email || 'Not signed in'}
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3.5 space-y-1">
                <p className="text-[11px] font-medium uppercase tracking-wider text-slate-500">
                  Current 24h Session
                </p>
                <p className="text-xs font-medium text-slate-900 flex items-center gap-1.5">
                  {securityStatus?.unlocked && otpEnabled ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span className="tabular-nums">
                        {formatRemainingTime(securityStatus.remainingSeconds)}
                      </span>
                    </>
                  ) : (
                    <>
                      <Clock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      <span>{otpEnabled ? 'Verification required' : '24h gate disabled'}</span>
                    </>
                  )}
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3.5 space-y-1">
                <p className="text-[11px] font-medium uppercase tracking-wider text-slate-500">
                  Next Verification Due
                </p>
                <p className="text-xs font-mono text-slate-700">
                  {securityStatus?.expiresAt
                    ? new Date(securityStatus.expiresAt).toLocaleString()
                    : 'On next sign-in'}
                </p>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <p className="text-xs text-slate-500">
                Locking the workspace immediately ends your 24-hour verification session and sends a
                fresh 6-digit code to your Gmail.
              </p>
              <button
                type="button"
                onClick={lockPlatformNow}
                className="min-h-[44px] px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Lock Platform Now</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'workspace' && (
        <form
          onSubmit={handleSave}
          className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-4"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Business / Brand Name
              </label>
              <input
                type="text"
                required
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                className="w-full min-h-[44px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Administrator Contact Email
              </label>
              <input
                type="email"
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                className="w-full min-h-[44px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Timezone (IANA)
              </label>
              <input
                type="text"
                required
                value={timezone}
                onChange={(e) => setTimezone(e.target.value)}
                placeholder="America/Los_Angeles"
                className="w-full min-h-[44px] px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Default Currency
              </label>
              <select
                value={defaultCurrency}
                onChange={(e) => setDefaultCurrency(e.target.value)}
                className="w-full min-h-[44px] px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                <option value="EUR">EUR</option>
                <option value="USD">USD</option>
                <option value="GBP">GBP</option>
                <option value="CAD">CAD</option>
                <option value="MAD">MAD</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Invoice Number Prefix
              </label>
              <input
                type="text"
                required
                value={invoicePrefix}
                onChange={(e) => setInvoicePrefix(e.target.value)}
                className="w-full min-h-[44px] px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Company Address (for Invoices)
              </label>
              <input
                type="text"
                value={companyAddress}
                onChange={(e) => setCompanyAddress(e.target.value)}
                className="w-full min-h-[44px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Tax / Registration ID
              </label>
              <input
                type="text"
                value={taxId}
                onChange={(e) => setTaxId(e.target.value)}
                className="w-full min-h-[44px] px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={saving}
              className="w-full sm:w-auto min-h-[44px] inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{saving ? 'Saving...' : 'Save Settings'}</span>
            </button>
          </div>
        </form>
      )}

      {activeTab === 'logs' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-4 sm:px-5 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="min-w-0">
              <h2 className="text-sm font-semibold text-slate-900">
                Backend Scheduler &amp; Error Audit Log
              </h2>
              {cronMeta && (
                <p className="text-xs text-slate-500 font-mono mt-0.5 break-all">
                  Daily Cron: {cronMeta.schedule} ({cronMeta.timezone})
                  {cronMeta.lastRunAt ? ` · Last run: ${cronMeta.lastRunAt}` : ''}
                </p>
              )}
            </div>
            <button
              type="button"
              onClick={loadLogs}
              className="min-h-[44px] sm:min-h-0 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 shrink-0"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refresh</span>
            </button>
          </div>

          {serverLogs.length === 0 ? (
            <p className="p-8 text-center text-xs text-slate-500">
              No backend errors recorded.
            </p>
          ) : (
            <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
              {serverLogs.map((log) => (
                <div key={log.id} className="px-4 sm:px-5 py-3 text-xs space-y-1">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-mono font-semibold text-slate-800 uppercase">
                      {log.source}
                    </span>
                    <span className="font-mono text-slate-400 text-[11px]">{log.timestamp}</span>
                  </div>
                  <p className="text-slate-900 font-medium break-words">{log.message}</p>
                  {log.details && (
                    <p className="text-slate-500 font-mono break-all">{log.details}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};


