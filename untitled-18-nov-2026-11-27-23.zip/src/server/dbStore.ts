import fs from 'node:fs';
import path from 'node:path';

const DATA_DIR = path.resolve(process.cwd(), '.freska-data');
const ACCOUNTS_DIR = path.join(DATA_DIR, 'accounts');
const ACCOUNTS_INDEX_FILE = path.join(DATA_DIR, 'accounts-index.json');
const LEGACY_DB_FILE = path.join(DATA_DIR, 'freska-db.json');
const LEGACY_MIGRATED_FILE = path.join(DATA_DIR, 'freska-db.migrated.json');

export type StoreCollectionName =
  | 'clients'
  | 'services'
  | 'subscriptions'
  | 'payments'
  | 'payment_requests'
  | 'invoices'
  | 'invoice_items'
  | 'reminder_settings'
  | 'reminder_logs'
  | 'email_logs'
  | 'email_templates'
  | 'payment_gateway_settings'
  | 'webhook_events'
  | 'system_settings';

export type StoreData = Record<StoreCollectionName, Record<string, Record<string, unknown>>>;

const EMPTY_STORE: StoreData = {
  clients: {},
  services: {},
  subscriptions: {},
  payments: {},
  payment_requests: {},
  invoices: {},
  invoice_items: {},
  reminder_settings: {},
  reminder_logs: {},
  email_logs: {},
  email_templates: {},
  payment_gateway_settings: {},
  webhook_events: {},
  system_settings: {},
};

export function createEmptyStoreData(): StoreData {
  return structuredClone(EMPTY_STORE);
}

function ensureDirs() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(ACCOUNTS_DIR)) {
    fs.mkdirSync(ACCOUNTS_DIR, { recursive: true });
  }
}

function sanitizeUid(uid: string): string {
  return uid.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 128);
}

function getAccountStoreFile(uid: string): string {
  return path.join(ACCOUNTS_DIR, `${sanitizeUid(uid)}.json`);
}

export function registerAccountIndex(uid: string, email?: string | null): void {
  if (!uid) return;
  ensureDirs();
  let index: Record<string, string> = {};
  if (fs.existsSync(ACCOUNTS_INDEX_FILE)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(ACCOUNTS_INDEX_FILE, 'utf8'));
      if (parsed && typeof parsed === 'object') {
        index = parsed as Record<string, string>;
      }
    } catch {
      index = {};
    }
  }
  const cleanEmail = (email || '').trim().toLowerCase();
  if (cleanEmail && index[cleanEmail] !== uid) {
    index[cleanEmail] = uid;
    const tmp = `${ACCOUNTS_INDEX_FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(index, null, 2), 'utf8');
    fs.renameSync(tmp, ACCOUNTS_INDEX_FILE);
  }
}

export function resolveAccountUidByEmail(email?: string | null): string | null {
  if (!email) return null;
  ensureDirs();
  if (!fs.existsSync(ACCOUNTS_INDEX_FILE)) return null;
  try {
    const parsed = JSON.parse(fs.readFileSync(ACCOUNTS_INDEX_FILE, 'utf8')) as Record<string, string>;
    return parsed[email.trim().toLowerCase()] || null;
  } catch {
    return null;
  }
}

export function migrateLegacyGlobalStoreToAccount(uid: string, email?: string | null): void {
  if (!uid) return;
  ensureDirs();
  registerAccountIndex(uid, email);

  const accountFile = getAccountStoreFile(uid);
  const isLegacyOwner = (email || '').trim().toLowerCase() === 'zwizoo175@gmail.com';
  if (!isLegacyOwner || !fs.existsSync(LEGACY_DB_FILE) || fs.existsSync(accountFile)) {
    return;
  }

  try {
    const raw = fs.readFileSync(LEGACY_DB_FILE, 'utf8');
    const parsed = JSON.parse(raw) as Partial<StoreData>;
    const migrated: StoreData = createEmptyStoreData();

    for (const colKey of Object.keys(EMPTY_STORE) as StoreCollectionName[]) {
      const sourceCol = parsed[colKey];
      if (!sourceCol || typeof sourceCol !== 'object') continue;
      for (const [docId, docVal] of Object.entries(sourceCol)) {
        if (!docVal || typeof docVal !== 'object') continue;
        migrated[colKey][docId] = {
          ...docVal,
          id: docId,
          _cloudSynced: false,
        };
      }
    }

    writeAccountStore(uid, migrated);
    fs.renameSync(LEGACY_DB_FILE, LEGACY_MIGRATED_FILE);
  } catch (err) {
    console.error('Failed to migrate legacy global store:', err);
  }
}

export function readAccountStore(uid?: string | null): StoreData {
  if (!uid) {
    return createEmptyStoreData();
  }
  ensureDirs();
  const file = getAccountStoreFile(uid);
  if (!fs.existsSync(file)) {
    return createEmptyStoreData();
  }
  try {
    const raw = fs.readFileSync(file, 'utf8');
    const parsed = JSON.parse(raw) as Partial<StoreData>;
    return {
      ...createEmptyStoreData(),
      ...parsed,
    };
  } catch (err) {
    console.error('Failed to read account store:', err);
    return createEmptyStoreData();
  }
}

export function writeAccountStore(uid: string, store: StoreData): void {
  if (!uid) return;
  ensureDirs();
  const file = getAccountStoreFile(uid);
  const tmpFile = `${file}.tmp`;
  fs.writeFileSync(tmpFile, JSON.stringify(store, null, 2), 'utf8');
  fs.renameSync(tmpFile, file);
}

export function upsertAccountDocument(
  uid: string,
  collectionName: StoreCollectionName,
  docId: string,
  data: Record<string, unknown>
): Record<string, unknown> {
  const store = readAccountStore(uid);
  if (!store[collectionName]) {
    store[collectionName] = {};
  }
  const existing = store[collectionName][docId] || {};
  const nowIso = new Date().toISOString();
  const merged = {
    ...existing,
    ...data,
    id: docId,
    createdAt: existing.createdAt || data.createdAt || nowIso,
    updatedAt: nowIso,
  };
  store[collectionName][docId] = merged;
  writeAccountStore(uid, store);
  return merged;
}

export function deleteAccountDocument(
  uid: string,
  collectionName: StoreCollectionName,
  docId: string
): void {
  const store = readAccountStore(uid);
  if (store[collectionName] && store[collectionName][docId]) {
    delete store[collectionName][docId];
    writeAccountStore(uid, store);
  }
}

export function mergeCloudStoreSnapshot(
  uid: string,
  cloudCollections: Partial<Record<StoreCollectionName, Array<Record<string, unknown>>>>,
  allowEmptyCollections: string[] = []
): StoreData {
  const store = readAccountStore(uid);
  const nowIso = new Date().toISOString();
  const allowEmptySet = new Set(allowEmptyCollections);

  for (const [colKey, docs] of Object.entries(cloudCollections)) {
    const colName = colKey as StoreCollectionName;
    if (!store[colName] || !Array.isArray(docs)) continue;

    // Never allow an unconfirmed/offline empty array to wipe existing synced account data
    if (docs.length === 0 && !allowEmptySet.has(colName) && Object.keys(store[colName]).length > 0) {
      continue;
    }

    const nextMap: Record<string, Record<string, unknown>> = {};

    // Preserve any local/API records that have not yet been synced to Cloud Firestore
    for (const [docId, existingDoc] of Object.entries(store[colName])) {
      if (existingDoc && existingDoc._cloudSynced !== true) {
        nextMap[docId] = existingDoc;
      }
    }

    // Upsert authoritative Cloud Firestore records
    for (const doc of docs) {
      const docId = typeof doc.id === 'string' ? doc.id : '';
      if (!docId) continue;
      nextMap[docId] = {
        ...doc,
        id: docId,
        createdAt: doc.createdAt || nowIso,
        updatedAt: doc.updatedAt || nowIso,
        _cloudSynced: true,
      };
    }

    store[colName] = nextMap;
  }

  writeAccountStore(uid, store);
  return store;
}
