import fs from 'node:fs';
import path from 'node:path';
import type { InvoicePdfPayload } from './pdf.ts';

const DATA_DIR = path.resolve(process.cwd(), '.freska-data');
const INVOICES_DIR = path.join(DATA_DIR, 'invoices');
const BANK_REQUESTS_DIR = path.join(DATA_DIR, 'bank-requests');
const LOGS_FILE = path.join(DATA_DIR, 'server-logs.json');
const WEBHOOK_CACHE_FILE = path.join(DATA_DIR, 'webhook-events.json');

function ensureDirs() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(INVOICES_DIR)) fs.mkdirSync(INVOICES_DIR, { recursive: true });
  if (!fs.existsSync(BANK_REQUESTS_DIR)) fs.mkdirSync(BANK_REQUESTS_DIR, { recursive: true });
}

export interface BankInstructionSnapshot {
  requestId: string;
  reference: string;
  clientId?: string;
  subscriptionId?: string;
  billingType?: 'subscription' | 'one_time';
  clientName: string;
  businessName: string;
  serviceName: string;
  description: string;
  amount: number;
  currency: string;
  dueDate: string;
  status: string;
  bankAccountName: string;
  bankName: string;
  bankIban: string;
  bankBic: string;
  bankInstructions: string;
  companyName: string;
  paidAt?: string;
  paidMethod?: 'bank_transfer' | 'card' | 'manual';
  transactionReference?: string;
  testMode?: boolean;
  clientReportedTransfer?: boolean;
  clientReportedAt?: string;
  clientTransferNote?: string;
  updatedAt: string;
}

export function savePublicInvoiceSnapshot(invoiceId: string, payload: InvoicePdfPayload): void {
  ensureDirs();
  const safeId = invoiceId.replace(/[^a-zA-Z0-9_\-]/g, '');
  fs.writeFileSync(
    path.join(INVOICES_DIR, `${safeId}.json`),
    JSON.stringify(payload, null, 2),
    'utf8'
  );
}

export function readPublicInvoiceSnapshot(invoiceId: string): InvoicePdfPayload | null {
  ensureDirs();
  const safeId = invoiceId.replace(/[^a-zA-Z0-9_\-]/g, '');
  const target = path.join(INVOICES_DIR, `${safeId}.json`);
  if (!fs.existsSync(target)) return null;
  return JSON.parse(fs.readFileSync(target, 'utf8')) as InvoicePdfPayload;
}

export function saveBankInstructionSnapshot(snapshot: BankInstructionSnapshot): void {
  ensureDirs();
  const safeId = snapshot.requestId.replace(/[^a-zA-Z0-9_\-]/g, '');
  fs.writeFileSync(
    path.join(BANK_REQUESTS_DIR, `${safeId}.json`),
    JSON.stringify(snapshot, null, 2),
    'utf8'
  );
}

export function readBankInstructionSnapshot(requestId: string): BankInstructionSnapshot | null {
  ensureDirs();
  const safeId = requestId.replace(/[^a-zA-Z0-9_\-]/g, '');
  const target = path.join(BANK_REQUESTS_DIR, `${safeId}.json`);
  if (!fs.existsSync(target)) return null;
  return JSON.parse(fs.readFileSync(target, 'utf8')) as BankInstructionSnapshot;
}

export interface ServerErrorLog {
  id: string;
  source: string;
  message: string;
  details?: string;
  timestamp: string;
}

export function appendServerErrorLog(source: string, message: string, details?: string): void {
  ensureDirs();
  let logs: ServerErrorLog[] = [];
  if (fs.existsSync(LOGS_FILE)) {
    try {
      logs = JSON.parse(fs.readFileSync(LOGS_FILE, 'utf8')) as ServerErrorLog[];
    } catch {
      logs = [];
    }
  }
  logs.unshift({
    id: `err_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    source,
    message,
    details,
    timestamp: new Date().toISOString(),
  });
  fs.writeFileSync(LOGS_FILE, JSON.stringify(logs.slice(0, 100), null, 2), 'utf8');
}

export function readServerErrorLogs(): ServerErrorLog[] {
  ensureDirs();
  if (!fs.existsSync(LOGS_FILE)) return [];
  try {
    return JSON.parse(fs.readFileSync(LOGS_FILE, 'utf8')) as ServerErrorLog[];
  } catch {
    return [];
  }
}

export interface BufferedWebhookEvent {
  externalEventId: string;
  provider: string;
  eventType: string;
  paymentRequestId?: string;
  sessionId?: string;
  amountPaid?: number;
  currency?: string;
  transactionReference?: string;
  summary: string;
  receivedAt: string;
  syncedToFirestore: boolean;
}

export function recordBufferedWebhookEvent(evt: BufferedWebhookEvent): boolean {
  ensureDirs();
  let events: BufferedWebhookEvent[] = [];
  if (fs.existsSync(WEBHOOK_CACHE_FILE)) {
    try {
      events = JSON.parse(fs.readFileSync(WEBHOOK_CACHE_FILE, 'utf8')) as BufferedWebhookEvent[];
    } catch {
      events = [];
    }
  }
  if (events.some((e) => e.externalEventId === evt.externalEventId)) {
    return false; // Idempotent duplicate protection
  }
  events.unshift(evt);
  fs.writeFileSync(WEBHOOK_CACHE_FILE, JSON.stringify(events.slice(0, 200), null, 2), 'utf8');
  return true;
}

export function getPendingWebhookEvents(): BufferedWebhookEvent[] {
  ensureDirs();
  if (!fs.existsSync(WEBHOOK_CACHE_FILE)) return [];
  try {
    const events = JSON.parse(fs.readFileSync(WEBHOOK_CACHE_FILE, 'utf8')) as BufferedWebhookEvent[];
    return events.filter((e) => !e.syncedToFirestore);
  } catch {
    return [];
  }
}

export function markWebhookEventSynced(externalEventId: string): void {
  ensureDirs();
  if (!fs.existsSync(WEBHOOK_CACHE_FILE)) return;
  try {
    const events = JSON.parse(fs.readFileSync(WEBHOOK_CACHE_FILE, 'utf8')) as BufferedWebhookEvent[];
    const updated = events.map((e) =>
      e.externalEventId === externalEventId ? { ...e, syncedToFirestore: true } : e
    );
    fs.writeFileSync(WEBHOOK_CACHE_FILE, JSON.stringify(updated, null, 2), 'utf8');
  } catch {
    // ignore
  }
}
