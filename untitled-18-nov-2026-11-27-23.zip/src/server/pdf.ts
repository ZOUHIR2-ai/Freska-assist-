import fs from 'node:fs';
import path from 'node:path';
import PDFDocument from 'pdfkit';

export interface InvoicePdfPayload {
  invoiceNumber: string;
  invoiceDate: string;
  paymentDate: string;
  status: string;
  clientName: string;
  businessName: string;
  clientEmail: string;
  serviceName: string;
  serviceDescription?: string;
  paymentType: 'subscription' | 'one_time';
  paymentMethod: 'bank_transfer' | 'manual' | 'card';
  paymentReference?: string;
  manuallyVerified?: boolean;
  amount: number;
  currency: string;
  companyName?: string;
  companyAddress?: string;
  companyEmail?: string;
  taxId?: string;
}

const BUSINESS_LOGO_PATH = path.resolve(
  process.cwd(),
  'public/assets/aistudio/IMG-20261117-WA0014_9dd05831.jpg'
);

function formatMethod(method: string): string {
  if (method === 'bank_transfer') return 'Bank Transfer (Virement)';
  if (method === 'manual') return 'Manual Payment (Offline)';
  if (method === 'card') return 'Credit / Debit Card';
  return method;
}

function formatType(type: string): string {
  return type === 'subscription' ? 'Recurring Subscription' : 'One-Time Purchase';
}

function formatCurrency(amount: number, currency: string): string {
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency || 'EUR',
    }).format(amount);
  } catch {
    return `${currency || 'EUR'} ${amount.toFixed(2)}`;
  }
}

export function generateInvoicePdfBuffer(data: InvoicePdfPayload): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 52 });
    const chunks: Buffer[] = [];

    doc.on('data', (chunk: Buffer) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    const companyName = data.companyName || 'FreskaAssist';
    const companyAddress = data.companyAddress || 'Private Billing & Client Administration';
    const companyEmail = data.companyEmail || '';
    const taxId = data.taxId || '';

    const statusUpper = (data.status || 'PAID').toUpperCase();
    const statusBadgeTextColor =
      statusUpper === 'PAID'
        ? '#4ADE80'
        : statusUpper === 'PENDING'
        ? '#FBBF24'
        : '#F87171';

    // Dark Branded Header Band matching the black-ground FreskaAssist logo
    doc.roundedRect(52, 40, 491, 76, 8).fill('#000000');

    const hasLogo = fs.existsSync(BUSINESS_LOGO_PATH);
    if (hasLogo) {
      doc.image(BUSINESS_LOGO_PATH, 66, 51, { height: 54 });
    } else {
      doc
        .fillColor('#FFFFFF')
        .fontSize(22)
        .font('Helvetica-Bold')
        .text('FreskaAssist', 68, 64);
    }

    // Right Invoice Title & Status inside Header Band
    doc
      .fillColor('#FFFFFF')
      .fontSize(18)
      .font('Helvetica-Bold')
      .text('INVOICE', 340, 52, { align: 'right', width: 185 });

    doc
      .fillColor('#CBD5E1')
      .fontSize(9.5)
      .font('Helvetica')
      .text(`No. ${data.invoiceNumber}`, 340, 74, { align: 'right', width: 185 });

    doc
      .fillColor(statusBadgeTextColor)
      .fontSize(9.5)
      .font('Helvetica-Bold')
      .text(`STATUS: ${statusUpper}`, 340, 91, { align: 'right', width: 185 });

    // Issuer Business Metadata Strip below Header Band
    let issuerY = 128;
    const issuerLineParts: string[] = [];
    if (companyName && companyName !== 'FreskaAssist') {
      issuerLineParts.push(companyName);
    }
    if (companyAddress) issuerLineParts.push(companyAddress);
    if (companyEmail) issuerLineParts.push(companyEmail);
    if (taxId) issuerLineParts.push(`Tax / Reg ID: ${taxId}`);

    if (issuerLineParts.length > 0) {
      doc
        .fillColor('#475569')
        .fontSize(8.5)
        .font('Helvetica')
        .text(issuerLineParts.join('  ·  '), 52, issuerY, { width: 491 });
      issuerY += 18;
    }

    // Hairline Divider
    const dividerY = Math.max(154, issuerY + 6);
    doc
      .moveTo(52, dividerY)
      .lineTo(543, dividerY)
      .strokeColor('#E2E8F0')
      .lineWidth(1)
      .stroke();

    // Billed To & Invoice Metadata Columns
    const infoTop = dividerY + 18;
    doc.fillColor('#64748B').fontSize(8.5).font('Helvetica-Bold').text('BILLED TO', 52, infoTop);
    doc
      .fillColor('#0F172A')
      .fontSize(12)
      .font('Helvetica-Bold')
      .text(data.businessName || data.clientName, 52, infoTop + 16, { width: 255 });
    doc
      .fillColor('#334155')
      .fontSize(10)
      .font('Helvetica')
      .text(data.clientName, 52, infoTop + 33, { width: 255 });
    doc
      .fillColor('#475569')
      .fontSize(9.5)
      .text(data.clientEmail, 52, infoTop + 48, { width: 255 });

    // Right Metadata Grid
    const metaX = 330;
    doc
      .fillColor('#64748B')
      .fontSize(8.5)
      .font('Helvetica-Bold')
      .text('INVOICE DETAILS', metaX, infoTop);

    const rows: [string, string][] = [
      ['Invoice Date', data.invoiceDate],
      ['Payment Date', data.paymentDate || 'Pending'],
      ['Billing Type', formatType(data.paymentType)],
      ['Payment Method', formatMethod(data.paymentMethod)],
      ['Reference', data.paymentReference || 'N/A'],
    ];

    let metaY = infoTop + 16;
    for (const [label, val] of rows) {
      doc.fillColor('#64748B').fontSize(9).font('Helvetica').text(label, metaX, metaY, { width: 90 });
      doc
        .fillColor('#0F172A')
        .fontSize(9)
        .font('Helvetica-Bold')
        .text(val, metaX + 92, metaY, { width: 121, align: 'right' });
      metaY += 16;
    }

    // Line Items Table Header
    const tableTop = Math.max(metaY + 24, infoTop + 118);
    doc.rect(52, tableTop, 491, 28).fill('#F8FAFC');
    doc
      .moveTo(52, tableTop)
      .lineTo(543, tableTop)
      .strokeColor('#E2E8F0')
      .lineWidth(1)
      .stroke();
    doc
      .moveTo(52, tableTop + 28)
      .lineTo(543, tableTop + 28)
      .strokeColor('#E2E8F0')
      .lineWidth(1)
      .stroke();

    doc.fillColor('#475569').fontSize(8.5).font('Helvetica-Bold');
    doc.text('SERVICE & DESCRIPTION', 64, tableTop + 10);
    doc.text('TYPE', 320, tableTop + 10);
    doc.text('AMOUNT', 430, tableTop + 10, { width: 100, align: 'right' });

    // Line Item Row
    const itemTop = tableTop + 42;
    doc
      .fillColor('#0F172A')
      .fontSize(10.5)
      .font('Helvetica-Bold')
      .text(data.serviceName, 64, itemTop, { width: 245 });
    const descY = itemTop + 16;
    const description = data.serviceDescription || 'Professional service delivery';
    doc
      .fillColor('#475569')
      .fontSize(9)
      .font('Helvetica')
      .text(description, 64, descY, { width: 245 });

    doc
      .fillColor('#334155')
      .fontSize(9.5)
      .font('Helvetica')
      .text(formatType(data.paymentType), 320, itemTop, { width: 105 });
    doc
      .fillColor('#0F172A')
      .fontSize(10.5)
      .font('Helvetica-Bold')
      .text(formatCurrency(data.amount, data.currency), 430, itemTop, { width: 100, align: 'right' });

    const dividerAfterItem = Math.max(descY + 40, itemTop + 56);
    doc
      .moveTo(52, dividerAfterItem)
      .lineTo(543, dividerAfterItem)
      .strokeColor('#E2E8F0')
      .lineWidth(1)
      .stroke();

    // Totals Block
    const totalsTop = dividerAfterItem + 22;
    doc.fillColor('#64748B').fontSize(9.5).font('Helvetica').text('Subtotal', 340, totalsTop);
    doc
      .fillColor('#0F172A')
      .fontSize(9.5)
      .font('Helvetica')
      .text(formatCurrency(data.amount, data.currency), 430, totalsTop, { width: 100, align: 'right' });

    doc
      .moveTo(340, totalsTop + 22)
      .lineTo(543, totalsTop + 22)
      .strokeColor('#CBD5E1')
      .lineWidth(1)
      .stroke();

    doc.fillColor('#0F172A').fontSize(12).font('Helvetica-Bold').text('Total Paid', 340, totalsTop + 34);
    doc
      .fillColor('#0F172A')
      .fontSize(13)
      .font('Helvetica-Bold')
      .text(formatCurrency(data.amount, data.currency), 430, totalsTop + 33, { width: 100, align: 'right' });

    // Verification Box
    const noteTop = totalsTop + 88;
    doc.rect(52, noteTop, 491, 56).fill('#F8FAFC');
    doc.rect(52, noteTop, 491, 56).strokeColor('#E2E8F0').lineWidth(1).stroke();

    const verificationLabel = data.manuallyVerified
      ? 'Verification: Manually verified by FreskaAssist administrator'
      : `Verification: Confirmed via ${formatMethod(data.paymentMethod)}`;

    doc.fillColor('#0F172A').fontSize(9).font('Helvetica-Bold').text(verificationLabel, 66, noteTop + 14);
    doc
      .fillColor('#64748B')
      .fontSize(8.5)
      .font('Helvetica')
      .text(
        `Invoice Number ${data.invoiceNumber} · Reference ${data.paymentReference || 'N/A'} · Currency ${data.currency}`,
        66,
        noteTop + 31
      );

    // Footer
    doc
      .fillColor('#94A3B8')
      .fontSize(8)
      .font('Helvetica')
      .text('Generated by FreskaAssist Billing Administration', 52, 760, {
        align: 'center',
        width: 491,
      });

    doc.end();
  });
}
