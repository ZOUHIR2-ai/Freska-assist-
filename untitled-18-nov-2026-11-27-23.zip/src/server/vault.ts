import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const VAULT_FILE = path.resolve(process.cwd(), '.freska-vault.json');

export interface GatewayCredentials {
  provider: 'stripe';
  environment: 'test' | 'live';
  publicKey: string;
  secretKey: string;
  webhookSecret: string;
  enabled: boolean;
  connectionVerified: boolean;
  lastVerifiedAt: string | null;
  accountId: string | null;
  updatedAt: string;
}

export interface PublicGatewayStatus {
  provider: 'stripe';
  environment: 'test' | 'live';
  enabled: boolean;
  hasPublicKey: boolean;
  publicKeyMasked: string;
  hasSecretKey: boolean;
  secretKeyLast4: string;
  hasWebhookSecret: boolean;
  connectionVerified: boolean;
  lastVerifiedAt: string | null;
  accountId: string | null;
  updatedAt: string;
}

function getEncryptionKey(): Buffer {
  const secret =
    process.env.FRESKA_VAULT_SECRET ||
    process.env.GEMINI_API_KEY ||
    'freska-assist-local-vault-key-v1';
  return crypto.createHash('sha256').update(secret).digest();
}

function encryptPayload(plaintext: string): string {
  const iv = crypto.randomBytes(12);
  const key = getEncryptionKey();
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return JSON.stringify({
    iv: iv.toString('hex'),
    tag: tag.toString('hex'),
    data: encrypted.toString('hex'),
  });
}

function decryptPayload(raw: string): string {
  const parsed = JSON.parse(raw) as { iv: string; tag: string; data: string };
  const key = getEncryptionKey();
  const decipher = crypto.createDecipheriv(
    'aes-256-gcm',
    key,
    Buffer.from(parsed.iv, 'hex')
  );
  decipher.setAuthTag(Buffer.from(parsed.tag, 'hex'));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(parsed.data, 'hex')),
    decipher.final(),
  ]);
  return decrypted.toString('utf8');
}

const DEFAULT_CREDENTIALS: GatewayCredentials = {
  provider: 'stripe',
  environment: 'test',
  publicKey: '',
  secretKey: '',
  webhookSecret: '',
  enabled: false,
  connectionVerified: false,
  lastVerifiedAt: null,
  accountId: null,
  updatedAt: new Date(0).toISOString(),
};

export function readGatewayCredentials(): GatewayCredentials {
  try {
    if (!fs.existsSync(VAULT_FILE)) {
      return { ...DEFAULT_CREDENTIALS };
    }
    const raw = fs.readFileSync(VAULT_FILE, 'utf8');
    const json = decryptPayload(raw);
    const parsed = JSON.parse(json) as Partial<GatewayCredentials>;
    return {
      ...DEFAULT_CREDENTIALS,
      ...parsed,
    };
  } catch (err) {
    console.error('Failed to read encrypted gateway vault:', err);
    return { ...DEFAULT_CREDENTIALS };
  }
}

export function writeGatewayCredentials(creds: GatewayCredentials): void {
  const serialized = JSON.stringify(creds);
  const encrypted = encryptPayload(serialized);
  fs.writeFileSync(VAULT_FILE, encrypted, { encoding: 'utf8', mode: 0o600 });
}

function maskKey(val: string): string {
  if (!val) return '';
  if (val.length <= 10) return '••••' + val.slice(-4);
  return `${val.slice(0, 7)}••••${val.slice(-4)}`;
}

export function getPublicGatewayStatus(): PublicGatewayStatus {
  const creds = readGatewayCredentials();
  return {
    provider: creds.provider,
    environment: creds.environment,
    enabled: creds.enabled,
    hasPublicKey: Boolean(creds.publicKey),
    publicKeyMasked: maskKey(creds.publicKey),
    hasSecretKey: Boolean(creds.secretKey),
    secretKeyLast4: creds.secretKey ? creds.secretKey.slice(-4) : '',
    hasWebhookSecret: Boolean(creds.webhookSecret),
    connectionVerified: creds.connectionVerified,
    lastVerifiedAt: creds.lastVerifiedAt,
    accountId: creds.accountId,
    updatedAt: creds.updatedAt,
  };
}

export function signToken(payload: string): string {
  const key = getEncryptionKey();
  return crypto.createHmac('sha256', key).update(payload).digest('hex');
}

export function verifySignature(payload: string, sig: string): boolean {
  if (!sig) return false;
  const expected = signToken(payload);
  const a = Buffer.from(expected, 'hex');
  const b = Buffer.from(sig, 'hex');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

// --- Encrypted SMTP & Verified Domain Delivery Vault ---
const SMTP_VAULT_FILE = path.resolve(process.cwd(), '.freska-email-vault.json');

export type SmtpPreset = 'custom' | 'brevo' | 'resend' | 'sendgrid' | 'gmail_smtp';

export interface SmtpCredentials {
  preset: SmtpPreset;
  host: string;
  port: number;
  secure: boolean;
  username: string;
  password: string;
  fromName: string;
  fromEmail: string;
  replyTo: string;
  publicPortalUrl: string;
  enabled: boolean;
  connectionVerified: boolean;
  lastVerifiedAt: string | null;
  updatedAt: string;
}

export interface PublicSmtpStatus {
  preset: SmtpPreset;
  host: string;
  port: number;
  secure: boolean;
  username: string;
  hasPassword: boolean;
  passwordLast4: string;
  fromName: string;
  fromEmail: string;
  replyTo: string;
  publicPortalUrl: string;
  enabled: boolean;
  connectionVerified: boolean;
  lastVerifiedAt: string | null;
  updatedAt: string;
}

const DEFAULT_SMTP_CREDENTIALS: SmtpCredentials = {
  preset: 'custom',
  host: '',
  port: 587,
  secure: false,
  username: '',
  password: '',
  fromName: 'FreskaAssist',
  fromEmail: '',
  replyTo: '',
  publicPortalUrl: '',
  enabled: false,
  connectionVerified: false,
  lastVerifiedAt: null,
  updatedAt: new Date(0).toISOString(),
};

export function readSmtpCredentials(): SmtpCredentials {
  try {
    if (!fs.existsSync(SMTP_VAULT_FILE)) {
      return { ...DEFAULT_SMTP_CREDENTIALS };
    }
    const raw = fs.readFileSync(SMTP_VAULT_FILE, 'utf8');
    const json = decryptPayload(raw);
    const parsed = JSON.parse(json) as Partial<SmtpCredentials>;
    return {
      ...DEFAULT_SMTP_CREDENTIALS,
      ...parsed,
    };
  } catch (err) {
    console.error('Failed to read encrypted email vault:', err);
    return { ...DEFAULT_SMTP_CREDENTIALS };
  }
}

export function writeSmtpCredentials(creds: SmtpCredentials): void {
  const serialized = JSON.stringify(creds);
  const encrypted = encryptPayload(serialized);
  fs.writeFileSync(SMTP_VAULT_FILE, encrypted, { encoding: 'utf8', mode: 0o600 });
}

export function getPublicSmtpStatus(): PublicSmtpStatus {
  const creds = readSmtpCredentials();
  return {
    preset: creds.preset,
    host: creds.host,
    port: creds.port,
    secure: creds.secure,
    username: creds.username,
    hasPassword: Boolean(creds.password),
    passwordLast4: creds.password ? creds.password.slice(-4) : '',
    fromName: creds.fromName,
    fromEmail: creds.fromEmail,
    replyTo: creds.replyTo,
    publicPortalUrl: creds.publicPortalUrl,
    enabled: creds.enabled,
    connectionVerified: creds.connectionVerified,
    lastVerifiedAt: creds.lastVerifiedAt,
    updatedAt: creds.updatedAt,
  };
}

