import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const DATA_DIR = path.resolve(process.cwd(), '.freska-data');
const API_KEYS_FILE = path.join(DATA_DIR, 'api-keys.json');
const API_ACTIVITY_FILE = path.join(DATA_DIR, 'api-activity.json');

export const ALL_API_SCOPES = [
  'clients:read',
  'clients:write',
  'payments:read',
  'payments:write',
  'subscriptions:read',
  'subscriptions:write',
  'invoices:read',
  'services:read',
] as const;

export type ApiKeyScope = (typeof ALL_API_SCOPES)[number];

export interface StoredApiKeyRecord {
  id: string;
  name: string;
  keyPrefix: string;
  keyHash: string;
  scopes: ApiKeyScope[];
  active: boolean;
  ownerUid?: string;
  ownerEmail?: string;
  createdAt: string;
  lastUsedAt: string | null;
  requestCount: number;
}

export type PublicApiKeyRecord = Omit<StoredApiKeyRecord, 'keyHash'>;

export interface ApiActivityEntry {
  id: string;
  keyId: string;
  keyName: string;
  ownerUid?: string;
  method: string;
  path: string;
  statusCode: number;
  timestamp: string;
}

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readStoredKeys(): StoredApiKeyRecord[] {
  ensureDir();
  if (!fs.existsSync(API_KEYS_FILE)) {
    return [];
  }
  try {
    const raw = fs.readFileSync(API_KEYS_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as StoredApiKeyRecord[]) : [];
  } catch {
    return [];
  }
}

function writeStoredKeys(keys: StoredApiKeyRecord[]): void {
  ensureDir();
  const tmpFile = `${API_KEYS_FILE}.tmp`;
  fs.writeFileSync(tmpFile, JSON.stringify(keys, null, 2), 'utf8');
  fs.renameSync(tmpFile, API_KEYS_FILE);
}

function hashApiKey(rawKey: string): string {
  return crypto.createHash('sha256').update(rawKey).digest('hex');
}

function toPublicKey(record: StoredApiKeyRecord): PublicApiKeyRecord {
  const { keyHash: _omitted, ...safe } = record;
  return safe;
}

function isOwnedByAccount(
  record: { ownerUid?: string; ownerEmail?: string },
  uid?: string | null,
  email?: string | null
): boolean {
  if (!uid) return false;
  if (record.ownerUid) {
    return record.ownerUid === uid;
  }
  const cleanEmail = (email || '').trim().toLowerCase();
  if (record.ownerEmail) {
    return record.ownerEmail.trim().toLowerCase() === cleanEmail;
  }
  // Legacy keys created before per-account ownership belong strictly to primary admin
  return cleanEmail === 'zwizoo175@gmail.com';
}

export function sanitizeScopes(input: unknown): ApiKeyScope[] {
  if (!Array.isArray(input) || input.length === 0) {
    return [...ALL_API_SCOPES];
  }
  const validSet = new Set<string>(ALL_API_SCOPES);
  const filtered = input.filter((s): s is ApiKeyScope => typeof s === 'string' && validSet.has(s));
  return filtered.length > 0 ? Array.from(new Set(filtered)) : [...ALL_API_SCOPES];
}

export function listApiKeysForAccount(
  uid?: string | null,
  email?: string | null
): PublicApiKeyRecord[] {
  if (!uid) return [];
  return readStoredKeys()
    .filter((k) => isOwnedByAccount(k, uid, email))
    .map(toPublicKey);
}

export function createApiKey(
  name: string,
  scopesInput?: unknown,
  owner?: { uid: string; email?: string | null }
): { record: PublicApiKeyRecord; plaintextKey: string } {
  const cleanName = name.trim().slice(0, 80) || 'External Website Integration';
  const scopes = sanitizeScopes(scopesInput);
  const randomSecret = crypto.randomBytes(18).toString('hex');
  const plaintextKey = `fa_live_${randomSecret}`;
  const keyPrefix = `${plaintextKey.slice(0, 12)}••••${plaintextKey.slice(-4)}`;
  const keyHash = hashApiKey(plaintextKey);
  const nowIso = new Date().toISOString();

  const record: StoredApiKeyRecord = {
    id: `key_${Date.now().toString(36)}_${crypto.randomBytes(3).toString('hex')}`,
    name: cleanName,
    keyPrefix,
    keyHash,
    scopes,
    active: true,
    ownerUid: owner?.uid,
    ownerEmail: owner?.email || undefined,
    createdAt: nowIso,
    lastUsedAt: null,
    requestCount: 0,
  };

  const keys = readStoredKeys();
  keys.unshift(record);
  writeStoredKeys(keys);

  return {
    record: toPublicKey(record),
    plaintextKey,
  };
}

export function toggleApiKeyActive(
  id: string,
  active: boolean,
  uid?: string | null,
  email?: string | null
): PublicApiKeyRecord | null {
  const keys = readStoredKeys();
  const idx = keys.findIndex((k) => k.id === id && isOwnedByAccount(k, uid, email));
  if (idx === -1) return null;
  keys[idx] = {
    ...keys[idx],
    active: Boolean(active),
  };
  writeStoredKeys(keys);
  return toPublicKey(keys[idx]);
}

export function deleteApiKey(
  id: string,
  uid?: string | null,
  email?: string | null
): boolean {
  const keys = readStoredKeys();
  const next = keys.filter((k) => !(k.id === id && isOwnedByAccount(k, uid, email)));
  if (next.length === keys.length) return false;
  writeStoredKeys(next);
  return true;
}

export function verifyApiKeyToken(rawKey: string): PublicApiKeyRecord | null {
  const trimmed = rawKey.trim();
  if (!trimmed.startsWith('fa_live_')) {
    return null;
  }
  const incomingHash = hashApiKey(trimmed);
  const incomingBuf = Buffer.from(incomingHash, 'hex');
  const keys = readStoredKeys();

  let matchedIndex = -1;
  for (let i = 0; i < keys.length; i++) {
    const candidateBuf = Buffer.from(keys[i].keyHash, 'hex');
    if (
      candidateBuf.length === incomingBuf.length &&
      crypto.timingSafeEqual(candidateBuf, incomingBuf)
    ) {
      matchedIndex = i;
      break;
    }
  }

  if (matchedIndex === -1) return null;
  const matched = keys[matchedIndex];
  if (!matched.active) return null;

  keys[matchedIndex] = {
    ...matched,
    lastUsedAt: new Date().toISOString(),
    requestCount: (matched.requestCount || 0) + 1,
  };
  writeStoredKeys(keys);

  return toPublicKey(keys[matchedIndex]);
}

export function recordApiActivity(entry: Omit<ApiActivityEntry, 'id' | 'timestamp'>): void {
  ensureDir();
  let entries: ApiActivityEntry[] = [];
  if (fs.existsSync(API_ACTIVITY_FILE)) {
    try {
      entries = JSON.parse(fs.readFileSync(API_ACTIVITY_FILE, 'utf8')) as ApiActivityEntry[];
    } catch {
      entries = [];
    }
  }
  entries.unshift({
    id: `act_${Date.now()}_${crypto.randomBytes(2).toString('hex')}`,
    ...entry,
    timestamp: new Date().toISOString(),
  });
  fs.writeFileSync(API_ACTIVITY_FILE, JSON.stringify(entries.slice(0, 80), null, 2), 'utf8');
}

export function readApiActivityForAccount(
  uid?: string | null,
  email?: string | null
): ApiActivityEntry[] {
  if (!uid) return [];
  ensureDir();
  if (!fs.existsSync(API_ACTIVITY_FILE)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(API_ACTIVITY_FILE, 'utf8'));
    if (!Array.isArray(parsed)) return [];
    const cleanEmail = (email || '').trim().toLowerCase();
    return (parsed as ApiActivityEntry[]).filter((entry) => {
      if (entry.ownerUid) return entry.ownerUid === uid;
      return cleanEmail === 'zwizoo175@gmail.com';
    });
  } catch {
    return [];
  }
}
