import nodemailer, { type SendMailOptions } from 'nodemailer';

export interface SendGmailArgs {
  accessToken: string;
  fromName?: string;
  fromEmail: string;
  to: string;
  subject: string;
  bodyText: string;
  attachment?: {
    filename: string;
    mimeType: string;
    contentBuffer: Buffer;
  };
}

const mimeTransport = nodemailer.createTransport({
  streamTransport: true,
  newline: 'windows',
  buffer: true,
});

function encodeBase64Url(input: Buffer | string): string {
  const buf = typeof input === 'string' ? Buffer.from(input, 'utf8') : input;
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function sanitizeHeader(val: string): string {
  return val.replace(/[\r\n]+/g, ' ').trim();
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Generates clean, Gmail-native `<div dir="ltr">` HTML matching text/plain 1:1.
 * Avoids heavy newsletter CSS wrappers, dark CTA buttons, and masked anchor text
 * (anchor text always matches the actual URL to avoid anti-phishing spam triggers).
 */
function formatNaturalGmailHtml(bodyText: string): string {
  const lines = bodyText.replace(/\r\n/g, '\n').split('\n');
  const urlRegex = /(https?:\/\/[^\s<>]+)/g;

  const htmlLines = lines.map((line) => {
    const trimmed = line.trim();
    if (!trimmed) return '<div><br></div>';

    let lastIdx = 0;
    let out = '';
    let match: RegExpExecArray | null;
    urlRegex.lastIndex = 0;
    while ((match = urlRegex.exec(line)) !== null) {
      out += escapeHtml(line.slice(lastIdx, match.index));
      const safeUrl = escapeHtml(match[1]);
      out += `<a href="${safeUrl}">${safeUrl}</a>`;
      lastIdx = match.index + match[0].length;
    }
    out += escapeHtml(line.slice(lastIdx));

    return `<div>${out}</div>`;
  });

  return `<div dir="ltr">${htmlLines.join('')}</div>`;
}

export async function buildCompliantMimeMessage(args: Omit<SendGmailArgs, 'accessToken'>): Promise<Buffer> {
  const cleanFromEmail = sanitizeHeader(args.fromEmail);
  const cleanTo = sanitizeHeader(args.to);
  const cleanFromName = args.fromName ? sanitizeHeader(args.fromName) : '';
  const cleanSubject = sanitizeHeader(args.subject);

  const fromField =
    cleanFromEmail === 'me'
      ? undefined
      : cleanFromName
      ? { name: cleanFromName, address: cleanFromEmail }
      : cleanFromEmail;

  const htmlBody = formatNaturalGmailHtml(args.bodyText);

  const mailOptions: SendMailOptions = {
    from: fromField,
    to: cleanTo,
    subject: cleanSubject,
    text: args.bodyText,
    html: htmlBody,
    textEncoding: 'quoted-printable',
    attachments: args.attachment
      ? [
          {
            filename: sanitizeHeader(args.attachment.filename).replace(/"/g, ''),
            content: args.attachment.contentBuffer,
            contentType: args.attachment.mimeType,
            contentDisposition: 'attachment',
          },
        ]
      : undefined,
  };

  const info = await mimeTransport.sendMail(mailOptions);
  return info.message as Buffer;
}

export async function sendEmailViaGmailApi(args: SendGmailArgs): Promise<{ messageId: string }> {
  const rawBuffer = await buildCompliantMimeMessage(args);
  const encoded = encodeBase64Url(rawBuffer);

  const response = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${args.accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ raw: encoded }),
  });

  const json = (await response.json().catch(() => ({}))) as {
    id?: string;
    error?: { message?: string; code?: number };
  };

  if (!response.ok || !json.id) {
    const msg = json.error?.message || `Gmail API rejected request with status ${response.status}`;
    throw new Error(msg);
  }

  return { messageId: json.id };
}

export interface SmtpTransportConfig {
  host: string;
  port: number;
  secure: boolean;
  username: string;
  password: string;
}

export interface SendSmtpArgs extends Omit<SendGmailArgs, 'accessToken'> {
  smtp: SmtpTransportConfig;
  replyTo?: string;
}

function createSmtpTransporter(smtp: SmtpTransportConfig) {
  return nodemailer.createTransport({
    host: sanitizeHeader(smtp.host),
    port: Number(smtp.port) || 587,
    secure: Boolean(smtp.secure),
    auth:
      smtp.username || smtp.password
        ? {
            user: smtp.username,
            pass: smtp.password,
          }
        : undefined,
    connectionTimeout: 12000,
    greetingTimeout: 10000,
    socketTimeout: 20000,
  });
}

export async function verifySmtpConnection(smtp: SmtpTransportConfig): Promise<void> {
  const transporter = createSmtpTransporter(smtp);
  await transporter.verify();
}

export async function sendEmailViaSmtp(args: SendSmtpArgs): Promise<{ messageId: string }> {
  const transporter = createSmtpTransporter(args.smtp);
  const cleanFromEmail = sanitizeHeader(args.fromEmail);
  const cleanFromName = args.fromName ? sanitizeHeader(args.fromName) : '';
  const cleanTo = sanitizeHeader(args.to);
  const cleanSubject = sanitizeHeader(args.subject);
  const cleanReplyTo = args.replyTo ? sanitizeHeader(args.replyTo) : undefined;
  const htmlBody = formatNaturalGmailHtml(args.bodyText);

  const info = await transporter.sendMail({
    from: cleanFromName ? { name: cleanFromName, address: cleanFromEmail } : cleanFromEmail,
    to: cleanTo,
    replyTo: cleanReplyTo || undefined,
    subject: cleanSubject,
    text: args.bodyText,
    html: htmlBody,
    textEncoding: 'quoted-printable',
    attachments: args.attachment
      ? [
          {
            filename: sanitizeHeader(args.attachment.filename).replace(/"/g, ''),
            content: args.attachment.contentBuffer,
            contentType: args.attachment.mimeType,
            contentDisposition: 'attachment',
          },
        ]
      : undefined,
  });

  return { messageId: info.messageId || `smtp_${Date.now()}` };
}

