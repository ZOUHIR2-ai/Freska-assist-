import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const SECURITY_VAULT_FILE = path.resolve(process.cwd(), '.freska-security-vault.json');

export const SECURITY_SESSION_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
export const OTP_CHALLENGE_TTL_MS = 10 * 60 * 1000; // 10 minutes
export const OTP_RESEND_COOLDOWN_MS = 30 * 1000; // 30 seconds
export const OTP_MAX_ATTEMPTS = 5;

interface OtpChallengeRecord {
  email: string;
  codeHash: string;
  createdAtMs: number;
  expiresAtMs: number;
  lastSentAtMs: number;
  attempts: number;
}

interface VerifiedSessionRecord {
  tokenHash: string;
  email: string;
  verifiedAtMs: number;
  expiresAtMs: number;
}

interface SecurityVaultData {
  require24hOtp: boolean;
  challenges: Record<string, OtpChallengeRecord>;
  sessions: Record<string, VerifiedSessionRecord>;
}

const DEFAULT_VAULT: SecurityVaultData = {
  require24hOtp: true,
  challenges: {},
  sessions: {},
};

function getSecurityKey(): Buffer {
  const secret =
    process.env.FRESKA_VAULT_SECRET ||
    process.env.GEMINI_API_KEY ||
    'freska-assist-local-vault-key-v1';
  return crypto.createHash('sha256').update(`security:${secret}`).digest();
}

function encryptVault(plaintext: string): string {
  const iv = crypto.randomBytes(12);
  const key = getSecurityKey();
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return JSON.stringify({
    iv: iv.toString('hex'),
    tag: tag.toString('hex'),
    data: encrypted.toString('hex'),
  });
}

function decryptVault(raw: string): string {
  const parsed = JSON.parse(raw) as { iv: string; tag: string; data: string };
  const key = getSecurityKey();
  const decipher = crypto.createDecipheriv(
    'aes-256-gcm',
    key,
    Buffer.from(parsed.iv, 'hex')
  );
  decipher.setAuthTag(Buffer.from(parsed.tag, 'hex'));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(parsed.data, 'hex')),
    decipher.final(),
  ]);
  return decrypted.toString('utf8');
}

function readSecurityVault(): SecurityVaultData {
  try {
    if (!fs.existsSync(SECURITY_VAULT_FILE)) {
      return { require24hOtp: true, challenges: {}, sessions: {} };
    }
    const raw = fs.readFileSync(SECURITY_VAULT_FILE, 'utf8');
    const json = decryptVault(raw);
    const parsed = JSON.parse(json) as Partial<SecurityVaultData>;
    return {
      require24hOtp: typeof parsed.require24hOtp === 'boolean' ? parsed.require24hOtp : true,
      challenges: parsed.challenges && typeof parsed.challenges === 'object' ? parsed.challenges : {},
      sessions: parsed.sessions && typeof parsed.sessions === 'object' ? parsed.sessions : {},
    };
  } catch (err) {
    console.error('Failed to read security vault:', err);
    return { ...DEFAULT_VAULT, challenges: {}, sessions: {} };
  }
}

function writeSecurityVault(data: SecurityVaultData): void {
  const now = Date.now();
  const cleanChallenges: Record<string, OtpChallengeRecord> = {};
  for (const [k, ch] of Object.entries(data.challenges || {})) {
    if (ch && ch.expiresAtMs > now) {
      cleanChallenges[k] = ch;
    }
  }
  const cleanSessions: Record<string, VerifiedSessionRecord> = {};
  for (const [k, s] of Object.entries(data.sessions || {})) {
    if (s && s.expiresAtMs > now) {
      cleanSessions[k] = s;
    }
  }
  const payload = JSON.stringify({
    require24hOtp: data.require24hOtp,
    challenges: cleanChallenges,
    sessions: cleanSessions,
  });
  const encrypted = encryptVault(payload);
  fs.writeFileSync(SECURITY_VAULT_FILE, encrypted, { encoding: 'utf8', mode: 0o600 });
}

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

export function maskEmailAddress(email: string): string {
  const clean = normalizeEmail(email);
  const [local, domain] = clean.split('@');
  if (!local || !domain) return clean;
  if (local.length <= 2) return `${local[0] || '*'}***@${domain}`;
  return `${local.slice(0, 2)}${'*'.repeat(Math.min(5, local.length - 2))}@${domain}`;
}

function hashOtpCode(email: string, code: string): string {
  const key = getSecurityKey();
  return crypto
    .createHmac('sha256', key)
    .update(`otp:${normalizeEmail(email)}:${code.trim()}`)
    .digest('hex');
}

function hashSessionToken(token: string): string {
  const key = getSecurityKey();
  return crypto.createHmac('sha256', key).update(`sess:${token.trim()}`).digest('hex');
}

export interface SecuritySessionStatus {
  unlocked: boolean;
  require24hOtp: boolean;
  email: string;
  verifiedAt: string | null;
  expiresAt: string | null;
  remainingSeconds: number;
  hasActiveChallenge: boolean;
  challengeCooldownSeconds: number;
}

export function getSecuritySessionStatus(
  emailRaw: string,
  tokenRaw?: string
): SecuritySessionStatus {
  const email = normalizeEmail(emailRaw);
  const vault = readSecurityVault();
  const now = Date.now();

  const ch = email ? vault.challenges[email] : undefined;
  const hasActiveChallenge = Boolean(ch && ch.expiresAtMs > now && ch.attempts < OTP_MAX_ATTEMPTS);
  const cooldownMs = ch && ch.expiresAtMs > now ? Math.max(0, OTP_RESEND_COOLDOWN_MS - (now - ch.lastSentAtMs)) : 0;

  if (!vault.require24hOtp) {
    return {
      unlocked: true,
      require24hOtp: false,
      email,
      verifiedAt: null,
      expiresAt: null,
      remainingSeconds: 0,
      hasActiveChallenge,
      challengeCooldownSeconds: Math.ceil(cooldownMs / 1000),
    };
  }

  if (!email || !tokenRaw) {
    return {
      unlocked: false,
      require24hOtp: true,
      email,
      verifiedAt: null,
      expiresAt: null,
      remainingSeconds: 0,
      hasActiveChallenge,
      challengeCooldownSeconds: Math.ceil(cooldownMs / 1000),
    };
  }

  const tokenHash = hashSessionToken(tokenRaw);
  const sess = vault.sessions[tokenHash];
  if (!sess || sess.email !== email || sess.expiresAtMs <= now) {
    if (sess && sess.expiresAtMs <= now) {
      delete vault.sessions[tokenHash];
      writeSecurityVault(vault);
    }
    return {
      unlocked: false,
      require24hOtp: true,
      email,
      verifiedAt: null,
      expiresAt: null,
      remainingSeconds: 0,
      hasActiveChallenge,
      challengeCooldownSeconds: Math.ceil(cooldownMs / 1000),
    };
  }

  return {
    unlocked: true,
    require24hOtp: true,
    email,
    verifiedAt: new Date(sess.verifiedAtMs).toISOString(),
    expiresAt: new Date(sess.expiresAtMs).toISOString(),
    remainingSeconds: Math.max(0, Math.floor((sess.expiresAtMs - now) / 1000)),
    hasActiveChallenge,
    challengeCooldownSeconds: Math.ceil(cooldownMs / 1000),
  };
}

export function prepareOtpChallenge(
  emailRaw: string,
  options?: { forceNew?: boolean }
):
  | {
      ok: true;
      code: string;
      expiresInSeconds: number;
      cooldownSeconds: number;
    }
  | {
      ok: false;
      reason: 'cooldown';
      cooldownSeconds: number;
      expiresInSeconds: number;
    } {
  const email = normalizeEmail(emailRaw);
  const vault = readSecurityVault();
  const now = Date.now();
  const existing = vault.challenges[email];

  if (
    !options?.forceNew &&
    existing &&
    existing.expiresAtMs > now &&
    existing.attempts < OTP_MAX_ATTEMPTS
  ) {
    const elapsed = now - existing.lastSentAtMs;
    if (elapsed < OTP_RESEND_COOLDOWN_MS) {
      return {
        ok: false,
        reason: 'cooldown',
        cooldownSeconds: Math.ceil((OTP_RESEND_COOLDOWN_MS - elapsed) / 1000),
        expiresInSeconds: Math.ceil((existing.expiresAtMs - now) / 1000),
      };
    }
  }

  const code = String(crypto.randomInt(100000, 1000000));
  const record: OtpChallengeRecord = {
    email,
    codeHash: hashOtpCode(email, code),
    createdAtMs: now,
    expiresAtMs: now + OTP_CHALLENGE_TTL_MS,
    lastSentAtMs: now,
    attempts: 0,
  };
  vault.challenges[email] = record;
  writeSecurityVault(vault);

  return {
    ok: true,
    code,
    expiresInSeconds: Math.floor(OTP_CHALLENGE_TTL_MS / 1000),
    cooldownSeconds: Math.floor(OTP_RESEND_COOLDOWN_MS / 1000),
  };
}

export function clearOtpChallenge(emailRaw: string): void {
  const email = normalizeEmail(emailRaw);
  const vault = readSecurityVault();
  if (vault.challenges[email]) {
    delete vault.challenges[email];
    writeSecurityVault(vault);
  }
}

export function verifyOtpChallenge(
  emailRaw: string,
  codeRaw: string
):
  | {
      ok: true;
      securityToken: string;
      status: SecuritySessionStatus;
    }
  | {
      ok: false;
      error: string;
      attemptsRemaining: number;
    } {
  const email = normalizeEmail(emailRaw);
  const cleanCode = codeRaw.replace(/\D/g, '').trim();
  const vault = readSecurityVault();
  const now = Date.now();
  const ch = vault.challenges[email];

  if (!ch || ch.expiresAtMs <= now) {
    if (ch) {
      delete vault.challenges[email];
      writeSecurityVault(vault);
    }
    return {
      ok: false,
      error: 'Verification code has expired or was not requested yet. Request a new code.',
      attemptsRemaining: 0,
    };
  }

  if (ch.attempts >= OTP_MAX_ATTEMPTS) {
    delete vault.challenges[email];
    writeSecurityVault(vault);
    return {
      ok: false,
      error: 'Too many invalid attempts. Please request a new security code.',
      attemptsRemaining: 0,
    };
  }

  if (cleanCode.length !== 6) {
    return {
      ok: false,
      error: 'Enter the complete 6-digit security code sent to your Gmail.',
      attemptsRemaining: OTP_MAX_ATTEMPTS - ch.attempts,
    };
  }

  const submittedHash = hashOtpCode(email, cleanCode);
  const a = Buffer.from(ch.codeHash, 'hex');
  const b = Buffer.from(submittedHash, 'hex');
  const matches = a.length === b.length && crypto.timingSafeEqual(a, b);

  if (!matches) {
    ch.attempts += 1;
    const remaining = Math.max(0, OTP_MAX_ATTEMPTS - ch.attempts);
    if (remaining === 0) {
      delete vault.challenges[email];
    } else {
      vault.challenges[email] = ch;
    }
    writeSecurityVault(vault);
    return {
      ok: false,
      error:
        remaining > 0
          ? `Incorrect security code. ${remaining} attempt${remaining === 1 ? '' : 's'} remaining.`
          : 'Too many incorrect attempts. Please request a new verification code.',
      attemptsRemaining: remaining,
    };
  }

  // Valid OTP — remove challenge and issue a 24-hour signed session token
  delete vault.challenges[email];

  const securityToken = `fsec_${crypto.randomBytes(32).toString('hex')}`;
  const tokenHash = hashSessionToken(securityToken);
  const expiresAtMs = now + SECURITY_SESSION_TTL_MS;

  vault.sessions[tokenHash] = {
    tokenHash,
    email,
    verifiedAtMs: now,
    expiresAtMs,
  };
  writeSecurityVault(vault);

  return {
    ok: true,
    securityToken,
    status: {
      unlocked: true,
      require24hOtp: vault.require24hOtp,
      email,
      verifiedAt: new Date(now).toISOString(),
      expiresAt: new Date(expiresAtMs).toISOString(),
      remainingSeconds: Math.floor(SECURITY_SESSION_TTL_MS / 1000),
      hasActiveChallenge: false,
      challengeCooldownSeconds: 0,
    },
  };
}

export function revokeSecuritySession(emailRaw?: string, tokenRaw?: string): void {
  const vault = readSecurityVault();
  let changed = false;
  if (tokenRaw) {
    const tokenHash = hashSessionToken(tokenRaw);
    if (vault.sessions[tokenHash]) {
      delete vault.sessions[tokenHash];
      changed = true;
    }
  }
  if (emailRaw) {
    const email = normalizeEmail(emailRaw);
    for (const [k, s] of Object.entries(vault.sessions)) {
      if (s.email === email) {
        delete vault.sessions[k];
        changed = true;
      }
    }
  }
  if (changed) {
    writeSecurityVault(vault);
  }
}

export function setRequire24hOtpSetting(enabled: boolean): boolean {
  const vault = readSecurityVault();
  vault.require24hOtp = Boolean(enabled);
  writeSecurityVault(vault);
  return vault.require24hOtp;
}

export function getRequire24hOtpSetting(): boolean {
  return readSecurityVault().require24hOtp;
}
