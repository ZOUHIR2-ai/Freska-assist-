export type ClientStatus = 'active' | 'inactive' | 'archived';
export type BillingType = 'subscription' | 'one_time';
export type BillingFrequency = 'monthly' | 'quarterly' | 'yearly';
export type PaymentMethod = 'bank_transfer' | 'manual' | 'card';
export type SubscriptionStatus =
  | 'active'
  | 'pending'
  | 'unpaid'
  | 'overdue'
  | 'paused'
  | 'cancelled';
export type PaymentStatus =
  | 'paid'
  | 'pending'
  | 'unpaid'
  | 'overdue'
  | 'cancelled'
  | 'refunded';
export type PaymentRequestStatus = 'pending' | 'paid' | 'overdue' | 'cancelled';
export type InvoiceStatus = 'paid' | 'pending' | 'cancelled' | 'refunded';
export type ReminderStage =
  | 'before_due'
  | 'due_today'
  | 'overdue_1'
  | 'overdue_2'
  | 'manual';

export interface AdminUser {
  uid: string;
  email: string;
  displayName: string;
  role: 'admin';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface ClientRecord {
  id: string;
  clientCode: string;
  fullName: string;
  businessName: string;
  email: string;
  phone?: string;
  businessType?: string;
  servicesPurchased?: string[];
  notes?: string;
  status: ClientStatus;
  preferredCurrency?: string;
  preferredPaymentMethod?: PaymentMethod;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface ServiceRecord {
  id: string;
  name: string;
  description?: string;
  billingType: BillingType;
  defaultPrice: number;
  currency: string;
  active: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface SubscriptionRecord {
  id: string;
  clientId: string;
  serviceId?: string;
  name: string;
  description?: string;
  monthlyPrice: number;
  currency: string;
  startDate: string;
  lastPaymentDate?: string;
  nextPaymentDate: string;
  billingFrequency: BillingFrequency;
  paymentMethod: PaymentMethod;
  status: SubscriptionStatus;
  reminderEnabled: boolean;
  autoRenew: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface PaymentRecord {
  id: string;
  paymentCode: string;
  clientId: string;
  subscriptionId?: string;
  paymentRequestId?: string;
  invoiceId?: string;
  invoiceNumber?: string;
  serviceName: string;
  description?: string;
  billingType: BillingType;
  paymentMethod: PaymentMethod;
  amount: number;
  currency: string;
  paymentDate: string;
  confirmedAt?: string;
  transactionReference?: string;
  manuallyVerified: boolean;
  notes?: string;
  status: PaymentStatus;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface PaymentRequestRecord {
  id: string;
  clientId: string;
  subscriptionId?: string;
  serviceId?: string;
  serviceName: string;
  description?: string;
  billingType: BillingType;
  paymentMethod: PaymentMethod;
  reference: string;
  amount: number;
  currency: string;
  dueDate: string;
  paymentUrl?: string;
  gatewaySessionId?: string;
  status: PaymentRequestStatus;
  paidAt?: string;
  paymentId?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface InvoiceRecord {
  id: string;
  invoiceNumber: string;
  clientId: string;
  clientName: string;
  businessName?: string;
  clientEmail: string;
  paymentId: string;
  paymentRequestId?: string;
  subscriptionId?: string;
  serviceName: string;
  serviceDescription?: string;
  paymentType: BillingType;
  paymentMethod: PaymentMethod;
  amount: number;
  currency: string;
  invoiceDate: string;
  paymentDate: string;
  paymentReference?: string;
  status: InvoiceStatus;
  downloadToken?: string;
  sentViaGmail?: boolean;
  sentAt?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface InvoiceItemRecord {
  id: string;
  invoiceId: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
  createdAt?: unknown;
}

export interface ReminderSettingRecord {
  id: string;
  clientId: string;
  enabled: boolean;
  daysBeforeDue: number;
  sendOnDueDate: boolean;
  daysAfterDueFirst: number;
  daysAfterDueSecond: number;
  customOffsets?: number[];
  updatedAt?: unknown;
}

export interface ReminderLogRecord {
  id: string;
  clientId: string;
  subscriptionId: string;
  billingCycleDate: string;
  stage: ReminderStage;
  emailLogId?: string;
  status: 'sent' | 'failed' | 'cancelled' | 'skipped';
  errorMessage?: string;
  scheduledFor?: string;
  sentAt?: string;
  createdAt?: unknown;
}

export interface EmailLogRecord {
  id: string;
  clientId?: string;
  recipient: string;
  subject: string;
  emailType: string;
  gmailMessageId?: string;
  status: 'sent' | 'failed';
  errorMessage?: string;
  sentAt?: string;
  createdAt?: unknown;
}

export interface EmailTemplateRecord {
  id: string;
  templateKey: string;
  label: string;
  senderDisplayName: string;
  subject: string;
  body: string;
  updatedAt?: unknown;
}

export interface PaymentGatewaySettingRecord {
  id: string;
  provider: string;
  environment: 'test' | 'live';
  cardEnabled: boolean;
  credentialsConfigured: boolean;
  connectionVerified: boolean;
  bankAccountName?: string;
  bankName?: string;
  bankIban?: string;
  bankBic?: string;
  bankInstructions?: string;
  updatedAt?: unknown;
}

export interface WebhookEventRecord {
  id: string;
  provider: string;
  eventType: string;
  externalEventId: string;
  status: 'processed' | 'ignored' | 'failed';
  summary?: string;
  receivedAt?: string;
  createdAt?: unknown;
}

export interface SystemSettingRecord {
  id: string;
  businessName: string;
  adminEmail?: string;
  timezone: string;
  defaultCurrency: string;
  invoicePrefix: string;
  companyAddress?: string;
  taxId?: string;
  updatedAt?: unknown;
}

export interface PublicGatewayStatus {
  provider: 'stripe';
  environment: 'test' | 'live';
  enabled: boolean;
  hasPublicKey: boolean;
  publicKeyMasked: string;
  hasSecretKey: boolean;
  secretKeyLast4: string;
  hasWebhookSecret: boolean;
  connectionVerified: boolean;
  lastVerifiedAt: string | null;
  accountId: string | null;
  updatedAt: string;
}

export type NavSection =
  | 'overview'
  | 'clients'
  | 'client_profile'
  | 'subscriptions'
  | 'payments'
  | 'invoices'
  | 'email_center'
  | 'reminders'
  | 'payment_settings'
  | 'gmail_integration'
  | 'settings';
